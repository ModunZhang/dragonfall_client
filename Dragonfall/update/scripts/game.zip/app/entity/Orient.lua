return import("..utils.Enum")("X",
    "Y",
    "NEG_X",
    "NEG_Y",
    "RIGHT",
    "DOWN",
    "LEFT",
    "UP",
    "NONE")






