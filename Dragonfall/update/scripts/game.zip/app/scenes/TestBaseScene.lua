--
-- Author: Danny He
-- Date: 2015-09-06 10:34:57
--
local TestBaseScene = class("TestBaseScene", function()
    return display.newScene("TestBaseScene")
end)

function TestBaseScene:ctor()
	app:createGrid(self)

    self:createEditBox()

    app:createTitle(self, "Test UIButton")
    app:createNextButton(self)
end

function TestBaseScene:createEditBox()
	 local editbox = cc.ui.UIInput.new({
        UIInputType = 1,
        image = "EditBoxBg.png",
        size = cc.size(417,51),
        listener = onEdit,
    })
    editbox:setPlaceHolder(string.format("最多可输入%d字符",140))
    editbox:setMaxLength(140)
    -- editbox:setFont(UIKit:getEditBoxFont(),22)
    -- editbox:setFontColor(cc.c3b(0,0,0))
    -- editbox:setPlaceholderFontColor(cc.c3b(204,196,158))
    editbox:setReturnType(cc.KEYBOARD_RETURNTYPE_SEND)
    editbox:align(display.CENTER,display.cx, display.top - 70):addTo(self)
end

return TestBaseScene