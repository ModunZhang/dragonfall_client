local allianceMap_1 = GameDatas.AllianceMap.allianceMap_1

allianceMap_1[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 1
}
allianceMap_1[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 2
}
allianceMap_1[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 2
}
allianceMap_1[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 2
}
allianceMap_1[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 2
}
allianceMap_1[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 2
}
allianceMap_1[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 2
}
allianceMap_1[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 2
}
allianceMap_1[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 2
}
allianceMap_1[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 2
}
allianceMap_1[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 2
}
allianceMap_1[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 2
}
allianceMap_1[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 3
}
allianceMap_1[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 3
}
allianceMap_1[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 3
}
allianceMap_1[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 3
}
allianceMap_1[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 3
}
allianceMap_1[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 3
}
allianceMap_1[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 3
}
allianceMap_1[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 3
}
allianceMap_1[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 3
}
allianceMap_1[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 3
}
allianceMap_1[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 3
}
allianceMap_1[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 3
}
allianceMap_1[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 3
}
allianceMap_1[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 3
}
allianceMap_1[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 3
}
allianceMap_1[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 4
}
allianceMap_1[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 4
}
allianceMap_1[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 4
}
allianceMap_1[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 4
}
allianceMap_1[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 4
}
allianceMap_1[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 4
}
allianceMap_1[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 4
}
allianceMap_1[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 4
}
allianceMap_1[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 4
}
allianceMap_1[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 4
}
allianceMap_1[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 5
}
allianceMap_1[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 5
}
allianceMap_1[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 5
}
allianceMap_1[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 5
}
allianceMap_1[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 5
}
allianceMap_1[42] = {
	["index"] = 42,
	["name"] = "decorate_mountain_1",
	["x"] = 13,
	["y"] = 5
}
allianceMap_1[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 5
}
allianceMap_1[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 5
}
allianceMap_1[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 5
}
allianceMap_1[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 5
}
allianceMap_1[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 5
}
allianceMap_1[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 5
}
allianceMap_1[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 6
}
allianceMap_1[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 6
}
allianceMap_1[51] = {
	["index"] = 51,
	["name"] = "decorate_mountain_2",
	["x"] = 7,
	["y"] = 6
}
allianceMap_1[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 6
}
allianceMap_1[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 6
}
allianceMap_1[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 6
}
allianceMap_1[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 6
}
allianceMap_1[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 6
}
allianceMap_1[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 6
}
allianceMap_1[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 6
}
allianceMap_1[59] = {
	["index"] = 59,
	["name"] = "decorate_lake_2",
	["x"] = 24,
	["y"] = 6
}
allianceMap_1[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 6
}
allianceMap_1[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 6
}
allianceMap_1[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 6
}
allianceMap_1[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 7
}
allianceMap_1[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 7
}
allianceMap_1[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 7
}
allianceMap_1[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 7
}
allianceMap_1[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 7
}
allianceMap_1[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 7
}
allianceMap_1[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 7
}
allianceMap_1[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 7
}
allianceMap_1[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 7
}
allianceMap_1[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 7
}
allianceMap_1[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 7
}
allianceMap_1[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 8
}
allianceMap_1[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 8
}
allianceMap_1[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 8
}
allianceMap_1[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 8
}
allianceMap_1[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 9
}
allianceMap_1[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 9
}
allianceMap_1[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 9
}
allianceMap_1[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 9
}
allianceMap_1[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 9
}
allianceMap_1[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 10
}
allianceMap_1[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 10
}
allianceMap_1[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 10
}
allianceMap_1[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_8",
	["x"] = 28,
	["y"] = 10
}
allianceMap_1[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 11
}
allianceMap_1[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 11
}
allianceMap_1[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 12
}
allianceMap_1[90] = {
	["index"] = 90,
	["name"] = "decorate_lake_2",
	["x"] = 5,
	["y"] = 12
}
allianceMap_1[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 12
}
allianceMap_1[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 12
}
allianceMap_1[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 12
}
allianceMap_1[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 12
}
allianceMap_1[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 12
}
allianceMap_1[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 12
}
allianceMap_1[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 13
}
allianceMap_1[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_6",
	["x"] = 3,
	["y"] = 13
}
allianceMap_1[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 13
}
allianceMap_1[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 13
}
allianceMap_1[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 13
}
allianceMap_1[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 13
}
allianceMap_1[103] = {
	["index"] = 103,
	["name"] = "palace",
	["x"] = 13,
	["y"] = 13
}
allianceMap_1[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 13
}
allianceMap_1[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 13
}
allianceMap_1[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 13
}
allianceMap_1[107] = {
	["index"] = 107,
	["name"] = "bloodSpring",
	["x"] = 17,
	["y"] = 13
}
allianceMap_1[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 13
}
allianceMap_1[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 13
}
allianceMap_1[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 14
}
allianceMap_1[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 14
}
allianceMap_1[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 14
}
allianceMap_1[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 14
}
allianceMap_1[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 14
}
allianceMap_1[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 14
}
allianceMap_1[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 14
}
allianceMap_1[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 14
}
allianceMap_1[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 14
}
allianceMap_1[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 14
}
allianceMap_1[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 14
}
allianceMap_1[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 15
}
allianceMap_1[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 15
}
allianceMap_1[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 15
}
allianceMap_1[124] = {
	["index"] = 124,
	["name"] = "orderHall",
	["x"] = 13,
	["y"] = 15
}
allianceMap_1[125] = {
	["index"] = 125,
	["name"] = "shop",
	["x"] = 17,
	["y"] = 15
}
allianceMap_1[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 15
}
allianceMap_1[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 15
}
allianceMap_1[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 15
}
allianceMap_1[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 15
}
allianceMap_1[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 15
}
allianceMap_1[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 15
}
allianceMap_1[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 16
}
allianceMap_1[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 16
}
allianceMap_1[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 16
}
allianceMap_1[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 16
}
allianceMap_1[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 16
}
allianceMap_1[137] = {
	["index"] = 137,
	["name"] = "decorate_lake_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_1[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_1[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 16
}
allianceMap_1[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 17
}
allianceMap_1[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 17
}
allianceMap_1[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 17
}
allianceMap_1[143] = {
	["index"] = 143,
	["name"] = "shrine",
	["x"] = 13,
	["y"] = 17
}
allianceMap_1[144] = {
	["index"] = 144,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
allianceMap_1[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 17
}
allianceMap_1[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 17
}
allianceMap_1[147] = {
	["index"] = 147,
	["name"] = "watchTower",
	["x"] = 17,
	["y"] = 17
}
allianceMap_1[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 17
}
allianceMap_1[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 17
}
allianceMap_1[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 18
}
allianceMap_1[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 18
}
allianceMap_1[152] = {
	["index"] = 152,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 18
}
allianceMap_1[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 18
}
allianceMap_1[154] = {
	["index"] = 154,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 18
}
allianceMap_1[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 18
}
allianceMap_1[156] = {
	["index"] = 156,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 18
}
allianceMap_1[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 18
}
allianceMap_1[158] = {
	["index"] = 158,
	["name"] = "decorate_mountain_2",
	["x"] = 27,
	["y"] = 18
}
allianceMap_1[159] = {
	["index"] = 159,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 18
}
allianceMap_1[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 19
}
allianceMap_1[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 19
}
allianceMap_1[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 19
}
allianceMap_1[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 19
}
allianceMap_1[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 19
}
allianceMap_1[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 19
}
allianceMap_1[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 19
}
allianceMap_1[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 19
}
allianceMap_1[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 19
}
allianceMap_1[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 19
}
allianceMap_1[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 20
}
allianceMap_1[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 20
}
allianceMap_1[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_9",
	["x"] = 26,
	["y"] = 20
}
allianceMap_1[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 20
}
allianceMap_1[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 21
}
allianceMap_1[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 21
}
allianceMap_1[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 21
}
allianceMap_1[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 21
}
allianceMap_1[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 22
}
allianceMap_1[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 22
}
allianceMap_1[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 22
}
allianceMap_1[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 22
}
allianceMap_1[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 22
}
allianceMap_1[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 22
}
allianceMap_1[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 23
}
allianceMap_1[185] = {
	["index"] = 185,
	["name"] = "decorate_mountain_1",
	["x"] = 6,
	["y"] = 23
}
allianceMap_1[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 23
}
allianceMap_1[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 23
}
allianceMap_1[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 23
}
allianceMap_1[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 23
}
allianceMap_1[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 23
}
allianceMap_1[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 23
}
allianceMap_1[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 23
}
allianceMap_1[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 23
}
allianceMap_1[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 24
}
allianceMap_1[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 24
}
allianceMap_1[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 24
}
allianceMap_1[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 24
}
allianceMap_1[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 24
}
allianceMap_1[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 24
}
allianceMap_1[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 24
}
allianceMap_1[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 24
}
allianceMap_1[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 24
}
allianceMap_1[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 24
}
allianceMap_1[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 25
}
allianceMap_1[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 25
}
allianceMap_1[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 25
}
allianceMap_1[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 25
}
allianceMap_1[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 25
}
allianceMap_1[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 25
}
allianceMap_1[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 25
}
allianceMap_1[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 25
}
allianceMap_1[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 26
}
allianceMap_1[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 26
}
allianceMap_1[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 26
}
allianceMap_1[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 26
}
allianceMap_1[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 26
}
allianceMap_1[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 26
}
allianceMap_1[218] = {
	["index"] = 218,
	["name"] = "decorate_mountain_1",
	["x"] = 25,
	["y"] = 26
}
allianceMap_1[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 26
}
allianceMap_1[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 26
}
allianceMap_1[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 26
}
allianceMap_1[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 27
}
allianceMap_1[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 27
}
allianceMap_1[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 27
}
allianceMap_1[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_8",
	["x"] = 12,
	["y"] = 27
}
allianceMap_1[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 27
}
allianceMap_1[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 27
}
allianceMap_1[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 27
}
allianceMap_1[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 27
}
allianceMap_1[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 27
}
allianceMap_1[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 27
}
allianceMap_1[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 27
}
allianceMap_1[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 28
}
allianceMap_1[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 28
}
allianceMap_1[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 28
}
allianceMap_1[236] = {
	["index"] = 236,
	["name"] = "decorate_mountain_2",
	["x"] = 10,
	["y"] = 28
}
allianceMap_1[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 28
}
allianceMap_1[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 28
}
allianceMap_1[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 28
}
allianceMap_1[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 28
}
allianceMap_1[241] = {
	["index"] = 241,
	["name"] = "decorate_lake_2",
	["x"] = 20,
	["y"] = 28
}
allianceMap_1[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 28
}
allianceMap_1[243] = {
	["index"] = 243,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 28
}
allianceMap_1[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 28
}
allianceMap_1[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 28
}
allianceMap_1[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 29
}
allianceMap_1[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 29
}
allianceMap_1[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 29
}
allianceMap_1[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 29
}
allianceMap_1[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 29
}
allianceMap_1[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 29
}
allianceMap_1[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 29
}
allianceMap_1[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 29
}
allianceMap_1[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 29
}
allianceMap_1[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 29
}
allianceMap_1[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 29
}
allianceMap_1[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 29
}
allianceMap_1[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 29
}
allianceMap_1[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 29
}
