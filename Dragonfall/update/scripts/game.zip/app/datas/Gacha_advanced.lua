local advanced = GameDatas.Gacha.advanced

advanced[1] = {
	["index"] = 1,
	["itemName"] = "gemClass_3",
	["itemCount"] = 2,
	["weight"] = 1
}
advanced[2] = {
	["index"] = 2,
	["itemName"] = "vipPoint_3",
	["itemCount"] = 1,
	["weight"] = 5
}
advanced[3] = {
	["index"] = 3,
	["itemName"] = "dragonChest_2",
	["itemCount"] = 1,
	["weight"] = 8
}
advanced[4] = {
	["index"] = 4,
	["itemName"] = "dragonChest_3",
	["itemCount"] = 1,
	["weight"] = 2
}
advanced[5] = {
	["index"] = 5,
	["itemName"] = "woodClass_6",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[6] = {
	["index"] = 6,
	["itemName"] = "stoneClass_6",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[7] = {
	["index"] = 7,
	["itemName"] = "ironClass_6",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[8] = {
	["index"] = 8,
	["itemName"] = "foodClass_6",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[9] = {
	["index"] = 9,
	["itemName"] = "chest_3",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[10] = {
	["index"] = 10,
	["itemName"] = "chest_4",
	["itemCount"] = 1,
	["weight"] = 2
}
advanced[11] = {
	["index"] = 11,
	["itemName"] = "speedup_7",
	["itemCount"] = 1,
	["weight"] = 9
}
advanced[12] = {
	["index"] = 12,
	["itemName"] = "stamina_2",
	["itemCount"] = 1,
	["weight"] = 8
}
advanced[13] = {
	["index"] = 13,
	["itemName"] = "unitHpBonus_1",
	["itemCount"] = 1,
	["weight"] = 5
}
advanced[14] = {
	["index"] = 14,
	["itemName"] = "quarterMaster_2",
	["itemCount"] = 1,
	["weight"] = 5
}
advanced[15] = {
	["index"] = 15,
	["itemName"] = "marchSpeedBonus_2",
	["itemCount"] = 1,
	["weight"] = 5
}
advanced[16] = {
	["index"] = 16,
	["itemName"] = "coinBonus_2",
	["itemCount"] = 1,
	["weight"] = 5
}
