local dailyQuestStar = GameDatas.DailyQuests.dailyQuestStar

dailyQuestStar[1] = {
	["star"] = 1,
	["needMinutes"] = 9.000000
}
dailyQuestStar[2] = {
	["star"] = 2,
	["needMinutes"] = 18.000000
}
dailyQuestStar[3] = {
	["star"] = 3,
	["needMinutes"] = 27.000000
}
dailyQuestStar[4] = {
	["star"] = 4,
	["needMinutes"] = 36.000000
}
dailyQuestStar[5] = {
	["star"] = 5,
	["needMinutes"] = 45.000000
}
