local noManMap_4 = GameDatas.NoManMap.noManMap_4

noManMap_4[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 0
}
noManMap_4[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 0
}
noManMap_4[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 0
}
noManMap_4[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 0
}
noManMap_4[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 0
}
noManMap_4[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 0
}
noManMap_4[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 0
}
noManMap_4[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 0
}
noManMap_4[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 0
}
noManMap_4[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 0
}
noManMap_4[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 0
}
noManMap_4[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 0
}
noManMap_4[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 0
}
noManMap_4[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_4",
	["x"] = 30,
	["y"] = 0
}
noManMap_4[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 1
}
noManMap_4[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_7",
	["x"] = 5,
	["y"] = 1
}
noManMap_4[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 1
}
noManMap_4[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 1
}
noManMap_4[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 1
}
noManMap_4[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 1
}
noManMap_4[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_7",
	["x"] = 20,
	["y"] = 1
}
noManMap_4[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 1
}
noManMap_4[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 1
}
noManMap_4[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 1
}
noManMap_4[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 1
}
noManMap_4[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 2
}
noManMap_4[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 2
}
noManMap_4[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 2
}
noManMap_4[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_6",
	["x"] = 9,
	["y"] = 2
}
noManMap_4[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 2
}
noManMap_4[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 2
}
noManMap_4[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 2
}
noManMap_4[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 2
}
noManMap_4[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 2
}
noManMap_4[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 2
}
noManMap_4[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 2
}
noManMap_4[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_7",
	["x"] = 28,
	["y"] = 2
}
noManMap_4[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 2
}
noManMap_4[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 3
}
noManMap_4[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 3
}
noManMap_4[40] = {
	["index"] = 40,
	["name"] = "decorate_lake_2",
	["x"] = 4,
	["y"] = 3
}
noManMap_4[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 3
}
noManMap_4[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 3
}
noManMap_4[43] = {
	["index"] = 43,
	["name"] = "decorate_mountain_2",
	["x"] = 14,
	["y"] = 3
}
noManMap_4[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 3
}
noManMap_4[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 3
}
noManMap_4[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_9",
	["x"] = 17,
	["y"] = 3
}
noManMap_4[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 3
}
noManMap_4[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 3
}
noManMap_4[49] = {
	["index"] = 49,
	["name"] = "decorate_mountain_1",
	["x"] = 25,
	["y"] = 3
}
noManMap_4[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 3
}
noManMap_4[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 3
}
noManMap_4[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 3
}
noManMap_4[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 4
}
noManMap_4[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 4
}
noManMap_4[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 4
}
noManMap_4[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 4
}
noManMap_4[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 4
}
noManMap_4[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 4
}
noManMap_4[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 4
}
noManMap_4[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 4
}
noManMap_4[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 4
}
noManMap_4[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 4
}
noManMap_4[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 4
}
noManMap_4[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 4
}
noManMap_4[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 4
}
noManMap_4[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 4
}
noManMap_4[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 4
}
noManMap_4[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 5
}
noManMap_4[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 5
}
noManMap_4[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 5
}
noManMap_4[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 5
}
noManMap_4[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 5
}
noManMap_4[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 5
}
noManMap_4[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 5
}
noManMap_4[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 5
}
noManMap_4[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 5
}
noManMap_4[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 5
}
noManMap_4[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_1",
	["x"] = 0,
	["y"] = 6
}
noManMap_4[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_9",
	["x"] = 2,
	["y"] = 6
}
noManMap_4[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 6
}
noManMap_4[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 6
}
noManMap_4[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 6
}
noManMap_4[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 6
}
noManMap_4[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 6
}
noManMap_4[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 6
}
noManMap_4[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 6
}
noManMap_4[87] = {
	["index"] = 87,
	["name"] = "decorate_mountain_2",
	["x"] = 29,
	["y"] = 6
}
noManMap_4[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 7
}
noManMap_4[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 7
}
noManMap_4[90] = {
	["index"] = 90,
	["name"] = "decorate_mountain_1",
	["x"] = 7,
	["y"] = 7
}
noManMap_4[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 7
}
noManMap_4[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 7
}
noManMap_4[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 7
}
noManMap_4[94] = {
	["index"] = 94,
	["name"] = "decorate_lake_2",
	["x"] = 22,
	["y"] = 7
}
noManMap_4[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 7
}
noManMap_4[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 7
}
noManMap_4[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_6",
	["x"] = 25,
	["y"] = 7
}
noManMap_4[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 7
}
noManMap_4[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 7
}
noManMap_4[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 7
}
noManMap_4[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 7
}
noManMap_4[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 8
}
noManMap_4[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 8
}
noManMap_4[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 8
}
noManMap_4[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 8
}
noManMap_4[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 8
}
noManMap_4[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 8
}
noManMap_4[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_3",
	["x"] = 20,
	["y"] = 8
}
noManMap_4[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 8
}
noManMap_4[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 8
}
noManMap_4[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 8
}
noManMap_4[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 8
}
noManMap_4[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 8
}
noManMap_4[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 8
}
noManMap_4[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 9
}
noManMap_4[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 9
}
noManMap_4[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 9
}
noManMap_4[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 9
}
noManMap_4[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 9
}
noManMap_4[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_7",
	["x"] = 7,
	["y"] = 9
}
noManMap_4[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 9
}
noManMap_4[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 9
}
noManMap_4[123] = {
	["index"] = 123,
	["name"] = "decorate_mountain_2",
	["x"] = 12,
	["y"] = 9
}
noManMap_4[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 9
}
noManMap_4[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 9
}
noManMap_4[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 9
}
noManMap_4[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 9
}
noManMap_4[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 9
}
noManMap_4[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 10
}
noManMap_4[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 10
}
noManMap_4[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_7",
	["x"] = 10,
	["y"] = 10
}
noManMap_4[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 10
}
noManMap_4[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 10
}
noManMap_4[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 10
}
noManMap_4[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 10
}
noManMap_4[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 10
}
noManMap_4[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 10
}
noManMap_4[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 10
}
noManMap_4[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 10
}
noManMap_4[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 10
}
noManMap_4[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_4",
	["x"] = 30,
	["y"] = 10
}
noManMap_4[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 11
}
noManMap_4[143] = {
	["index"] = 143,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 11
}
noManMap_4[144] = {
	["index"] = 144,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 11
}
noManMap_4[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 11
}
noManMap_4[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 11
}
noManMap_4[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 11
}
noManMap_4[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 11
}
noManMap_4[149] = {
	["index"] = 149,
	["name"] = "decorate_lake_2",
	["x"] = 19,
	["y"] = 11
}
noManMap_4[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 11
}
noManMap_4[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 11
}
noManMap_4[152] = {
	["index"] = 152,
	["name"] = "decorate_lake_1",
	["x"] = 28,
	["y"] = 11
}
noManMap_4[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 11
}
noManMap_4[154] = {
	["index"] = 154,
	["name"] = "decorate_mountain_2",
	["x"] = 3,
	["y"] = 12
}
noManMap_4[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 12
}
noManMap_4[156] = {
	["index"] = 156,
	["name"] = "decorate_tree_8",
	["x"] = 8,
	["y"] = 12
}
noManMap_4[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 12
}
noManMap_4[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 12
}
noManMap_4[159] = {
	["index"] = 159,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 12
}
noManMap_4[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 12
}
noManMap_4[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 12
}
noManMap_4[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 12
}
noManMap_4[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 12
}
noManMap_4[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 13
}
noManMap_4[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 13
}
noManMap_4[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 13
}
noManMap_4[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_7",
	["x"] = 5,
	["y"] = 13
}
noManMap_4[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 13
}
noManMap_4[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 13
}
noManMap_4[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 13
}
noManMap_4[171] = {
	["index"] = 171,
	["name"] = "decorate_mountain_2",
	["x"] = 24,
	["y"] = 13
}
noManMap_4[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 13
}
noManMap_4[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_4",
	["x"] = 30,
	["y"] = 13
}
noManMap_4[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 14
}
noManMap_4[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 14
}
noManMap_4[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 14
}
noManMap_4[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 14
}
noManMap_4[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 14
}
noManMap_4[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 14
}
noManMap_4[180] = {
	["index"] = 180,
	["name"] = "decorate_lake_2",
	["x"] = 13,
	["y"] = 14
}
noManMap_4[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 14
}
noManMap_4[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_6",
	["x"] = 17,
	["y"] = 14
}
noManMap_4[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 14
}
noManMap_4[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 14
}
noManMap_4[185] = {
	["index"] = 185,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 14
}
noManMap_4[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 14
}
noManMap_4[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 14
}
noManMap_4[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 14
}
noManMap_4[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 15
}
noManMap_4[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 15
}
noManMap_4[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_7",
	["x"] = 7,
	["y"] = 15
}
noManMap_4[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 15
}
noManMap_4[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 15
}
noManMap_4[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 15
}
noManMap_4[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 15
}
noManMap_4[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 15
}
noManMap_4[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 15
}
noManMap_4[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 15
}
noManMap_4[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 15
}
noManMap_4[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 15
}
noManMap_4[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 16
}
noManMap_4[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 16
}
noManMap_4[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 16
}
noManMap_4[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 16
}
noManMap_4[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 16
}
noManMap_4[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 16
}
noManMap_4[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 16
}
noManMap_4[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 16
}
noManMap_4[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 16
}
noManMap_4[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 16
}
noManMap_4[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 16
}
noManMap_4[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 16
}
noManMap_4[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 16
}
noManMap_4[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 17
}
noManMap_4[215] = {
	["index"] = 215,
	["name"] = "decorate_lake_1",
	["x"] = 4,
	["y"] = 17
}
noManMap_4[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 17
}
noManMap_4[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 17
}
noManMap_4[218] = {
	["index"] = 218,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 17
}
noManMap_4[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 17
}
noManMap_4[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 17
}
noManMap_4[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 17
}
noManMap_4[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 17
}
noManMap_4[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_9",
	["x"] = 22,
	["y"] = 17
}
noManMap_4[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 17
}
noManMap_4[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 17
}
noManMap_4[226] = {
	["index"] = 226,
	["name"] = "decorate_mountain_1",
	["x"] = 28,
	["y"] = 17
}
noManMap_4[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 17
}
noManMap_4[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 17
}
noManMap_4[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 18
}
noManMap_4[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_7",
	["x"] = 3,
	["y"] = 18
}
noManMap_4[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 18
}
noManMap_4[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 18
}
noManMap_4[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 18
}
noManMap_4[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 18
}
noManMap_4[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 18
}
noManMap_4[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 18
}
noManMap_4[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 18
}
noManMap_4[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 19
}
noManMap_4[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 19
}
noManMap_4[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 19
}
noManMap_4[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_6",
	["x"] = 6,
	["y"] = 19
}
noManMap_4[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 19
}
noManMap_4[243] = {
	["index"] = 243,
	["name"] = "decorate_mountain_2",
	["x"] = 12,
	["y"] = 19
}
noManMap_4[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 19
}
noManMap_4[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 19
}
noManMap_4[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 19
}
noManMap_4[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 19
}
noManMap_4[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 19
}
noManMap_4[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 19
}
noManMap_4[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 19
}
noManMap_4[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_7",
	["x"] = 25,
	["y"] = 19
}
noManMap_4[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 19
}
noManMap_4[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 19
}
noManMap_4[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 19
}
noManMap_4[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 20
}
noManMap_4[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_8",
	["x"] = 1,
	["y"] = 20
}
noManMap_4[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 20
}
noManMap_4[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 20
}
noManMap_4[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 20
}
noManMap_4[260] = {
	["index"] = 260,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 20
}
noManMap_4[261] = {
	["index"] = 261,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 20
}
noManMap_4[262] = {
	["index"] = 262,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 20
}
noManMap_4[263] = {
	["index"] = 263,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 20
}
noManMap_4[264] = {
	["index"] = 264,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 20
}
noManMap_4[265] = {
	["index"] = 265,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 20
}
noManMap_4[266] = {
	["index"] = 266,
	["name"] = "decorate_tree_7",
	["x"] = 23,
	["y"] = 20
}
noManMap_4[267] = {
	["index"] = 267,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 20
}
noManMap_4[268] = {
	["index"] = 268,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 20
}
noManMap_4[269] = {
	["index"] = 269,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 20
}
noManMap_4[270] = {
	["index"] = 270,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 20
}
noManMap_4[271] = {
	["index"] = 271,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 21
}
noManMap_4[272] = {
	["index"] = 272,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 21
}
noManMap_4[273] = {
	["index"] = 273,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 21
}
noManMap_4[274] = {
	["index"] = 274,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 21
}
noManMap_4[275] = {
	["index"] = 275,
	["name"] = "decorate_tree_8",
	["x"] = 15,
	["y"] = 21
}
noManMap_4[276] = {
	["index"] = 276,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 21
}
noManMap_4[277] = {
	["index"] = 277,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 21
}
noManMap_4[278] = {
	["index"] = 278,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 21
}
noManMap_4[279] = {
	["index"] = 279,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 21
}
noManMap_4[280] = {
	["index"] = 280,
	["name"] = "decorate_tree_7",
	["x"] = 27,
	["y"] = 21
}
noManMap_4[281] = {
	["index"] = 281,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 21
}
noManMap_4[282] = {
	["index"] = 282,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 21
}
noManMap_4[283] = {
	["index"] = 283,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 22
}
noManMap_4[284] = {
	["index"] = 284,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 22
}
noManMap_4[285] = {
	["index"] = 285,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 22
}
noManMap_4[286] = {
	["index"] = 286,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 22
}
noManMap_4[287] = {
	["index"] = 287,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 22
}
noManMap_4[288] = {
	["index"] = 288,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 22
}
noManMap_4[289] = {
	["index"] = 289,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 22
}
noManMap_4[290] = {
	["index"] = 290,
	["name"] = "decorate_lake_1",
	["x"] = 20,
	["y"] = 22
}
noManMap_4[291] = {
	["index"] = 291,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 22
}
noManMap_4[292] = {
	["index"] = 292,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 22
}
noManMap_4[293] = {
	["index"] = 293,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 22
}
noManMap_4[294] = {
	["index"] = 294,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 22
}
noManMap_4[295] = {
	["index"] = 295,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 22
}
noManMap_4[296] = {
	["index"] = 296,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 23
}
noManMap_4[297] = {
	["index"] = 297,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 23
}
noManMap_4[298] = {
	["index"] = 298,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 23
}
noManMap_4[299] = {
	["index"] = 299,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 23
}
noManMap_4[300] = {
	["index"] = 300,
	["name"] = "decorate_lake_2",
	["x"] = 9,
	["y"] = 23
}
noManMap_4[301] = {
	["index"] = 301,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 23
}
noManMap_4[302] = {
	["index"] = 302,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 23
}
noManMap_4[303] = {
	["index"] = 303,
	["name"] = "decorate_tree_8",
	["x"] = 24,
	["y"] = 23
}
noManMap_4[304] = {
	["index"] = 304,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 23
}
noManMap_4[305] = {
	["index"] = 305,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 23
}
noManMap_4[306] = {
	["index"] = 306,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 24
}
noManMap_4[307] = {
	["index"] = 307,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 24
}
noManMap_4[308] = {
	["index"] = 308,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 24
}
noManMap_4[309] = {
	["index"] = 309,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 24
}
noManMap_4[310] = {
	["index"] = 310,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 24
}
noManMap_4[311] = {
	["index"] = 311,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 24
}
noManMap_4[312] = {
	["index"] = 312,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 24
}
noManMap_4[313] = {
	["index"] = 313,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 24
}
noManMap_4[314] = {
	["index"] = 314,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 24
}
noManMap_4[315] = {
	["index"] = 315,
	["name"] = "decorate_mountain_1",
	["x"] = 3,
	["y"] = 25
}
noManMap_4[316] = {
	["index"] = 316,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 25
}
noManMap_4[317] = {
	["index"] = 317,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 25
}
noManMap_4[318] = {
	["index"] = 318,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 25
}
noManMap_4[319] = {
	["index"] = 319,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 25
}
noManMap_4[320] = {
	["index"] = 320,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 25
}
noManMap_4[321] = {
	["index"] = 321,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 25
}
noManMap_4[322] = {
	["index"] = 322,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 25
}
noManMap_4[323] = {
	["index"] = 323,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 25
}
noManMap_4[324] = {
	["index"] = 324,
	["name"] = "decorate_lake_2",
	["x"] = 28,
	["y"] = 25
}
noManMap_4[325] = {
	["index"] = 325,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 25
}
noManMap_4[326] = {
	["index"] = 326,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 26
}
noManMap_4[327] = {
	["index"] = 327,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 26
}
noManMap_4[328] = {
	["index"] = 328,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 26
}
noManMap_4[329] = {
	["index"] = 329,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 26
}
noManMap_4[330] = {
	["index"] = 330,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 26
}
noManMap_4[331] = {
	["index"] = 331,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 26
}
noManMap_4[332] = {
	["index"] = 332,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 26
}
noManMap_4[333] = {
	["index"] = 333,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 26
}
noManMap_4[334] = {
	["index"] = 334,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 26
}
noManMap_4[335] = {
	["index"] = 335,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 26
}
noManMap_4[336] = {
	["index"] = 336,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 26
}
noManMap_4[337] = {
	["index"] = 337,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 26
}
noManMap_4[338] = {
	["index"] = 338,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 26
}
noManMap_4[339] = {
	["index"] = 339,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 26
}
noManMap_4[340] = {
	["index"] = 340,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 26
}
noManMap_4[341] = {
	["index"] = 341,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 26
}
noManMap_4[342] = {
	["index"] = 342,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 27
}
noManMap_4[343] = {
	["index"] = 343,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 27
}
noManMap_4[344] = {
	["index"] = 344,
	["name"] = "decorate_tree_7",
	["x"] = 7,
	["y"] = 27
}
noManMap_4[345] = {
	["index"] = 345,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 27
}
noManMap_4[346] = {
	["index"] = 346,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 27
}
noManMap_4[347] = {
	["index"] = 347,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 27
}
noManMap_4[348] = {
	["index"] = 348,
	["name"] = "decorate_mountain_1",
	["x"] = 13,
	["y"] = 27
}
noManMap_4[349] = {
	["index"] = 349,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 27
}
noManMap_4[350] = {
	["index"] = 350,
	["name"] = "decorate_tree_9",
	["x"] = 17,
	["y"] = 27
}
noManMap_4[351] = {
	["index"] = 351,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 27
}
noManMap_4[352] = {
	["index"] = 352,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 27
}
noManMap_4[353] = {
	["index"] = 353,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 27
}
noManMap_4[354] = {
	["index"] = 354,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 28
}
noManMap_4[355] = {
	["index"] = 355,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 28
}
noManMap_4[356] = {
	["index"] = 356,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 28
}
noManMap_4[357] = {
	["index"] = 357,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 28
}
noManMap_4[358] = {
	["index"] = 358,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 28
}
noManMap_4[359] = {
	["index"] = 359,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 28
}
noManMap_4[360] = {
	["index"] = 360,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 28
}
noManMap_4[361] = {
	["index"] = 361,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 28
}
noManMap_4[362] = {
	["index"] = 362,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 28
}
noManMap_4[363] = {
	["index"] = 363,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 28
}
noManMap_4[364] = {
	["index"] = 364,
	["name"] = "decorate_mountain_2",
	["x"] = 22,
	["y"] = 28
}
noManMap_4[365] = {
	["index"] = 365,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 28
}
noManMap_4[366] = {
	["index"] = 366,
	["name"] = "decorate_tree_6",
	["x"] = 27,
	["y"] = 28
}
noManMap_4[367] = {
	["index"] = 367,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 28
}
noManMap_4[368] = {
	["index"] = 368,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 28
}
noManMap_4[369] = {
	["index"] = 369,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 29
}
noManMap_4[370] = {
	["index"] = 370,
	["name"] = "decorate_tree_9",
	["x"] = 4,
	["y"] = 29
}
noManMap_4[371] = {
	["index"] = 371,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 29
}
noManMap_4[372] = {
	["index"] = 372,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 29
}
noManMap_4[373] = {
	["index"] = 373,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 29
}
noManMap_4[374] = {
	["index"] = 374,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 29
}
noManMap_4[375] = {
	["index"] = 375,
	["name"] = "decorate_tree_7",
	["x"] = 12,
	["y"] = 29
}
noManMap_4[376] = {
	["index"] = 376,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 29
}
noManMap_4[377] = {
	["index"] = 377,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 29
}
noManMap_4[378] = {
	["index"] = 378,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 29
}
noManMap_4[379] = {
	["index"] = 379,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 29
}
noManMap_4[380] = {
	["index"] = 380,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 29
}
noManMap_4[381] = {
	["index"] = 381,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 29
}
noManMap_4[382] = {
	["index"] = 382,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 30
}
noManMap_4[383] = {
	["index"] = 383,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 30
}
noManMap_4[384] = {
	["index"] = 384,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 30
}
noManMap_4[385] = {
	["index"] = 385,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 30
}
noManMap_4[386] = {
	["index"] = 386,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 30
}
noManMap_4[387] = {
	["index"] = 387,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 30
}
noManMap_4[388] = {
	["index"] = 388,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 30
}
noManMap_4[389] = {
	["index"] = 389,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 30
}
noManMap_4[390] = {
	["index"] = 390,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 30
}
noManMap_4[391] = {
	["index"] = 391,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 30
}
noManMap_4[392] = {
	["index"] = 392,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 30
}
