local stringInit = GameDatas.PlayerInitData.stringInit

stringInit["firstIAPRewards"] = {
	["type"] = "firstIAPRewards",
	["value"] = "resource:casinoTokenClass_2:1,special:vipActive_3:1,special:stamina_2:1,special:moveTheCity:1,special:dragonExp_1:1,special:heroBlood_1:1"
}
stringInit["empireRiseDailyTaskRewards"] = {
	["type"] = "empireRiseDailyTaskRewards",
	["value"] = "special:chest_1:2"
}
stringInit["conquerorDailyTaskRewards"] = {
	["type"] = "conquerorDailyTaskRewards",
	["value"] = "resource:coinClass_4:1"
}
stringInit["brotherClubDailyTaskRewards"] = {
	["type"] = "brotherClubDailyTaskRewards",
	["value"] = "resource:coinClass_4:1"
}
stringInit["growUpDailyTaskRewards"] = {
	["type"] = "growUpDailyTaskRewards",
	["value"] = "resource:gemClass_2:1"
}
