local dailyTaskRewards = GameDatas.PlayerInitData.dailyTaskRewards

dailyTaskRewards[0] = {
	["index"] = 0,
	["score"] = 40,
	["rewards"] = "resource:coinClass_3:1;resource:foodClass_3:1"
}
dailyTaskRewards[1] = {
	["index"] = 1,
	["score"] = 80,
	["rewards"] = "special:chest_1:1;special:sweepScroll:2"
}
dailyTaskRewards[2] = {
	["index"] = 2,
	["score"] = 120,
	["rewards"] = "resource:woodClass_3:2;resource:stoneClass_3:2;resource:ironClass_3:2;resource:foodClass_3:2"
}
dailyTaskRewards[3] = {
	["index"] = 3,
	["score"] = 160,
	["rewards"] = "special:chest_2:1;special:sweepScroll:5"
}
dailyTaskRewards[4] = {
	["index"] = 4,
	["score"] = 200,
	["rewards"] = "resource:gemClass_2:1;resource:stoneClass_4:1;resource:ironClass_4:1;resource:foodClass_4:1"
}
