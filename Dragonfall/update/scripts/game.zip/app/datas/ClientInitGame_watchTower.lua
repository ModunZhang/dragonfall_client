local watchTower = GameDatas.ClientInitGame.watchTower

watchTower[1] = {
	["level"] = 1,
	["waringMinute"] = 1.000000
}
watchTower[2] = {
	["level"] = 2,
	["waringMinute"] = 1.000000
}
watchTower[3] = {
	["level"] = 3,
	["waringMinute"] = 1.100000
}
watchTower[4] = {
	["level"] = 4,
	["waringMinute"] = 1.100000
}
watchTower[5] = {
	["level"] = 5,
	["waringMinute"] = 1.400000
}
watchTower[6] = {
	["level"] = 6,
	["waringMinute"] = 1.400000
}
watchTower[7] = {
	["level"] = 7,
	["waringMinute"] = 1.700000
}
watchTower[8] = {
	["level"] = 8,
	["waringMinute"] = 1.700000
}
watchTower[9] = {
	["level"] = 9,
	["waringMinute"] = 2.000000
}
watchTower[10] = {
	["level"] = 10,
	["waringMinute"] = 2.000000
}
watchTower[11] = {
	["level"] = 11,
	["waringMinute"] = 2.300000
}
watchTower[12] = {
	["level"] = 12,
	["waringMinute"] = 2.300000
}
watchTower[13] = {
	["level"] = 13,
	["waringMinute"] = 2.600000
}
watchTower[14] = {
	["level"] = 14,
	["waringMinute"] = 2.600000
}
watchTower[15] = {
	["level"] = 15,
	["waringMinute"] = 2.900000
}
watchTower[16] = {
	["level"] = 16,
	["waringMinute"] = 2.900000
}
watchTower[17] = {
	["level"] = 17,
	["waringMinute"] = 3.200000
}
watchTower[18] = {
	["level"] = 18,
	["waringMinute"] = 3.200000
}
watchTower[19] = {
	["level"] = 19,
	["waringMinute"] = 3.500000
}
watchTower[20] = {
	["level"] = 20,
	["waringMinute"] = 3.500000
}
watchTower[21] = {
	["level"] = 21,
	["waringMinute"] = 3.800000
}
watchTower[22] = {
	["level"] = 22,
	["waringMinute"] = 3.800000
}
watchTower[23] = {
	["level"] = 23,
	["waringMinute"] = 4.100000
}
watchTower[24] = {
	["level"] = 24,
	["waringMinute"] = 4.100000
}
watchTower[25] = {
	["level"] = 25,
	["waringMinute"] = 4.400000
}
watchTower[26] = {
	["level"] = 26,
	["waringMinute"] = 4.400000
}
watchTower[27] = {
	["level"] = 27,
	["waringMinute"] = 4.700000
}
watchTower[28] = {
	["level"] = 28,
	["waringMinute"] = 4.700000
}
watchTower[29] = {
	["level"] = 29,
	["waringMinute"] = 5.000000
}
watchTower[30] = {
	["level"] = 30,
	["waringMinute"] = 5.000000
}
watchTower[31] = {
	["level"] = 31,
	["waringMinute"] = 5.300000
}
watchTower[32] = {
	["level"] = 32,
	["waringMinute"] = 5.300000
}
watchTower[33] = {
	["level"] = 33,
	["waringMinute"] = 5.600000
}
watchTower[34] = {
	["level"] = 34,
	["waringMinute"] = 5.600000
}
watchTower[35] = {
	["level"] = 35,
	["waringMinute"] = 5.900000
}
watchTower[36] = {
	["level"] = 36,
	["waringMinute"] = 5.900000
}
watchTower[37] = {
	["level"] = 37,
	["waringMinute"] = 6.200000
}
watchTower[38] = {
	["level"] = 38,
	["waringMinute"] = 6.200000
}
watchTower[39] = {
	["level"] = 39,
	["waringMinute"] = 6.500000
}
watchTower[40] = {
	["level"] = 40,
	["waringMinute"] = 6.500000
}
