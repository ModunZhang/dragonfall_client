local wood = GameDatas.GemsPayment.wood

wood[1] = {
	["index"] = 1,
	["min"] = 0,
	["max"] = 1000,
	["resource"] = 100,
	["gem"] = 1
}
wood[2] = {
	["index"] = 2,
	["min"] = 1000,
	["max"] = 8000,
	["resource"] = 2000,
	["gem"] = 10
}
wood[3] = {
	["index"] = 3,
	["min"] = 8000,
	["max"] = 40000,
	["resource"] = 10000,
	["gem"] = 40
}
wood[4] = {
	["index"] = 4,
	["min"] = 40000,
	["max"] = 125000,
	["resource"] = 50000,
	["gem"] = 160
}
wood[5] = {
	["index"] = 5,
	["min"] = 125000,
	["max"] = 450000,
	["resource"] = 150000,
	["gem"] = 400
}
wood[6] = {
	["index"] = 6,
	["min"] = 450000,
	["max"] = 1375000,
	["resource"] = 500000,
	["gem"] = 1200
}
wood[7] = {
	["index"] = 7,
	["min"] = 1375000,
	["resource"] = 1500000,
	["gem"] = 3300
}
