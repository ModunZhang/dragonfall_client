local farmer = GameDatas.HouseFunction.farmer

farmer[1] = {
	["level"] = 1,
	["production"] = 160,
	["power"] = 2
}
farmer[2] = {
	["level"] = 2,
	["production"] = 260,
	["power"] = 4
}
farmer[3] = {
	["level"] = 3,
	["production"] = 380,
	["power"] = 6
}
farmer[4] = {
	["level"] = 4,
	["production"] = 520,
	["power"] = 8
}
farmer[5] = {
	["level"] = 5,
	["production"] = 680,
	["power"] = 10
}
farmer[6] = {
	["level"] = 6,
	["production"] = 860,
	["power"] = 15
}
farmer[7] = {
	["level"] = 7,
	["production"] = 1060,
	["power"] = 20
}
farmer[8] = {
	["level"] = 8,
	["production"] = 1280,
	["power"] = 60
}
farmer[9] = {
	["level"] = 9,
	["production"] = 1520,
	["power"] = 130
}
farmer[10] = {
	["level"] = 10,
	["production"] = 1780,
	["power"] = 200
}
farmer[11] = {
	["level"] = 11,
	["production"] = 2060,
	["power"] = 280
}
farmer[12] = {
	["level"] = 12,
	["production"] = 2360,
	["power"] = 360
}
farmer[13] = {
	["level"] = 13,
	["production"] = 2680,
	["power"] = 480
}
farmer[14] = {
	["level"] = 14,
	["production"] = 3020,
	["power"] = 980
}
farmer[15] = {
	["level"] = 15,
	["production"] = 3380,
	["power"] = 1530
}
farmer[16] = {
	["level"] = 16,
	["production"] = 3760,
	["power"] = 2130
}
farmer[17] = {
	["level"] = 17,
	["production"] = 4160,
	["power"] = 3110
}
farmer[18] = {
	["level"] = 18,
	["production"] = 4580,
	["power"] = 3830
}
farmer[19] = {
	["level"] = 19,
	["production"] = 5020,
	["power"] = 4680
}
farmer[20] = {
	["level"] = 20,
	["production"] = 5480,
	["power"] = 5500
}
farmer[21] = {
	["level"] = 21,
	["production"] = 5960,
	["power"] = 7470
}
farmer[22] = {
	["level"] = 22,
	["production"] = 6460,
	["power"] = 8570
}
farmer[23] = {
	["level"] = 23,
	["production"] = 6980,
	["power"] = 9890
}
farmer[24] = {
	["level"] = 24,
	["production"] = 7520,
	["power"] = 11130
}
farmer[25] = {
	["level"] = 25,
	["production"] = 8080,
	["power"] = 15200
}
farmer[26] = {
	["level"] = 26,
	["production"] = 8660,
	["power"] = 16980
}
farmer[27] = {
	["level"] = 27,
	["production"] = 9260,
	["power"] = 19100
}
farmer[28] = {
	["level"] = 28,
	["production"] = 9880,
	["power"] = 21100
}
farmer[29] = {
	["level"] = 29,
	["production"] = 10520,
	["power"] = 30040
}
farmer[30] = {
	["level"] = 30,
	["production"] = 11180,
	["power"] = 34680
}
farmer[31] = {
	["level"] = 31,
	["production"] = 11880,
	["power"] = 40060
}
farmer[32] = {
	["level"] = 32,
	["production"] = 12620,
	["power"] = 45450
}
farmer[33] = {
	["level"] = 33,
	["production"] = 13400,
	["power"] = 62220
}
farmer[34] = {
	["level"] = 34,
	["production"] = 14220,
	["power"] = 69910
}
farmer[35] = {
	["level"] = 35,
	["production"] = 15080,
	["power"] = 78750
}
farmer[36] = {
	["level"] = 36,
	["production"] = 15980,
	["power"] = 87650
}
farmer[37] = {
	["level"] = 37,
	["production"] = 16920,
	["power"] = 117880
}
farmer[38] = {
	["level"] = 38,
	["production"] = 17900,
	["power"] = 130400
}
farmer[39] = {
	["level"] = 39,
	["production"] = 18920,
	["power"] = 144570
}
farmer[40] = {
	["level"] = 40,
	["production"] = 20000,
	["power"] = 159020
}
