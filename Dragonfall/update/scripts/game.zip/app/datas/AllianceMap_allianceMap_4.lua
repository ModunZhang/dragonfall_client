local allianceMap_4 = GameDatas.AllianceMap.allianceMap_4

allianceMap_4[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 1
}
allianceMap_4[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 1
}
allianceMap_4[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 1
}
allianceMap_4[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 1
}
allianceMap_4[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 1
}
allianceMap_4[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 1
}
allianceMap_4[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 1
}
allianceMap_4[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 1
}
allianceMap_4[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 2
}
allianceMap_4[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 2
}
allianceMap_4[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 2
}
allianceMap_4[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 2
}
allianceMap_4[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 2
}
allianceMap_4[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 2
}
allianceMap_4[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 2
}
allianceMap_4[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 2
}
allianceMap_4[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 2
}
allianceMap_4[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 2
}
allianceMap_4[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 2
}
allianceMap_4[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 3
}
allianceMap_4[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 3
}
allianceMap_4[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 3
}
allianceMap_4[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 3
}
allianceMap_4[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 3
}
allianceMap_4[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 3
}
allianceMap_4[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 3
}
allianceMap_4[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 3
}
allianceMap_4[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 3
}
allianceMap_4[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 3
}
allianceMap_4[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 3
}
allianceMap_4[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 3
}
allianceMap_4[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 3
}
allianceMap_4[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 3
}
allianceMap_4[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 3
}
allianceMap_4[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 4
}
allianceMap_4[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 4
}
allianceMap_4[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 4
}
allianceMap_4[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 4
}
allianceMap_4[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 4
}
allianceMap_4[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 4
}
allianceMap_4[40] = {
	["index"] = 40,
	["name"] = "decorate_mountain_2",
	["x"] = 15,
	["y"] = 4
}
allianceMap_4[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 4
}
allianceMap_4[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 4
}
allianceMap_4[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 4
}
allianceMap_4[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 4
}
allianceMap_4[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 4
}
allianceMap_4[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 4
}
allianceMap_4[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 4
}
allianceMap_4[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 4
}
allianceMap_4[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 5
}
allianceMap_4[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 5
}
allianceMap_4[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 5
}
allianceMap_4[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 5
}
allianceMap_4[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 5
}
allianceMap_4[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 5
}
allianceMap_4[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 5
}
allianceMap_4[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 5
}
allianceMap_4[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 5
}
allianceMap_4[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 5
}
allianceMap_4[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 5
}
allianceMap_4[60] = {
	["index"] = 60,
	["name"] = "decorate_lake_2",
	["x"] = 27,
	["y"] = 5
}
allianceMap_4[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 5
}
allianceMap_4[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 6
}
allianceMap_4[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 6
}
allianceMap_4[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 6
}
allianceMap_4[65] = {
	["index"] = 65,
	["name"] = "decorate_lake_1",
	["x"] = 8,
	["y"] = 6
}
allianceMap_4[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 6
}
allianceMap_4[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 6
}
allianceMap_4[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 6
}
allianceMap_4[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 6
}
allianceMap_4[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 7
}
allianceMap_4[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_6",
	["x"] = 4,
	["y"] = 7
}
allianceMap_4[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 7
}
allianceMap_4[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 7
}
allianceMap_4[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 7
}
allianceMap_4[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 8
}
allianceMap_4[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 8
}
allianceMap_4[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_8",
	["x"] = 26,
	["y"] = 8
}
allianceMap_4[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 8
}
allianceMap_4[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 9
}
allianceMap_4[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 10
}
allianceMap_4[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 10
}
allianceMap_4[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 10
}
allianceMap_4[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 10
}
allianceMap_4[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 11
}
allianceMap_4[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 11
}
allianceMap_4[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 11
}
allianceMap_4[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 11
}
allianceMap_4[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 11
}
allianceMap_4[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 11
}
allianceMap_4[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 11
}
allianceMap_4[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 12
}
allianceMap_4[92] = {
	["index"] = 92,
	["name"] = "decorate_mountain_2",
	["x"] = 5,
	["y"] = 12
}
allianceMap_4[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 12
}
allianceMap_4[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 12
}
allianceMap_4[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 12
}
allianceMap_4[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 12
}
allianceMap_4[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 12
}
allianceMap_4[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 12
}
allianceMap_4[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 12
}
allianceMap_4[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 12
}
allianceMap_4[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 13
}
allianceMap_4[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 13
}
allianceMap_4[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 13
}
allianceMap_4[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 13
}
allianceMap_4[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 13
}
allianceMap_4[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 13
}
allianceMap_4[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 13
}
allianceMap_4[108] = {
	["index"] = 108,
	["name"] = "palace",
	["x"] = 13,
	["y"] = 13
}
allianceMap_4[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 13
}
allianceMap_4[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 13
}
allianceMap_4[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 13
}
allianceMap_4[112] = {
	["index"] = 112,
	["name"] = "bloodSpring",
	["x"] = 17,
	["y"] = 13
}
allianceMap_4[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 13
}
allianceMap_4[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 13
}
allianceMap_4[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 13
}
allianceMap_4[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 13
}
allianceMap_4[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 13
}
allianceMap_4[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 14
}
allianceMap_4[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 14
}
allianceMap_4[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 14
}
allianceMap_4[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 14
}
allianceMap_4[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 14
}
allianceMap_4[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
allianceMap_4[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 14
}
allianceMap_4[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 14
}
allianceMap_4[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 14
}
allianceMap_4[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 14
}
allianceMap_4[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 14
}
allianceMap_4[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 14
}
allianceMap_4[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 15
}
allianceMap_4[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 15
}
allianceMap_4[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 15
}
allianceMap_4[133] = {
	["index"] = 133,
	["name"] = "orderHall",
	["x"] = 13,
	["y"] = 15
}
allianceMap_4[134] = {
	["index"] = 134,
	["name"] = "shop",
	["x"] = 17,
	["y"] = 15
}
allianceMap_4[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 15
}
allianceMap_4[136] = {
	["index"] = 136,
	["name"] = "decorate_lake_1",
	["x"] = 28,
	["y"] = 15
}
allianceMap_4[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 15
}
allianceMap_4[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 16
}
allianceMap_4[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 16
}
allianceMap_4[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 16
}
allianceMap_4[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 16
}
allianceMap_4[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 16
}
allianceMap_4[143] = {
	["index"] = 143,
	["name"] = "decorate_mountain_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_4[144] = {
	["index"] = 144,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_4[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 16
}
allianceMap_4[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 16
}
allianceMap_4[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 16
}
allianceMap_4[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 16
}
allianceMap_4[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 16
}
allianceMap_4[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 17
}
allianceMap_4[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 17
}
allianceMap_4[152] = {
	["index"] = 152,
	["name"] = "shrine",
	["x"] = 13,
	["y"] = 17
}
allianceMap_4[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 17
}
allianceMap_4[154] = {
	["index"] = 154,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 17
}
allianceMap_4[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 17
}
allianceMap_4[156] = {
	["index"] = 156,
	["name"] = "watchTower",
	["x"] = 17,
	["y"] = 17
}
allianceMap_4[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 17
}
allianceMap_4[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_3",
	["x"] = 20,
	["y"] = 17
}
allianceMap_4[159] = {
	["index"] = 159,
	["name"] = "decorate_tree_9",
	["x"] = 26,
	["y"] = 17
}
allianceMap_4[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 17
}
allianceMap_4[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 17
}
allianceMap_4[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 18
}
allianceMap_4[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 18
}
allianceMap_4[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 18
}
allianceMap_4[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 18
}
allianceMap_4[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 18
}
allianceMap_4[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 18
}
allianceMap_4[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 18
}
allianceMap_4[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 18
}
allianceMap_4[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 18
}
allianceMap_4[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 18
}
allianceMap_4[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 19
}
allianceMap_4[173] = {
	["index"] = 173,
	["name"] = "decorate_lake_2",
	["x"] = 6,
	["y"] = 19
}
allianceMap_4[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 19
}
allianceMap_4[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 19
}
allianceMap_4[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 19
}
allianceMap_4[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 19
}
allianceMap_4[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 19
}
allianceMap_4[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 20
}
allianceMap_4[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 20
}
allianceMap_4[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 20
}
allianceMap_4[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 20
}
allianceMap_4[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 20
}
allianceMap_4[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 21
}
allianceMap_4[185] = {
	["index"] = 185,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 21
}
allianceMap_4[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 21
}
allianceMap_4[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 21
}
allianceMap_4[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 21
}
allianceMap_4[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 22
}
allianceMap_4[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 22
}
allianceMap_4[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 22
}
allianceMap_4[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 22
}
allianceMap_4[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 22
}
allianceMap_4[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 22
}
allianceMap_4[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 23
}
allianceMap_4[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 23
}
allianceMap_4[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 23
}
allianceMap_4[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 23
}
allianceMap_4[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 24
}
allianceMap_4[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 24
}
allianceMap_4[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 24
}
allianceMap_4[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_8",
	["x"] = 7,
	["y"] = 24
}
allianceMap_4[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 24
}
allianceMap_4[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 24
}
allianceMap_4[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 24
}
allianceMap_4[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 25
}
allianceMap_4[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 25
}
allianceMap_4[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 25
}
allianceMap_4[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 25
}
allianceMap_4[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 25
}
allianceMap_4[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 25
}
allianceMap_4[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 25
}
allianceMap_4[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 25
}
allianceMap_4[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 25
}
allianceMap_4[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 25
}
allianceMap_4[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 25
}
allianceMap_4[217] = {
	["index"] = 217,
	["name"] = "decorate_mountain_2",
	["x"] = 27,
	["y"] = 25
}
allianceMap_4[218] = {
	["index"] = 218,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 25
}
allianceMap_4[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 26
}
allianceMap_4[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 26
}
allianceMap_4[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 26
}
allianceMap_4[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 26
}
allianceMap_4[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 26
}
allianceMap_4[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 26
}
allianceMap_4[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 26
}
allianceMap_4[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 26
}
allianceMap_4[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 26
}
allianceMap_4[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 26
}
allianceMap_4[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 26
}
allianceMap_4[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 26
}
allianceMap_4[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 26
}
allianceMap_4[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 27
}
allianceMap_4[233] = {
	["index"] = 233,
	["name"] = "decorate_lake_1",
	["x"] = 6,
	["y"] = 27
}
allianceMap_4[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 27
}
allianceMap_4[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 27
}
allianceMap_4[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 27
}
allianceMap_4[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 27
}
allianceMap_4[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 27
}
allianceMap_4[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 27
}
allianceMap_4[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 27
}
allianceMap_4[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 27
}
allianceMap_4[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 27
}
allianceMap_4[243] = {
	["index"] = 243,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 27
}
allianceMap_4[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 27
}
allianceMap_4[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 28
}
allianceMap_4[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 28
}
allianceMap_4[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 28
}
allianceMap_4[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 28
}
allianceMap_4[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 28
}
allianceMap_4[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 28
}
allianceMap_4[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 28
}
allianceMap_4[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 28
}
allianceMap_4[253] = {
	["index"] = 253,
	["name"] = "decorate_lake_2",
	["x"] = 18,
	["y"] = 28
}
allianceMap_4[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 28
}
allianceMap_4[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 28
}
allianceMap_4[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 28
}
allianceMap_4[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 28
}
allianceMap_4[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 28
}
allianceMap_4[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 29
}
allianceMap_4[260] = {
	["index"] = 260,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 29
}
allianceMap_4[261] = {
	["index"] = 261,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 29
}
allianceMap_4[262] = {
	["index"] = 262,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 29
}
allianceMap_4[263] = {
	["index"] = 263,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 29
}
allianceMap_4[264] = {
	["index"] = 264,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 29
}
allianceMap_4[265] = {
	["index"] = 265,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 29
}
allianceMap_4[266] = {
	["index"] = 266,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 29
}
