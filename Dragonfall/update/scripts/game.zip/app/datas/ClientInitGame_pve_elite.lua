local pve_elite = GameDatas.ClientInitGame.pve_elite

pve_elite[1] = {
	["index"] = 1,
	["soldiers"] = "lancer_2,8;horseArcher_2,6;sentinel_2,8;swordsman_2,4",
	["rewards"] = "resources,food,5000"
}
pve_elite[2] = {
	["index"] = 2,
	["soldiers"] = "sentinel_2,16;swordsman_2,12;ranger_2,8;crossbowman_2,4",
	["rewards"] = "resources,iron,5000"
}
pve_elite[3] = {
	["index"] = 3,
	["soldiers"] = "ranger_2,16;crossbowman_2,12;catapult_2,2;ballista_2,1",
	["rewards"] = "resources,wood,5000"
}
pve_elite[4] = {
	["index"] = 4,
	["soldiers"] = "ballista_2,4;catapult_2,3;lancer_2,4;horseArcher_2,2",
	["rewards"] = "resources,stone,5000"
}
