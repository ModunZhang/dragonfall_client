local citizen = GameDatas.GemsPayment.citizen

citizen[1] = {
	["index"] = 1,
	["min"] = 0.000000,
	["max"] = 0.200000,
	["resource"] = 0.200000,
	["gem"] = 130
}
citizen[2] = {
	["index"] = 2,
	["min"] = 0.200000,
	["max"] = 0.500000,
	["resource"] = 0.500000,
	["gem"] = 240
}
citizen[3] = {
	["index"] = 3,
	["min"] = 0.500000,
	["max"] = 1.000000,
	["resource"] = 1.000000,
	["gem"] = 400
}
