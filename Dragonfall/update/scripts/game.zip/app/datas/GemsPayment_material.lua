local material = GameDatas.GemsPayment.material

material[1] = {
	["index"] = 1,
	["blueprints"] = 50,
	["tools"] = 50,
	["tiles"] = 50,
	["pulley"] = 50,
	["trainingFigure"] = 100,
	["bowTarget"] = 100,
	["saddle"] = 100,
	["ironPart"] = 100
}
