local workshop = GameDatas.BuildingFunction.workshop

workshop[1] = {
	["level"] = 1,
	["efficiency"] = 0.010000,
	["power"] = 110
}
workshop[2] = {
	["level"] = 2,
	["efficiency"] = 0.020000,
	["power"] = 115
}
workshop[3] = {
	["level"] = 3,
	["efficiency"] = 0.030000,
	["power"] = 120
}
workshop[4] = {
	["level"] = 4,
	["efficiency"] = 0.040000,
	["power"] = 130
}
workshop[5] = {
	["level"] = 5,
	["efficiency"] = 0.050000,
	["power"] = 150
}
workshop[6] = {
	["level"] = 6,
	["efficiency"] = 0.060000,
	["power"] = 160
}
workshop[7] = {
	["level"] = 7,
	["efficiency"] = 0.070000,
	["power"] = 200
}
workshop[8] = {
	["level"] = 8,
	["efficiency"] = 0.080000,
	["power"] = 310
}
workshop[9] = {
	["level"] = 9,
	["efficiency"] = 0.090000,
	["power"] = 580
}
workshop[10] = {
	["level"] = 10,
	["efficiency"] = 0.100000,
	["power"] = 830
}
workshop[11] = {
	["level"] = 11,
	["efficiency"] = 0.110000,
	["power"] = 1110
}
workshop[12] = {
	["level"] = 12,
	["efficiency"] = 0.120000,
	["power"] = 1390
}
workshop[13] = {
	["level"] = 13,
	["efficiency"] = 0.130000,
	["power"] = 1810
}
workshop[14] = {
	["level"] = 14,
	["efficiency"] = 0.140000,
	["power"] = 3590
}
workshop[15] = {
	["level"] = 15,
	["efficiency"] = 0.150000,
	["power"] = 5550
}
workshop[16] = {
	["level"] = 16,
	["efficiency"] = 0.160000,
	["power"] = 7650
}
workshop[17] = {
	["level"] = 17,
	["efficiency"] = 0.170000,
	["power"] = 11150
}
workshop[18] = {
	["level"] = 18,
	["efficiency"] = 0.180000,
	["power"] = 13710
}
workshop[19] = {
	["level"] = 19,
	["efficiency"] = 0.190000,
	["power"] = 16730
}
workshop[20] = {
	["level"] = 20,
	["efficiency"] = 0.200000,
	["power"] = 19610
}
workshop[21] = {
	["level"] = 21,
	["efficiency"] = 0.210000,
	["power"] = 26610
}
workshop[22] = {
	["level"] = 22,
	["efficiency"] = 0.220000,
	["power"] = 30490
}
workshop[23] = {
	["level"] = 23,
	["efficiency"] = 0.230000,
	["power"] = 35170
}
workshop[24] = {
	["level"] = 24,
	["efficiency"] = 0.240000,
	["power"] = 39580
}
workshop[25] = {
	["level"] = 25,
	["efficiency"] = 0.250000,
	["power"] = 54030
}
workshop[26] = {
	["level"] = 26,
	["efficiency"] = 0.260000,
	["power"] = 60300
}
workshop[27] = {
	["level"] = 27,
	["efficiency"] = 0.270000,
	["power"] = 67830
}
workshop[28] = {
	["level"] = 28,
	["efficiency"] = 0.280000,
	["power"] = 74940
}
workshop[29] = {
	["level"] = 29,
	["efficiency"] = 0.290000,
	["power"] = 106630
}
workshop[30] = {
	["level"] = 30,
	["efficiency"] = 0.300000,
	["power"] = 123080
}
workshop[31] = {
	["level"] = 31,
	["efficiency"] = 0.310000,
	["power"] = 142150
}
workshop[32] = {
	["level"] = 32,
	["efficiency"] = 0.320000,
	["power"] = 161260
}
workshop[33] = {
	["level"] = 33,
	["efficiency"] = 0.330000,
	["power"] = 220700
}
workshop[34] = {
	["level"] = 34,
	["efficiency"] = 0.340000,
	["power"] = 247990
}
workshop[35] = {
	["level"] = 35,
	["efficiency"] = 0.350000,
	["power"] = 279330
}
workshop[36] = {
	["level"] = 36,
	["efficiency"] = 0.360000,
	["power"] = 310880
}
workshop[37] = {
	["level"] = 37,
	["efficiency"] = 0.370000,
	["power"] = 418050
}
workshop[38] = {
	["level"] = 38,
	["efficiency"] = 0.380000,
	["power"] = 462450
}
workshop[39] = {
	["level"] = 39,
	["efficiency"] = 0.390000,
	["power"] = 512680
}
workshop[40] = {
	["level"] = 40,
	["efficiency"] = 0.400000,
	["power"] = 563920
}
