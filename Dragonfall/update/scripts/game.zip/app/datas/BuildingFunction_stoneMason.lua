local stoneMason = GameDatas.BuildingFunction.stoneMason

stoneMason[1] = {
	["level"] = 1,
	["houseAdd"] = 1,
	["protection"] = 0.005000,
	["power"] = 40
}
stoneMason[2] = {
	["level"] = 2,
	["houseAdd"] = 1,
	["protection"] = 0.010000,
	["power"] = 45
}
stoneMason[3] = {
	["level"] = 3,
	["houseAdd"] = 1,
	["protection"] = 0.015000,
	["power"] = 50
}
stoneMason[4] = {
	["level"] = 4,
	["houseAdd"] = 1,
	["protection"] = 0.020000,
	["power"] = 60
}
stoneMason[5] = {
	["level"] = 5,
	["houseAdd"] = 1,
	["protection"] = 0.025000,
	["power"] = 70
}
stoneMason[6] = {
	["level"] = 6,
	["houseAdd"] = 1,
	["protection"] = 0.030000,
	["power"] = 80
}
stoneMason[7] = {
	["level"] = 7,
	["houseAdd"] = 1,
	["protection"] = 0.035000,
	["power"] = 100
}
stoneMason[8] = {
	["level"] = 8,
	["houseAdd"] = 2,
	["protection"] = 0.040000,
	["power"] = 170
}
stoneMason[9] = {
	["level"] = 9,
	["houseAdd"] = 2,
	["protection"] = 0.045000,
	["power"] = 320
}
stoneMason[10] = {
	["level"] = 10,
	["houseAdd"] = 2,
	["protection"] = 0.050000,
	["power"] = 470
}
stoneMason[11] = {
	["level"] = 11,
	["houseAdd"] = 2,
	["protection"] = 0.055000,
	["power"] = 640
}
stoneMason[12] = {
	["level"] = 12,
	["houseAdd"] = 2,
	["protection"] = 0.060000,
	["power"] = 800
}
stoneMason[13] = {
	["level"] = 13,
	["houseAdd"] = 2,
	["protection"] = 0.065000,
	["power"] = 1050
}
stoneMason[14] = {
	["level"] = 14,
	["houseAdd"] = 2,
	["protection"] = 0.070000,
	["power"] = 2100
}
stoneMason[15] = {
	["level"] = 15,
	["houseAdd"] = 3,
	["protection"] = 0.075000,
	["power"] = 3260
}
stoneMason[16] = {
	["level"] = 16,
	["houseAdd"] = 3,
	["protection"] = 0.080000,
	["power"] = 4500
}
stoneMason[17] = {
	["level"] = 17,
	["houseAdd"] = 3,
	["protection"] = 0.085000,
	["power"] = 6560
}
stoneMason[18] = {
	["level"] = 18,
	["houseAdd"] = 3,
	["protection"] = 0.090000,
	["power"] = 8070
}
stoneMason[19] = {
	["level"] = 19,
	["houseAdd"] = 3,
	["protection"] = 0.095000,
	["power"] = 9850
}
stoneMason[20] = {
	["level"] = 20,
	["houseAdd"] = 3,
	["protection"] = 0.100000,
	["power"] = 11540
}
stoneMason[21] = {
	["level"] = 21,
	["houseAdd"] = 3,
	["protection"] = 0.105000,
	["power"] = 15670
}
stoneMason[22] = {
	["level"] = 22,
	["houseAdd"] = 4,
	["protection"] = 0.110000,
	["power"] = 17960
}
stoneMason[23] = {
	["level"] = 23,
	["houseAdd"] = 4,
	["protection"] = 0.115000,
	["power"] = 20720
}
stoneMason[24] = {
	["level"] = 24,
	["houseAdd"] = 4,
	["protection"] = 0.120000,
	["power"] = 23320
}
stoneMason[25] = {
	["level"] = 25,
	["houseAdd"] = 4,
	["protection"] = 0.125000,
	["power"] = 31840
}
stoneMason[26] = {
	["level"] = 26,
	["houseAdd"] = 4,
	["protection"] = 0.130000,
	["power"] = 35540
}
stoneMason[27] = {
	["level"] = 27,
	["houseAdd"] = 4,
	["protection"] = 0.135000,
	["power"] = 39980
}
stoneMason[28] = {
	["level"] = 28,
	["houseAdd"] = 4,
	["protection"] = 0.140000,
	["power"] = 44180
}
stoneMason[29] = {
	["level"] = 29,
	["houseAdd"] = 5,
	["protection"] = 0.145000,
	["power"] = 62870
}
stoneMason[30] = {
	["level"] = 30,
	["houseAdd"] = 5,
	["protection"] = 0.150000,
	["power"] = 72570
}
stoneMason[31] = {
	["level"] = 31,
	["houseAdd"] = 5,
	["protection"] = 0.155000,
	["power"] = 83810
}
stoneMason[32] = {
	["level"] = 32,
	["houseAdd"] = 5,
	["protection"] = 0.160000,
	["power"] = 95090
}
stoneMason[33] = {
	["level"] = 33,
	["houseAdd"] = 5,
	["protection"] = 0.165000,
	["power"] = 130140
}
stoneMason[34] = {
	["level"] = 34,
	["houseAdd"] = 5,
	["protection"] = 0.170000,
	["power"] = 146230
}
stoneMason[35] = {
	["level"] = 35,
	["houseAdd"] = 5,
	["protection"] = 0.175000,
	["power"] = 164710
}
stoneMason[36] = {
	["level"] = 36,
	["houseAdd"] = 6,
	["protection"] = 0.180000,
	["power"] = 183320
}
stoneMason[37] = {
	["level"] = 37,
	["houseAdd"] = 6,
	["protection"] = 0.185000,
	["power"] = 246520
}
stoneMason[38] = {
	["level"] = 38,
	["houseAdd"] = 6,
	["protection"] = 0.190000,
	["power"] = 272710
}
stoneMason[39] = {
	["level"] = 39,
	["houseAdd"] = 6,
	["protection"] = 0.195000,
	["power"] = 302330
}
stoneMason[40] = {
	["level"] = 40,
	["houseAdd"] = 6,
	["protection"] = 0.200000,
	["power"] = 332550
}
