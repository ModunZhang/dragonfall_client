local allianceMap_3 = GameDatas.AllianceMap.allianceMap_3

allianceMap_3[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 1
}
allianceMap_3[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 1
}
allianceMap_3[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 1
}
allianceMap_3[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 1
}
allianceMap_3[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 1
}
allianceMap_3[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 1
}
allianceMap_3[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 1
}
allianceMap_3[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 1
}
allianceMap_3[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 1
}
allianceMap_3[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 1
}
allianceMap_3[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 2
}
allianceMap_3[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 2
}
allianceMap_3[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 2
}
allianceMap_3[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 2
}
allianceMap_3[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 2
}
allianceMap_3[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 2
}
allianceMap_3[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 2
}
allianceMap_3[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 2
}
allianceMap_3[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 2
}
allianceMap_3[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 2
}
allianceMap_3[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 2
}
allianceMap_3[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_9",
	["x"] = 2,
	["y"] = 3
}
allianceMap_3[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 3
}
allianceMap_3[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 3
}
allianceMap_3[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 3
}
allianceMap_3[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 3
}
allianceMap_3[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 3
}
allianceMap_3[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 3
}
allianceMap_3[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 3
}
allianceMap_3[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 3
}
allianceMap_3[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 3
}
allianceMap_3[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 3
}
allianceMap_3[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 3
}
allianceMap_3[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 3
}
allianceMap_3[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 4
}
allianceMap_3[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 4
}
allianceMap_3[36] = {
	["index"] = 36,
	["name"] = "decorate_lake_2",
	["x"] = 13,
	["y"] = 4
}
allianceMap_3[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 4
}
allianceMap_3[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 4
}
allianceMap_3[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 4
}
allianceMap_3[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 4
}
allianceMap_3[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 4
}
allianceMap_3[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 4
}
allianceMap_3[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 4
}
allianceMap_3[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 4
}
allianceMap_3[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 5
}
allianceMap_3[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 5
}
allianceMap_3[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 5
}
allianceMap_3[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 5
}
allianceMap_3[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 5
}
allianceMap_3[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 5
}
allianceMap_3[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 5
}
allianceMap_3[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 5
}
allianceMap_3[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 5
}
allianceMap_3[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 6
}
allianceMap_3[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 6
}
allianceMap_3[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 6
}
allianceMap_3[57] = {
	["index"] = 57,
	["name"] = "decorate_mountain_1",
	["x"] = 7,
	["y"] = 6
}
allianceMap_3[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 6
}
allianceMap_3[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 6
}
allianceMap_3[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 6
}
allianceMap_3[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 6
}
allianceMap_3[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 6
}
allianceMap_3[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 7
}
allianceMap_3[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 7
}
allianceMap_3[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 7
}
allianceMap_3[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 7
}
allianceMap_3[67] = {
	["index"] = 67,
	["name"] = "decorate_mountain_2",
	["x"] = 26,
	["y"] = 7
}
allianceMap_3[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 7
}
allianceMap_3[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 7
}
allianceMap_3[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 8
}
allianceMap_3[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 8
}
allianceMap_3[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 8
}
allianceMap_3[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 8
}
allianceMap_3[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 8
}
allianceMap_3[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 8
}
allianceMap_3[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 8
}
allianceMap_3[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 8
}
allianceMap_3[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 9
}
allianceMap_3[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 9
}
allianceMap_3[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_8",
	["x"] = 7,
	["y"] = 9
}
allianceMap_3[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 9
}
allianceMap_3[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 9
}
allianceMap_3[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 9
}
allianceMap_3[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 9
}
allianceMap_3[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 10
}
allianceMap_3[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 10
}
allianceMap_3[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 10
}
allianceMap_3[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 10
}
allianceMap_3[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 10
}
allianceMap_3[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 11
}
allianceMap_3[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 11
}
allianceMap_3[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 11
}
allianceMap_3[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 11
}
allianceMap_3[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 11
}
allianceMap_3[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 12
}
allianceMap_3[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 12
}
allianceMap_3[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 12
}
allianceMap_3[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 12
}
allianceMap_3[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 12
}
allianceMap_3[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 12
}
allianceMap_3[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 12
}
allianceMap_3[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 13
}
allianceMap_3[103] = {
	["index"] = 103,
	["name"] = "decorate_mountain_2",
	["x"] = 5,
	["y"] = 13
}
allianceMap_3[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 13
}
allianceMap_3[105] = {
	["index"] = 105,
	["name"] = "palace",
	["x"] = 13,
	["y"] = 13
}
allianceMap_3[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 13
}
allianceMap_3[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 13
}
allianceMap_3[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 13
}
allianceMap_3[109] = {
	["index"] = 109,
	["name"] = "bloodSpring",
	["x"] = 17,
	["y"] = 13
}
allianceMap_3[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 13
}
allianceMap_3[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_3",
	["x"] = 20,
	["y"] = 13
}
allianceMap_3[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 13
}
allianceMap_3[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_8",
	["x"] = 27,
	["y"] = 13
}
allianceMap_3[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 13
}
allianceMap_3[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 14
}
allianceMap_3[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 14
}
allianceMap_3[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 14
}
allianceMap_3[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 14
}
allianceMap_3[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 14
}
allianceMap_3[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
allianceMap_3[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 14
}
allianceMap_3[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 14
}
allianceMap_3[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 14
}
allianceMap_3[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 14
}
allianceMap_3[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 14
}
allianceMap_3[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 14
}
allianceMap_3[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 15
}
allianceMap_3[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 15
}
allianceMap_3[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 15
}
allianceMap_3[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 15
}
allianceMap_3[131] = {
	["index"] = 131,
	["name"] = "orderHall",
	["x"] = 13,
	["y"] = 15
}
allianceMap_3[132] = {
	["index"] = 132,
	["name"] = "shop",
	["x"] = 17,
	["y"] = 15
}
allianceMap_3[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 15
}
allianceMap_3[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 15
}
allianceMap_3[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 15
}
allianceMap_3[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 15
}
allianceMap_3[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 15
}
allianceMap_3[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 16
}
allianceMap_3[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 16
}
allianceMap_3[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 16
}
allianceMap_3[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 16
}
allianceMap_3[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 16
}
allianceMap_3[143] = {
	["index"] = 143,
	["name"] = "decorate_lake_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_3[144] = {
	["index"] = 144,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_3[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 16
}
allianceMap_3[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 16
}
allianceMap_3[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 17
}
allianceMap_3[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 17
}
allianceMap_3[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 17
}
allianceMap_3[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 17
}
allianceMap_3[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 17
}
allianceMap_3[152] = {
	["index"] = 152,
	["name"] = "shrine",
	["x"] = 13,
	["y"] = 17
}
allianceMap_3[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
allianceMap_3[154] = {
	["index"] = 154,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 17
}
allianceMap_3[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 17
}
allianceMap_3[156] = {
	["index"] = 156,
	["name"] = "watchTower",
	["x"] = 17,
	["y"] = 17
}
allianceMap_3[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 17
}
allianceMap_3[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 17
}
allianceMap_3[159] = {
	["index"] = 159,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 18
}
allianceMap_3[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 18
}
allianceMap_3[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 18
}
allianceMap_3[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 18
}
allianceMap_3[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 18
}
allianceMap_3[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 18
}
allianceMap_3[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 18
}
allianceMap_3[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 18
}
allianceMap_3[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 18
}
allianceMap_3[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 18
}
allianceMap_3[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 19
}
allianceMap_3[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 19
}
allianceMap_3[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 19
}
allianceMap_3[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 19
}
allianceMap_3[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 19
}
allianceMap_3[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 19
}
allianceMap_3[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 19
}
allianceMap_3[176] = {
	["index"] = 176,
	["name"] = "decorate_lake_2",
	["x"] = 27,
	["y"] = 19
}
allianceMap_3[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 19
}
allianceMap_3[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 20
}
allianceMap_3[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 20
}
allianceMap_3[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 20
}
allianceMap_3[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 20
}
allianceMap_3[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 20
}
allianceMap_3[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 20
}
allianceMap_3[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 20
}
allianceMap_3[185] = {
	["index"] = 185,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 21
}
allianceMap_3[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 21
}
allianceMap_3[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 21
}
allianceMap_3[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 21
}
allianceMap_3[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 21
}
allianceMap_3[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 22
}
allianceMap_3[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 22
}
allianceMap_3[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 22
}
allianceMap_3[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 22
}
allianceMap_3[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 23
}
allianceMap_3[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 23
}
allianceMap_3[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 23
}
allianceMap_3[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 23
}
allianceMap_3[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 24
}
allianceMap_3[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 24
}
allianceMap_3[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 24
}
allianceMap_3[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 24
}
allianceMap_3[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 24
}
allianceMap_3[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 24
}
allianceMap_3[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 25
}
allianceMap_3[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 25
}
allianceMap_3[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 25
}
allianceMap_3[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 25
}
allianceMap_3[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 25
}
allianceMap_3[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 25
}
allianceMap_3[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 25
}
allianceMap_3[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 26
}
allianceMap_3[212] = {
	["index"] = 212,
	["name"] = "decorate_mountain_1",
	["x"] = 6,
	["y"] = 26
}
allianceMap_3[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 26
}
allianceMap_3[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 26
}
allianceMap_3[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 26
}
allianceMap_3[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 26
}
allianceMap_3[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 26
}
allianceMap_3[218] = {
	["index"] = 218,
	["name"] = "decorate_mountain_1",
	["x"] = 28,
	["y"] = 26
}
allianceMap_3[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 26
}
allianceMap_3[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 27
}
allianceMap_3[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 27
}
allianceMap_3[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 27
}
allianceMap_3[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 27
}
allianceMap_3[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 27
}
allianceMap_3[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 27
}
allianceMap_3[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 27
}
allianceMap_3[227] = {
	["index"] = 227,
	["name"] = "decorate_lake_2",
	["x"] = 12,
	["y"] = 27
}
allianceMap_3[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 27
}
allianceMap_3[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 27
}
allianceMap_3[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 27
}
allianceMap_3[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 27
}
allianceMap_3[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 27
}
allianceMap_3[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_6",
	["x"] = 24,
	["y"] = 27
}
allianceMap_3[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 27
}
allianceMap_3[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 27
}
allianceMap_3[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 27
}
allianceMap_3[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 27
}
allianceMap_3[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 28
}
allianceMap_3[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 28
}
allianceMap_3[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 28
}
allianceMap_3[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 28
}
allianceMap_3[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 28
}
allianceMap_3[243] = {
	["index"] = 243,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 28
}
allianceMap_3[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 28
}
allianceMap_3[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 28
}
allianceMap_3[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 28
}
allianceMap_3[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 28
}
allianceMap_3[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 28
}
allianceMap_3[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 28
}
allianceMap_3[250] = {
	["index"] = 250,
	["name"] = "decorate_mountain_2",
	["x"] = 20,
	["y"] = 28
}
allianceMap_3[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 28
}
allianceMap_3[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 28
}
allianceMap_3[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 28
}
allianceMap_3[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 28
}
allianceMap_3[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 29
}
allianceMap_3[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 29
}
allianceMap_3[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 29
}
allianceMap_3[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 29
}
allianceMap_3[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 29
}
allianceMap_3[260] = {
	["index"] = 260,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 29
}
allianceMap_3[261] = {
	["index"] = 261,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 29
}
allianceMap_3[262] = {
	["index"] = 262,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 29
}
allianceMap_3[263] = {
	["index"] = 263,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 29
}
allianceMap_3[264] = {
	["index"] = 264,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 29
}
allianceMap_3[265] = {
	["index"] = 265,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 29
}
allianceMap_3[266] = {
	["index"] = 266,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 29
}
allianceMap_3[267] = {
	["index"] = 267,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 29
}
allianceMap_3[268] = {
	["index"] = 268,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 29
}
