local stringInit = GameDatas.AllianceInitData.stringInit

