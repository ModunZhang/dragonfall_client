local day14 = GameDatas.Activities.day14

day14[1] = {
	["day"] = 1,
	["rewards"] = "soldiers:swordsman:50"
}
day14[2] = {
	["day"] = 2,
	["rewards"] = "soldiers:ranger:100"
}
day14[3] = {
	["day"] = 3,
	["rewards"] = "soldiers:sentinel:150"
}
day14[4] = {
	["day"] = 4,
	["rewards"] = "soldiers:swordsman:200"
}
day14[5] = {
	["day"] = 5,
	["rewards"] = "soldiers:ranger:250"
}
day14[6] = {
	["day"] = 6,
	["rewards"] = "soldiers:sentinel:300"
}
day14[7] = {
	["day"] = 7,
	["rewards"] = "soldiers:crossbowman:350"
}
day14[8] = {
	["day"] = 8,
	["rewards"] = "soldiers:swordsman:400"
}
day14[9] = {
	["day"] = 9,
	["rewards"] = "soldiers:ranger:450"
}
day14[10] = {
	["day"] = 10,
	["rewards"] = "soldiers:sentinel:500"
}
day14[11] = {
	["day"] = 11,
	["rewards"] = "soldiers:crossbowman:550"
}
day14[12] = {
	["day"] = 12,
	["rewards"] = "soldiers:lancer:300"
}
day14[13] = {
	["day"] = 13,
	["rewards"] = "soldiers:horseArcher:350"
}
day14[14] = {
	["day"] = 14,
	["rewards"] = "soldiers:catapult:200"
}
