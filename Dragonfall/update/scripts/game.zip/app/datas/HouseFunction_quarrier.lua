local quarrier = GameDatas.HouseFunction.quarrier

quarrier[1] = {
	["level"] = 1,
	["production"] = 160,
	["power"] = 2
}
quarrier[2] = {
	["level"] = 2,
	["production"] = 260,
	["power"] = 4
}
quarrier[3] = {
	["level"] = 3,
	["production"] = 380,
	["power"] = 6
}
quarrier[4] = {
	["level"] = 4,
	["production"] = 520,
	["power"] = 8
}
quarrier[5] = {
	["level"] = 5,
	["production"] = 680,
	["power"] = 10
}
quarrier[6] = {
	["level"] = 6,
	["production"] = 860,
	["power"] = 15
}
quarrier[7] = {
	["level"] = 7,
	["production"] = 1060,
	["power"] = 30
}
quarrier[8] = {
	["level"] = 8,
	["production"] = 1280,
	["power"] = 70
}
quarrier[9] = {
	["level"] = 9,
	["production"] = 1520,
	["power"] = 150
}
quarrier[10] = {
	["level"] = 10,
	["production"] = 1780,
	["power"] = 240
}
quarrier[11] = {
	["level"] = 11,
	["production"] = 2060,
	["power"] = 330
}
quarrier[12] = {
	["level"] = 12,
	["production"] = 2360,
	["power"] = 430
}
quarrier[13] = {
	["level"] = 13,
	["production"] = 2680,
	["power"] = 570
}
quarrier[14] = {
	["level"] = 14,
	["production"] = 3020,
	["power"] = 1160
}
quarrier[15] = {
	["level"] = 15,
	["production"] = 3380,
	["power"] = 1810
}
quarrier[16] = {
	["level"] = 16,
	["production"] = 3760,
	["power"] = 2510
}
quarrier[17] = {
	["level"] = 17,
	["production"] = 4160,
	["power"] = 3680
}
quarrier[18] = {
	["level"] = 18,
	["production"] = 4580,
	["power"] = 4530
}
quarrier[19] = {
	["level"] = 19,
	["production"] = 5020,
	["power"] = 5540
}
quarrier[20] = {
	["level"] = 20,
	["production"] = 5480,
	["power"] = 6500
}
quarrier[21] = {
	["level"] = 21,
	["production"] = 5960,
	["power"] = 8830
}
quarrier[22] = {
	["level"] = 22,
	["production"] = 6460,
	["power"] = 10120
}
quarrier[23] = {
	["level"] = 23,
	["production"] = 6980,
	["power"] = 11690
}
quarrier[24] = {
	["level"] = 24,
	["production"] = 7520,
	["power"] = 13150
}
quarrier[25] = {
	["level"] = 25,
	["production"] = 8080,
	["power"] = 17970
}
quarrier[26] = {
	["level"] = 26,
	["production"] = 8660,
	["power"] = 20060
}
quarrier[27] = {
	["level"] = 27,
	["production"] = 9260,
	["power"] = 22570
}
quarrier[28] = {
	["level"] = 28,
	["production"] = 9880,
	["power"] = 24940
}
quarrier[29] = {
	["level"] = 29,
	["production"] = 10520,
	["power"] = 35510
}
quarrier[30] = {
	["level"] = 30,
	["production"] = 11180,
	["power"] = 40990
}
quarrier[31] = {
	["level"] = 31,
	["production"] = 11880,
	["power"] = 47340
}
quarrier[32] = {
	["level"] = 32,
	["production"] = 12620,
	["power"] = 53720
}
quarrier[33] = {
	["level"] = 33,
	["production"] = 13400,
	["power"] = 73530
}
quarrier[34] = {
	["level"] = 34,
	["production"] = 14220,
	["power"] = 82620
}
quarrier[35] = {
	["level"] = 35,
	["production"] = 15080,
	["power"] = 93070
}
quarrier[36] = {
	["level"] = 36,
	["production"] = 15980,
	["power"] = 103590
}
quarrier[37] = {
	["level"] = 37,
	["production"] = 16920,
	["power"] = 139310
}
quarrier[38] = {
	["level"] = 38,
	["production"] = 17900,
	["power"] = 154110
}
quarrier[39] = {
	["level"] = 39,
	["production"] = 18920,
	["power"] = 170850
}
quarrier[40] = {
	["level"] = 40,
	["production"] = 20000,
	["power"] = 187930
}
