local noManMap_2 = GameDatas.NoManMap.noManMap_2

noManMap_2[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_9",
	["x"] = 1,
	["y"] = 1
}
noManMap_2[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 1
}
noManMap_2[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 1
}
noManMap_2[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 1
}
noManMap_2[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 1
}
noManMap_2[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 2
}
noManMap_2[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 2
}
noManMap_2[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 2
}
noManMap_2[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 2
}
noManMap_2[9] = {
	["index"] = 9,
	["name"] = "decorate_lake_1",
	["x"] = 4,
	["y"] = 3
}
noManMap_2[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 3
}
noManMap_2[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 3
}
noManMap_2[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 3
}
noManMap_2[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 3
}
noManMap_2[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 3
}
noManMap_2[15] = {
	["index"] = 15,
	["name"] = "decorate_mountain_1",
	["x"] = 19,
	["y"] = 3
}
noManMap_2[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 4
}
noManMap_2[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 4
}
noManMap_2[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 4
}
noManMap_2[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 4
}
noManMap_2[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 4
}
noManMap_2[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 4
}
noManMap_2[22] = {
	["index"] = 22,
	["name"] = "decorate_mountain_2",
	["x"] = 14,
	["y"] = 4
}
noManMap_2[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 4
}
noManMap_2[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 5
}
noManMap_2[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 5
}
noManMap_2[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 5
}
noManMap_2[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 5
}
noManMap_2[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 5
}
noManMap_2[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 5
}
noManMap_2[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 6
}
noManMap_2[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 6
}
noManMap_2[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 6
}
noManMap_2[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 6
}
noManMap_2[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 6
}
noManMap_2[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 7
}
noManMap_2[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 7
}
noManMap_2[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 7
}
noManMap_2[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 7
}
noManMap_2[39] = {
	["index"] = 39,
	["name"] = "decorate_lake_2",
	["x"] = 8,
	["y"] = 7
}
noManMap_2[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_6",
	["x"] = 10,
	["y"] = 7
}
noManMap_2[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 7
}
noManMap_2[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 7
}
noManMap_2[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 7
}
noManMap_2[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 7
}
noManMap_2[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 7
}
noManMap_2[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 8
}
noManMap_2[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 8
}
noManMap_2[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 8
}
noManMap_2[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 8
}
noManMap_2[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 8
}
noManMap_2[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 8
}
noManMap_2[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 8
}
noManMap_2[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 8
}
noManMap_2[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 9
}
noManMap_2[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 9
}
noManMap_2[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 9
}
noManMap_2[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 9
}
noManMap_2[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 9
}
noManMap_2[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 9
}
noManMap_2[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 9
}
noManMap_2[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 10
}
noManMap_2[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_6",
	["x"] = 13,
	["y"] = 10
}
noManMap_2[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 10
}
noManMap_2[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 10
}
noManMap_2[65] = {
	["index"] = 65,
	["name"] = "decorate_mountain_2",
	["x"] = 19,
	["y"] = 10
}
noManMap_2[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 11
}
noManMap_2[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 11
}
noManMap_2[68] = {
	["index"] = 68,
	["name"] = "decorate_mountain_1",
	["x"] = 3,
	["y"] = 12
}
noManMap_2[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 12
}
noManMap_2[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 12
}
noManMap_2[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_8",
	["x"] = 6,
	["y"] = 12
}
noManMap_2[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 12
}
noManMap_2[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 12
}
noManMap_2[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 12
}
noManMap_2[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 12
}
noManMap_2[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 13
}
noManMap_2[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 13
}
noManMap_2[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 13
}
noManMap_2[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 13
}
noManMap_2[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 13
}
noManMap_2[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 13
}
noManMap_2[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 13
}
noManMap_2[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 13
}
noManMap_2[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 14
}
noManMap_2[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 14
}
noManMap_2[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 14
}
noManMap_2[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 14
}
noManMap_2[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 14
}
noManMap_2[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 14
}
noManMap_2[90] = {
	["index"] = 90,
	["name"] = "decorate_lake_1",
	["x"] = 16,
	["y"] = 14
}
noManMap_2[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
noManMap_2[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 14
}
noManMap_2[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 15
}
noManMap_2[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 15
}
noManMap_2[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 15
}
noManMap_2[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 15
}
noManMap_2[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 15
}
noManMap_2[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 15
}
noManMap_2[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 15
}
noManMap_2[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 15
}
noManMap_2[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 16
}
noManMap_2[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 16
}
noManMap_2[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_7",
	["x"] = 10,
	["y"] = 16
}
noManMap_2[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 16
}
noManMap_2[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 16
}
noManMap_2[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 16
}
noManMap_2[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 16
}
noManMap_2[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 17
}
noManMap_2[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_9",
	["x"] = 2,
	["y"] = 17
}
noManMap_2[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 17
}
noManMap_2[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
noManMap_2[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 17
}
noManMap_2[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 17
}
noManMap_2[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_5",
	["x"] = 18,
	["y"] = 17
}
noManMap_2[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 18
}
noManMap_2[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 18
}
noManMap_2[117] = {
	["index"] = 117,
	["name"] = "decorate_mountain_2",
	["x"] = 7,
	["y"] = 18
}
noManMap_2[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 18
}
noManMap_2[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 18
}
noManMap_2[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 18
}
noManMap_2[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 18
}
noManMap_2[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 18
}
noManMap_2[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 18
}
noManMap_2[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 18
}
noManMap_2[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 18
}
noManMap_2[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 19
}
noManMap_2[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 19
}
noManMap_2[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 19
}
noManMap_2[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 19
}
