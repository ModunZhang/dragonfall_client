local noManMap_2 = GameDatas.NoManMap.noManMap_2

noManMap_2[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_4",
	["x"] = 0,
	["y"] = 0
}
noManMap_2[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 0
}
noManMap_2[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 0
}
noManMap_2[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 0
}
noManMap_2[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 0
}
noManMap_2[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 0
}
noManMap_2[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 0
}
noManMap_2[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 0
}
noManMap_2[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 0
}
noManMap_2[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 0
}
noManMap_2[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 0
}
noManMap_2[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 0
}
noManMap_2[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_4",
	["x"] = 30,
	["y"] = 0
}
noManMap_2[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_1",
	["x"] = 0,
	["y"] = 1
}
noManMap_2[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 1
}
noManMap_2[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 1
}
noManMap_2[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 1
}
noManMap_2[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 1
}
noManMap_2[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 1
}
noManMap_2[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 1
}
noManMap_2[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 1
}
noManMap_2[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 1
}
noManMap_2[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 1
}
noManMap_2[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 2
}
noManMap_2[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 2
}
noManMap_2[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 2
}
noManMap_2[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 2
}
noManMap_2[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 2
}
noManMap_2[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 2
}
noManMap_2[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 2
}
noManMap_2[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 2
}
noManMap_2[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 2
}
noManMap_2[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 3
}
noManMap_2[33] = {
	["index"] = 33,
	["name"] = "decorate_lake_1",
	["x"] = 4,
	["y"] = 3
}
noManMap_2[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 3
}
noManMap_2[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 3
}
noManMap_2[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 3
}
noManMap_2[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 3
}
noManMap_2[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 3
}
noManMap_2[39] = {
	["index"] = 39,
	["name"] = "decorate_mountain_1",
	["x"] = 19,
	["y"] = 3
}
noManMap_2[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 3
}
noManMap_2[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 4
}
noManMap_2[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 4
}
noManMap_2[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 4
}
noManMap_2[44] = {
	["index"] = 44,
	["name"] = "decorate_mountain_2",
	["x"] = 9,
	["y"] = 4
}
noManMap_2[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 4
}
noManMap_2[46] = {
	["index"] = 46,
	["name"] = "decorate_mountain_2",
	["x"] = 14,
	["y"] = 4
}
noManMap_2[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 4
}
noManMap_2[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 4
}
noManMap_2[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 4
}
noManMap_2[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 4
}
noManMap_2[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 4
}
noManMap_2[52] = {
	["index"] = 52,
	["name"] = "decorate_mountain_2",
	["x"] = 28,
	["y"] = 4
}
noManMap_2[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 4
}
noManMap_2[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 5
}
noManMap_2[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 5
}
noManMap_2[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 5
}
noManMap_2[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 5
}
noManMap_2[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 5
}
noManMap_2[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 5
}
noManMap_2[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 5
}
noManMap_2[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 5
}
noManMap_2[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 5
}
noManMap_2[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 5
}
noManMap_2[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 5
}
noManMap_2[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 5
}
noManMap_2[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 5
}
noManMap_2[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_4",
	["x"] = 0,
	["y"] = 6
}
noManMap_2[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 6
}
noManMap_2[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 6
}
noManMap_2[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 6
}
noManMap_2[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 6
}
noManMap_2[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_8",
	["x"] = 14,
	["y"] = 6
}
noManMap_2[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 6
}
noManMap_2[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 6
}
noManMap_2[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 6
}
noManMap_2[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 6
}
noManMap_2[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 6
}
noManMap_2[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 6
}
noManMap_2[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_6",
	["x"] = 29,
	["y"] = 6
}
noManMap_2[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 6
}
noManMap_2[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 7
}
noManMap_2[82] = {
	["index"] = 82,
	["name"] = "decorate_lake_2",
	["x"] = 5,
	["y"] = 7
}
noManMap_2[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 7
}
noManMap_2[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 7
}
noManMap_2[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 7
}
noManMap_2[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 7
}
noManMap_2[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 7
}
noManMap_2[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 7
}
noManMap_2[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 7
}
noManMap_2[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 7
}
noManMap_2[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 7
}
noManMap_2[92] = {
	["index"] = 92,
	["name"] = "decorate_lake_1",
	["x"] = 26,
	["y"] = 7
}
noManMap_2[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 7
}
noManMap_2[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 8
}
noManMap_2[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 8
}
noManMap_2[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 8
}
noManMap_2[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 8
}
noManMap_2[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 8
}
noManMap_2[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 8
}
noManMap_2[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 8
}
noManMap_2[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 8
}
noManMap_2[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 8
}
noManMap_2[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 9
}
noManMap_2[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 9
}
noManMap_2[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 9
}
noManMap_2[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 9
}
noManMap_2[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 9
}
noManMap_2[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 9
}
noManMap_2[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 9
}
noManMap_2[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 9
}
noManMap_2[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 9
}
noManMap_2[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_7",
	["x"] = 24,
	["y"] = 9
}
noManMap_2[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 9
}
noManMap_2[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 9
}
noManMap_2[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 9
}
noManMap_2[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 10
}
noManMap_2[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 10
}
noManMap_2[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 10
}
noManMap_2[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 10
}
noManMap_2[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 10
}
noManMap_2[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 10
}
noManMap_2[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 10
}
noManMap_2[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_7",
	["x"] = 13,
	["y"] = 10
}
noManMap_2[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 10
}
noManMap_2[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 10
}
noManMap_2[126] = {
	["index"] = 126,
	["name"] = "decorate_mountain_2",
	["x"] = 19,
	["y"] = 10
}
noManMap_2[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 10
}
noManMap_2[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 10
}
noManMap_2[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 10
}
noManMap_2[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 10
}
noManMap_2[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 10
}
noManMap_2[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 11
}
noManMap_2[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 11
}
noManMap_2[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 11
}
noManMap_2[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 11
}
noManMap_2[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 11
}
noManMap_2[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 11
}
noManMap_2[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 11
}
noManMap_2[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 11
}
noManMap_2[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 11
}
noManMap_2[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 11
}
noManMap_2[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 11
}
noManMap_2[143] = {
	["index"] = 143,
	["name"] = "decorate_tree_1",
	["x"] = 0,
	["y"] = 12
}
noManMap_2[144] = {
	["index"] = 144,
	["name"] = "decorate_mountain_1",
	["x"] = 3,
	["y"] = 12
}
noManMap_2[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 12
}
noManMap_2[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 12
}
noManMap_2[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_9",
	["x"] = 6,
	["y"] = 12
}
noManMap_2[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 12
}
noManMap_2[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 12
}
noManMap_2[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 12
}
noManMap_2[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 12
}
noManMap_2[152] = {
	["index"] = 152,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 12
}
noManMap_2[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 12
}
noManMap_2[154] = {
	["index"] = 154,
	["name"] = "decorate_mountain_2",
	["x"] = 28,
	["y"] = 12
}
noManMap_2[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 12
}
noManMap_2[156] = {
	["index"] = 156,
	["name"] = "decorate_tree_4",
	["x"] = 30,
	["y"] = 12
}
noManMap_2[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 13
}
noManMap_2[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 13
}
noManMap_2[159] = {
	["index"] = 159,
	["name"] = "decorate_lake_2",
	["x"] = 10,
	["y"] = 13
}
noManMap_2[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 13
}
noManMap_2[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 13
}
noManMap_2[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 13
}
noManMap_2[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 13
}
noManMap_2[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 13
}
noManMap_2[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 13
}
noManMap_2[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 13
}
noManMap_2[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 13
}
noManMap_2[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 13
}
noManMap_2[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 14
}
noManMap_2[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 14
}
noManMap_2[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 14
}
noManMap_2[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 14
}
noManMap_2[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 14
}
noManMap_2[174] = {
	["index"] = 174,
	["name"] = "decorate_lake_1",
	["x"] = 16,
	["y"] = 14
}
noManMap_2[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
noManMap_2[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 14
}
noManMap_2[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 14
}
noManMap_2[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 14
}
noManMap_2[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_4",
	["x"] = 0,
	["y"] = 15
}
noManMap_2[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 15
}
noManMap_2[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 15
}
noManMap_2[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 15
}
noManMap_2[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 15
}
noManMap_2[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 15
}
noManMap_2[185] = {
	["index"] = 185,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 15
}
noManMap_2[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 15
}
noManMap_2[187] = {
	["index"] = 187,
	["name"] = "decorate_mountain_1",
	["x"] = 22,
	["y"] = 15
}
noManMap_2[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 15
}
noManMap_2[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 15
}
noManMap_2[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 15
}
noManMap_2[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_1",
	["x"] = 0,
	["y"] = 16
}
noManMap_2[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 16
}
noManMap_2[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 16
}
noManMap_2[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 16
}
noManMap_2[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_8",
	["x"] = 10,
	["y"] = 16
}
noManMap_2[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 16
}
noManMap_2[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 16
}
noManMap_2[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 16
}
noManMap_2[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 16
}
noManMap_2[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_1",
	["x"] = 20,
	["y"] = 16
}
noManMap_2[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 16
}
noManMap_2[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 16
}
noManMap_2[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 16
}
noManMap_2[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 16
}
noManMap_2[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 16
}
noManMap_2[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 17
}
noManMap_2[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 17
}
noManMap_2[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 17
}
noManMap_2[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 17
}
noManMap_2[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 17
}
noManMap_2[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_6",
	["x"] = 18,
	["y"] = 17
}
noManMap_2[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 17
}
noManMap_2[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 17
}
noManMap_2[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 17
}
noManMap_2[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 17
}
noManMap_2[216] = {
	["index"] = 216,
	["name"] = "decorate_lake_2",
	["x"] = 29,
	["y"] = 17
}
noManMap_2[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 18
}
noManMap_2[218] = {
	["index"] = 218,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 18
}
noManMap_2[219] = {
	["index"] = 219,
	["name"] = "decorate_mountain_2",
	["x"] = 7,
	["y"] = 18
}
noManMap_2[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 18
}
noManMap_2[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 18
}
noManMap_2[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 18
}
noManMap_2[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 18
}
noManMap_2[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 18
}
noManMap_2[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 18
}
noManMap_2[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 18
}
noManMap_2[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 18
}
noManMap_2[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 18
}
noManMap_2[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 18
}
noManMap_2[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 19
}
noManMap_2[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 19
}
noManMap_2[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 19
}
noManMap_2[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 19
}
noManMap_2[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 19
}
noManMap_2[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 19
}
noManMap_2[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 19
}
noManMap_2[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 19
}
noManMap_2[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 20
}
noManMap_2[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 20
}
noManMap_2[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 20
}
noManMap_2[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 20
}
noManMap_2[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 20
}
noManMap_2[243] = {
	["index"] = 243,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 20
}
noManMap_2[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 20
}
noManMap_2[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 20
}
noManMap_2[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 20
}
noManMap_2[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 20
}
noManMap_2[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_1",
	["x"] = 0,
	["y"] = 21
}
noManMap_2[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 21
}
noManMap_2[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 21
}
noManMap_2[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 21
}
noManMap_2[252] = {
	["index"] = 252,
	["name"] = "decorate_mountain_1",
	["x"] = 11,
	["y"] = 21
}
noManMap_2[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 21
}
noManMap_2[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 21
}
noManMap_2[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 21
}
noManMap_2[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 21
}
noManMap_2[257] = {
	["index"] = 257,
	["name"] = "decorate_lake_2",
	["x"] = 20,
	["y"] = 21
}
noManMap_2[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 21
}
noManMap_2[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 21
}
noManMap_2[260] = {
	["index"] = 260,
	["name"] = "decorate_mountain_1",
	["x"] = 26,
	["y"] = 21
}
noManMap_2[261] = {
	["index"] = 261,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 21
}
noManMap_2[262] = {
	["index"] = 262,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 21
}
noManMap_2[263] = {
	["index"] = 263,
	["name"] = "decorate_tree_9",
	["x"] = 29,
	["y"] = 21
}
noManMap_2[264] = {
	["index"] = 264,
	["name"] = "decorate_tree_3",
	["x"] = 30,
	["y"] = 21
}
noManMap_2[265] = {
	["index"] = 265,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 22
}
noManMap_2[266] = {
	["index"] = 266,
	["name"] = "decorate_tree_9",
	["x"] = 6,
	["y"] = 22
}
noManMap_2[267] = {
	["index"] = 267,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 22
}
noManMap_2[268] = {
	["index"] = 268,
	["name"] = "decorate_tree_7",
	["x"] = 13,
	["y"] = 22
}
noManMap_2[269] = {
	["index"] = 269,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 22
}
noManMap_2[270] = {
	["index"] = 270,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 22
}
noManMap_2[271] = {
	["index"] = 271,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 22
}
noManMap_2[272] = {
	["index"] = 272,
	["name"] = "decorate_tree_3",
	["x"] = 20,
	["y"] = 22
}
noManMap_2[273] = {
	["index"] = 273,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 22
}
noManMap_2[274] = {
	["index"] = 274,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 22
}
noManMap_2[275] = {
	["index"] = 275,
	["name"] = "decorate_mountain_2",
	["x"] = 4,
	["y"] = 23
}
noManMap_2[276] = {
	["index"] = 276,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 23
}
noManMap_2[277] = {
	["index"] = 277,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 23
}
noManMap_2[278] = {
	["index"] = 278,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 23
}
noManMap_2[279] = {
	["index"] = 279,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 23
}
noManMap_2[280] = {
	["index"] = 280,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 23
}
noManMap_2[281] = {
	["index"] = 281,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 23
}
noManMap_2[282] = {
	["index"] = 282,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 23
}
noManMap_2[283] = {
	["index"] = 283,
	["name"] = "decorate_tree_8",
	["x"] = 22,
	["y"] = 23
}
noManMap_2[284] = {
	["index"] = 284,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 23
}
noManMap_2[285] = {
	["index"] = 285,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 23
}
noManMap_2[286] = {
	["index"] = 286,
	["name"] = "decorate_tree_4",
	["x"] = 0,
	["y"] = 24
}
noManMap_2[287] = {
	["index"] = 287,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 24
}
noManMap_2[288] = {
	["index"] = 288,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 24
}
noManMap_2[289] = {
	["index"] = 289,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 24
}
noManMap_2[290] = {
	["index"] = 290,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 24
}
noManMap_2[291] = {
	["index"] = 291,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 24
}
noManMap_2[292] = {
	["index"] = 292,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 24
}
noManMap_2[293] = {
	["index"] = 293,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 24
}
noManMap_2[294] = {
	["index"] = 294,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 24
}
noManMap_2[295] = {
	["index"] = 295,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 24
}
noManMap_2[296] = {
	["index"] = 296,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 24
}
noManMap_2[297] = {
	["index"] = 297,
	["name"] = "decorate_tree_2",
	["x"] = 0,
	["y"] = 25
}
noManMap_2[298] = {
	["index"] = 298,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 25
}
noManMap_2[299] = {
	["index"] = 299,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 25
}
noManMap_2[300] = {
	["index"] = 300,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 25
}
noManMap_2[301] = {
	["index"] = 301,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 25
}
noManMap_2[302] = {
	["index"] = 302,
	["name"] = "decorate_lake_1",
	["x"] = 17,
	["y"] = 25
}
noManMap_2[303] = {
	["index"] = 303,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 25
}
noManMap_2[304] = {
	["index"] = 304,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 25
}
noManMap_2[305] = {
	["index"] = 305,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 25
}
noManMap_2[306] = {
	["index"] = 306,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 25
}
noManMap_2[307] = {
	["index"] = 307,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 25
}
noManMap_2[308] = {
	["index"] = 308,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 26
}
noManMap_2[309] = {
	["index"] = 309,
	["name"] = "decorate_mountain_2",
	["x"] = 10,
	["y"] = 26
}
noManMap_2[310] = {
	["index"] = 310,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 26
}
noManMap_2[311] = {
	["index"] = 311,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 26
}
noManMap_2[312] = {
	["index"] = 312,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 26
}
noManMap_2[313] = {
	["index"] = 313,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 26
}
noManMap_2[314] = {
	["index"] = 314,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 26
}
noManMap_2[315] = {
	["index"] = 315,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 26
}
noManMap_2[316] = {
	["index"] = 316,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 27
}
noManMap_2[317] = {
	["index"] = 317,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 27
}
noManMap_2[318] = {
	["index"] = 318,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 27
}
noManMap_2[319] = {
	["index"] = 319,
	["name"] = "decorate_lake_1",
	["x"] = 6,
	["y"] = 27
}
noManMap_2[320] = {
	["index"] = 320,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 27
}
noManMap_2[321] = {
	["index"] = 321,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 27
}
noManMap_2[322] = {
	["index"] = 322,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 27
}
noManMap_2[323] = {
	["index"] = 323,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 27
}
noManMap_2[324] = {
	["index"] = 324,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 27
}
noManMap_2[325] = {
	["index"] = 325,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 27
}
noManMap_2[326] = {
	["index"] = 326,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 27
}
noManMap_2[327] = {
	["index"] = 327,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 27
}
noManMap_2[328] = {
	["index"] = 328,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 27
}
noManMap_2[329] = {
	["index"] = 329,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 27
}
noManMap_2[330] = {
	["index"] = 330,
	["name"] = "decorate_tree_1",
	["x"] = 30,
	["y"] = 27
}
noManMap_2[331] = {
	["index"] = 331,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 28
}
noManMap_2[332] = {
	["index"] = 332,
	["name"] = "decorate_tree_7",
	["x"] = 2,
	["y"] = 28
}
noManMap_2[333] = {
	["index"] = 333,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 28
}
noManMap_2[334] = {
	["index"] = 334,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 28
}
noManMap_2[335] = {
	["index"] = 335,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 28
}
noManMap_2[336] = {
	["index"] = 336,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 28
}
noManMap_2[337] = {
	["index"] = 337,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 28
}
noManMap_2[338] = {
	["index"] = 338,
	["name"] = "decorate_mountain_2",
	["x"] = 20,
	["y"] = 28
}
noManMap_2[339] = {
	["index"] = 339,
	["name"] = "decorate_tree_6",
	["x"] = 23,
	["y"] = 28
}
noManMap_2[340] = {
	["index"] = 340,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 28
}
noManMap_2[341] = {
	["index"] = 341,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 28
}
noManMap_2[342] = {
	["index"] = 342,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 29
}
noManMap_2[343] = {
	["index"] = 343,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 29
}
noManMap_2[344] = {
	["index"] = 344,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 29
}
noManMap_2[345] = {
	["index"] = 345,
	["name"] = "decorate_mountain_1",
	["x"] = 14,
	["y"] = 29
}
noManMap_2[346] = {
	["index"] = 346,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 29
}
noManMap_2[347] = {
	["index"] = 347,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 29
}
noManMap_2[348] = {
	["index"] = 348,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 29
}
noManMap_2[349] = {
	["index"] = 349,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 29
}
noManMap_2[350] = {
	["index"] = 350,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 29
}
noManMap_2[351] = {
	["index"] = 351,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 29
}
noManMap_2[352] = {
	["index"] = 352,
	["name"] = "decorate_lake_2",
	["x"] = 28,
	["y"] = 29
}
noManMap_2[353] = {
	["index"] = 353,
	["name"] = "decorate_tree_3",
	["x"] = 0,
	["y"] = 30
}
noManMap_2[354] = {
	["index"] = 354,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 30
}
noManMap_2[355] = {
	["index"] = 355,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 30
}
noManMap_2[356] = {
	["index"] = 356,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 30
}
noManMap_2[357] = {
	["index"] = 357,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 30
}
noManMap_2[358] = {
	["index"] = 358,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 30
}
noManMap_2[359] = {
	["index"] = 359,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 30
}
noManMap_2[360] = {
	["index"] = 360,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 30
}
noManMap_2[361] = {
	["index"] = 361,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 30
}
noManMap_2[362] = {
	["index"] = 362,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 30
}
noManMap_2[363] = {
	["index"] = 363,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 30
}
noManMap_2[364] = {
	["index"] = 364,
	["name"] = "decorate_tree_2",
	["x"] = 30,
	["y"] = 30
}
