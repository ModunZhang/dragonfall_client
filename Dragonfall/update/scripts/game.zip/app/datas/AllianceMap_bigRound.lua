local bigRound = GameDatas.AllianceMap.bigRound

bigRound[0] = {
	["index"] = 0,
	["locationFromX"] = 1,
	["locationFromY"] = 1
}
bigRound[1] = {
	["index"] = 1,
	["locationFromX"] = 12,
	["locationFromY"] = 1
}
bigRound[2] = {
	["index"] = 2,
	["locationFromX"] = 23,
	["locationFromY"] = 1
}
bigRound[3] = {
	["index"] = 3,
	["locationFromX"] = 1,
	["locationFromY"] = 12
}
bigRound[4] = {
	["index"] = 4,
	["locationFromX"] = 23,
	["locationFromY"] = 12
}
bigRound[5] = {
	["index"] = 5,
	["locationFromX"] = 1,
	["locationFromY"] = 23
}
bigRound[6] = {
	["index"] = 6,
	["locationFromX"] = 12,
	["locationFromY"] = 23
}
bigRound[7] = {
	["index"] = 7,
	["locationFromX"] = 23,
	["locationFromY"] = 23
}
