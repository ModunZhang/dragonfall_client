local miner = GameDatas.HouseReturn.miner

miner[0] = {
	["level"] = 0,
	["wood"] = 0,
	["stone"] = 0,
	["iron"] = 0,
	["citizen"] = 0
}
miner[1] = {
	["level"] = 1,
	["wood"] = 95,
	["stone"] = 95,
	["iron"] = 48,
	["citizen"] = 10
}
miner[2] = {
	["level"] = 2,
	["wood"] = 228,
	["stone"] = 228,
	["iron"] = 114,
	["citizen"] = 16
}
miner[3] = {
	["level"] = 3,
	["wood"] = 456,
	["stone"] = 456,
	["iron"] = 228,
	["citizen"] = 22
}
miner[4] = {
	["level"] = 4,
	["wood"] = 684,
	["stone"] = 684,
	["iron"] = 342,
	["citizen"] = 32
}
miner[5] = {
	["level"] = 5,
	["wood"] = 912,
	["stone"] = 912,
	["iron"] = 456,
	["citizen"] = 44
}
miner[6] = {
	["level"] = 6,
	["wood"] = 1140,
	["stone"] = 1140,
	["iron"] = 570,
	["citizen"] = 58
}
miner[7] = {
	["level"] = 7,
	["wood"] = 1368,
	["stone"] = 1368,
	["iron"] = 684,
	["citizen"] = 76
}
miner[8] = {
	["level"] = 8,
	["wood"] = 1779,
	["stone"] = 1779,
	["iron"] = 890,
	["citizen"] = 94
}
miner[9] = {
	["level"] = 9,
	["wood"] = 4378,
	["stone"] = 4378,
	["iron"] = 2189,
	["citizen"] = 116
}
miner[10] = {
	["level"] = 10,
	["wood"] = 7935,
	["stone"] = 7935,
	["iron"] = 3968,
	["citizen"] = 140
}
miner[11] = {
	["level"] = 11,
	["wood"] = 20137,
	["stone"] = 20137,
	["iron"] = 10069,
	["citizen"] = 166
}
miner[12] = {
	["level"] = 12,
	["wood"] = 29549,
	["stone"] = 29549,
	["iron"] = 14775,
	["citizen"] = 196
}
miner[13] = {
	["level"] = 13,
	["wood"] = 41150,
	["stone"] = 41150,
	["iron"] = 20575,
	["citizen"] = 226
}
miner[14] = {
	["level"] = 14,
	["wood"] = 55158,
	["stone"] = 55158,
	["iron"] = 27579,
	["citizen"] = 260
}
miner[15] = {
	["level"] = 15,
	["wood"] = 71793,
	["stone"] = 71793,
	["iron"] = 35897,
	["citizen"] = 296
}
miner[16] = {
	["level"] = 16,
	["wood"] = 106092,
	["stone"] = 106092,
	["iron"] = 53046,
	["citizen"] = 334
}
miner[17] = {
	["level"] = 17,
	["wood"] = 130272,
	["stone"] = 130272,
	["iron"] = 65136,
	["citizen"] = 376
}
miner[18] = {
	["level"] = 18,
	["wood"] = 156557,
	["stone"] = 156557,
	["iron"] = 78279,
	["citizen"] = 418
}
miner[19] = {
	["level"] = 19,
	["wood"] = 183220,
	["stone"] = 183220,
	["iron"] = 91610,
	["citizen"] = 464
}
miner[20] = {
	["level"] = 20,
	["wood"] = 208533,
	["stone"] = 208533,
	["iron"] = 104267,
	["citizen"] = 512
}
miner[21] = {
	["level"] = 21,
	["wood"] = 350280,
	["stone"] = 350280,
	["iron"] = 175140,
	["citizen"] = 562
}
miner[22] = {
	["level"] = 22,
	["wood"] = 388292,
	["stone"] = 388292,
	["iron"] = 194146,
	["citizen"] = 616
}
miner[23] = {
	["level"] = 23,
	["wood"] = 421964,
	["stone"] = 421964,
	["iron"] = 210982,
	["citizen"] = 670
}
miner[24] = {
	["level"] = 24,
	["wood"] = 488367,
	["stone"] = 488367,
	["iron"] = 244184,
	["citizen"] = 728
}
miner[25] = {
	["level"] = 25,
	["wood"] = 553581,
	["stone"] = 553581,
	["iron"] = 276791,
	["citizen"] = 788
}
miner[26] = {
	["level"] = 26,
	["wood"] = 947830,
	["stone"] = 947830,
	["iron"] = 473915,
	["citizen"] = 850
}
miner[27] = {
	["level"] = 27,
	["wood"] = 1064675,
	["stone"] = 1064675,
	["iron"] = 532338,
	["citizen"] = 916
}
miner[28] = {
	["level"] = 28,
	["wood"] = 1182333,
	["stone"] = 1182333,
	["iron"] = 591167,
	["citizen"] = 982
}
miner[29] = {
	["level"] = 29,
	["wood"] = 1299824,
	["stone"] = 1299824,
	["iron"] = 649912,
	["citizen"] = 1052
}
miner[30] = {
	["level"] = 30,
	["wood"] = 1416170,
	["stone"] = 1416170,
	["iron"] = 708085,
	["citizen"] = 1124
}
miner[31] = {
	["level"] = 31,
	["wood"] = 2307076,
	["stone"] = 2307076,
	["iron"] = 1153538,
	["citizen"] = 1198
}
miner[32] = {
	["level"] = 32,
	["wood"] = 2519660,
	["stone"] = 2519660,
	["iron"] = 1259830,
	["citizen"] = 1276
}
miner[33] = {
	["level"] = 33,
	["wood"] = 2736140,
	["stone"] = 2736140,
	["iron"] = 1368070,
	["citizen"] = 1354
}
miner[34] = {
	["level"] = 34,
	["wood"] = 2955830,
	["stone"] = 2955830,
	["iron"] = 1477915,
	["citizen"] = 1436
}
miner[35] = {
	["level"] = 35,
	["wood"] = 3178042,
	["stone"] = 3178042,
	["iron"] = 1589021,
	["citizen"] = 1520
}
miner[36] = {
	["level"] = 36,
	["wood"] = 4939613,
	["stone"] = 4939613,
	["iron"] = 2469807,
	["citizen"] = 1606
}
miner[37] = {
	["level"] = 37,
	["wood"] = 5327111,
	["stone"] = 5327111,
	["iron"] = 2663556,
	["citizen"] = 1696
}
miner[38] = {
	["level"] = 38,
	["wood"] = 5725687,
	["stone"] = 5725687,
	["iron"] = 2862844,
	["citizen"] = 1786
}
miner[39] = {
	["level"] = 39,
	["wood"] = 6134983,
	["stone"] = 6134983,
	["iron"] = 3067492,
	["citizen"] = 1880
}
miner[40] = {
	["level"] = 40,
	["wood"] = 8942000,
	["stone"] = 8942000,
	["iron"] = 4471000,
	["citizen"] = 2000
}
