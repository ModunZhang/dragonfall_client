local ruins = GameDatas.ClientInitGame.ruins

ruins[1] = {
	["index"] = 1,
	["building_type"] = "ruins",
	["x"] = 22,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[2] = {
	["index"] = 2,
	["building_type"] = "ruins",
	["x"] = 25,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[3] = {
	["index"] = 3,
	["building_type"] = "ruins",
	["x"] = 28,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[4] = {
	["index"] = 4,
	["building_type"] = "ruins",
	["x"] = 32,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[5] = {
	["index"] = 5,
	["building_type"] = "ruins",
	["x"] = 35,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[6] = {
	["index"] = 6,
	["building_type"] = "ruins",
	["x"] = 38,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[7] = {
	["index"] = 7,
	["building_type"] = "ruins",
	["x"] = 42,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[8] = {
	["index"] = 8,
	["building_type"] = "ruins",
	["x"] = 45,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[9] = {
	["index"] = 9,
	["building_type"] = "ruins",
	["x"] = 48,
	["y"] = 2,
	["w"] = 3,
	["h"] = 3
}
ruins[10] = {
	["index"] = 10,
	["building_type"] = "ruins",
	["x"] = 12,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[11] = {
	["index"] = 11,
	["building_type"] = "ruins",
	["x"] = 15,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[12] = {
	["index"] = 12,
	["building_type"] = "ruins",
	["x"] = 18,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[13] = {
	["index"] = 13,
	["building_type"] = "ruins",
	["x"] = 22,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[14] = {
	["index"] = 14,
	["building_type"] = "ruins",
	["x"] = 25,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[15] = {
	["index"] = 15,
	["building_type"] = "ruins",
	["x"] = 28,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[16] = {
	["index"] = 16,
	["building_type"] = "ruins",
	["x"] = 32,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[17] = {
	["index"] = 17,
	["building_type"] = "ruins",
	["x"] = 35,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[18] = {
	["index"] = 18,
	["building_type"] = "ruins",
	["x"] = 38,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[19] = {
	["index"] = 19,
	["building_type"] = "ruins",
	["x"] = 42,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[20] = {
	["index"] = 20,
	["building_type"] = "ruins",
	["x"] = 45,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[21] = {
	["index"] = 21,
	["building_type"] = "ruins",
	["x"] = 48,
	["y"] = 12,
	["w"] = 3,
	["h"] = 3
}
ruins[22] = {
	["index"] = 22,
	["building_type"] = "ruins",
	["x"] = 2,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[23] = {
	["index"] = 23,
	["building_type"] = "ruins",
	["x"] = 5,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[24] = {
	["index"] = 24,
	["building_type"] = "ruins",
	["x"] = 8,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[25] = {
	["index"] = 25,
	["building_type"] = "ruins",
	["x"] = 12,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[26] = {
	["index"] = 26,
	["building_type"] = "ruins",
	["x"] = 15,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[27] = {
	["index"] = 27,
	["building_type"] = "ruins",
	["x"] = 18,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[28] = {
	["index"] = 28,
	["building_type"] = "ruins",
	["x"] = 22,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[29] = {
	["index"] = 29,
	["building_type"] = "ruins",
	["x"] = 25,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[30] = {
	["index"] = 30,
	["building_type"] = "ruins",
	["x"] = 28,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[31] = {
	["index"] = 31,
	["building_type"] = "ruins",
	["x"] = 32,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[32] = {
	["index"] = 32,
	["building_type"] = "ruins",
	["x"] = 35,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[33] = {
	["index"] = 33,
	["building_type"] = "ruins",
	["x"] = 38,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[34] = {
	["index"] = 34,
	["building_type"] = "ruins",
	["x"] = 42,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[35] = {
	["index"] = 35,
	["building_type"] = "ruins",
	["x"] = 45,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[36] = {
	["index"] = 36,
	["building_type"] = "ruins",
	["x"] = 48,
	["y"] = 22,
	["w"] = 3,
	["h"] = 3
}
ruins[37] = {
	["index"] = 37,
	["building_type"] = "ruins",
	["x"] = 2,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[38] = {
	["index"] = 38,
	["building_type"] = "ruins",
	["x"] = 5,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[39] = {
	["index"] = 39,
	["building_type"] = "ruins",
	["x"] = 8,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[40] = {
	["index"] = 40,
	["building_type"] = "ruins",
	["x"] = 12,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[41] = {
	["index"] = 41,
	["building_type"] = "ruins",
	["x"] = 15,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[42] = {
	["index"] = 42,
	["building_type"] = "ruins",
	["x"] = 18,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[43] = {
	["index"] = 43,
	["building_type"] = "ruins",
	["x"] = 22,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[44] = {
	["index"] = 44,
	["building_type"] = "ruins",
	["x"] = 25,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[45] = {
	["index"] = 45,
	["building_type"] = "ruins",
	["x"] = 28,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[46] = {
	["index"] = 46,
	["building_type"] = "ruins",
	["x"] = 32,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[47] = {
	["index"] = 47,
	["building_type"] = "ruins",
	["x"] = 35,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[48] = {
	["index"] = 48,
	["building_type"] = "ruins",
	["x"] = 38,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[49] = {
	["index"] = 49,
	["building_type"] = "ruins",
	["x"] = 42,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[50] = {
	["index"] = 50,
	["building_type"] = "ruins",
	["x"] = 45,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[51] = {
	["index"] = 51,
	["building_type"] = "ruins",
	["x"] = 48,
	["y"] = 32,
	["w"] = 3,
	["h"] = 3
}
ruins[52] = {
	["index"] = 52,
	["building_type"] = "ruins",
	["x"] = 2,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[53] = {
	["index"] = 53,
	["building_type"] = "ruins",
	["x"] = 5,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[54] = {
	["index"] = 54,
	["building_type"] = "ruins",
	["x"] = 8,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[55] = {
	["index"] = 55,
	["building_type"] = "ruins",
	["x"] = 12,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[56] = {
	["index"] = 56,
	["building_type"] = "ruins",
	["x"] = 15,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[57] = {
	["index"] = 57,
	["building_type"] = "ruins",
	["x"] = 18,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[58] = {
	["index"] = 58,
	["building_type"] = "ruins",
	["x"] = 22,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[59] = {
	["index"] = 59,
	["building_type"] = "ruins",
	["x"] = 25,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[60] = {
	["index"] = 60,
	["building_type"] = "ruins",
	["x"] = 28,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[61] = {
	["index"] = 61,
	["building_type"] = "ruins",
	["x"] = 32,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[62] = {
	["index"] = 62,
	["building_type"] = "ruins",
	["x"] = 35,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[63] = {
	["index"] = 63,
	["building_type"] = "ruins",
	["x"] = 38,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[64] = {
	["index"] = 64,
	["building_type"] = "ruins",
	["x"] = 42,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[65] = {
	["index"] = 65,
	["building_type"] = "ruins",
	["x"] = 45,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
ruins[66] = {
	["index"] = 66,
	["building_type"] = "ruins",
	["x"] = 48,
	["y"] = 42,
	["w"] = 3,
	["h"] = 3
}
