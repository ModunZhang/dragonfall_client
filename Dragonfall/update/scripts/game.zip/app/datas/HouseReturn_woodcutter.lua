local woodcutter = GameDatas.HouseReturn.woodcutter

woodcutter[0] = {
	["level"] = 0,
	["wood"] = 0,
	["stone"] = 0,
	["iron"] = 0,
	["citizen"] = 0
}
woodcutter[1] = {
	["level"] = 1,
	["wood"] = 43,
	["stone"] = 107,
	["iron"] = 64,
	["citizen"] = 10
}
woodcutter[2] = {
	["level"] = 2,
	["wood"] = 103,
	["stone"] = 256,
	["iron"] = 153,
	["citizen"] = 16
}
woodcutter[3] = {
	["level"] = 3,
	["wood"] = 205,
	["stone"] = 511,
	["iron"] = 306,
	["citizen"] = 22
}
woodcutter[4] = {
	["level"] = 4,
	["wood"] = 306,
	["stone"] = 765,
	["iron"] = 459,
	["citizen"] = 32
}
woodcutter[5] = {
	["level"] = 5,
	["wood"] = 409,
	["stone"] = 1021,
	["iron"] = 612,
	["citizen"] = 44
}
woodcutter[6] = {
	["level"] = 6,
	["wood"] = 510,
	["stone"] = 1275,
	["iron"] = 765,
	["citizen"] = 58
}
woodcutter[7] = {
	["level"] = 7,
	["wood"] = 612,
	["stone"] = 1530,
	["iron"] = 918,
	["citizen"] = 76
}
woodcutter[8] = {
	["level"] = 8,
	["wood"] = 796,
	["stone"] = 1990,
	["iron"] = 1194,
	["citizen"] = 94
}
woodcutter[9] = {
	["level"] = 9,
	["wood"] = 1959,
	["stone"] = 4896,
	["iron"] = 2938,
	["citizen"] = 116
}
woodcutter[10] = {
	["level"] = 10,
	["wood"] = 3550,
	["stone"] = 8874,
	["iron"] = 5325,
	["citizen"] = 140
}
woodcutter[11] = {
	["level"] = 11,
	["wood"] = 9009,
	["stone"] = 22522,
	["iron"] = 13513,
	["citizen"] = 166
}
woodcutter[12] = {
	["level"] = 12,
	["wood"] = 13220,
	["stone"] = 33048,
	["iron"] = 19829,
	["citizen"] = 196
}
woodcutter[13] = {
	["level"] = 13,
	["wood"] = 18409,
	["stone"] = 46023,
	["iron"] = 27614,
	["citizen"] = 226
}
woodcutter[14] = {
	["level"] = 14,
	["wood"] = 24676,
	["stone"] = 61690,
	["iron"] = 37014,
	["citizen"] = 260
}
woodcutter[15] = {
	["level"] = 15,
	["wood"] = 32118,
	["stone"] = 80295,
	["iron"] = 48177,
	["citizen"] = 296
}
woodcutter[16] = {
	["level"] = 16,
	["wood"] = 47041,
	["stone"] = 117603,
	["iron"] = 70562,
	["citizen"] = 334
}
woodcutter[17] = {
	["level"] = 17,
	["wood"] = 57648,
	["stone"] = 144120,
	["iron"] = 86472,
	["citizen"] = 376
}
woodcutter[18] = {
	["level"] = 18,
	["wood"] = 69092,
	["stone"] = 172728,
	["iron"] = 103637,
	["citizen"] = 418
}
woodcutter[19] = {
	["level"] = 19,
	["wood"] = 80493,
	["stone"] = 201233,
	["iron"] = 120740,
	["citizen"] = 464
}
woodcutter[20] = {
	["level"] = 20,
	["wood"] = 90976,
	["stone"] = 227438,
	["iron"] = 136463,
	["citizen"] = 512
}
woodcutter[21] = {
	["level"] = 21,
	["wood"] = 153126,
	["stone"] = 382813,
	["iron"] = 229688,
	["citizen"] = 562
}
woodcutter[22] = {
	["level"] = 22,
	["wood"] = 168341,
	["stone"] = 420852,
	["iron"] = 252512,
	["citizen"] = 616
}
woodcutter[23] = {
	["level"] = 23,
	["wood"] = 180984,
	["stone"] = 452460,
	["iron"] = 271476,
	["citizen"] = 670
}
woodcutter[24] = {
	["level"] = 24,
	["wood"] = 207533,
	["stone"] = 518832,
	["iron"] = 311299,
	["citizen"] = 728
}
woodcutter[25] = {
	["level"] = 25,
	["wood"] = 232708,
	["stone"] = 581769,
	["iron"] = 349061,
	["citizen"] = 788
}
woodcutter[26] = {
	["level"] = 26,
	["wood"] = 404135,
	["stone"] = 1010336,
	["iron"] = 606202,
	["citizen"] = 850
}
woodcutter[27] = {
	["level"] = 27,
	["wood"] = 450408,
	["stone"] = 1126018,
	["iron"] = 675611,
	["citizen"] = 916
}
woodcutter[28] = {
	["level"] = 28,
	["wood"] = 495886,
	["stone"] = 1239714,
	["iron"] = 743829,
	["citizen"] = 982
}
woodcutter[29] = {
	["level"] = 29,
	["wood"] = 540027,
	["stone"] = 1350066,
	["iron"] = 810040,
	["citizen"] = 1052
}
woodcutter[30] = {
	["level"] = 30,
	["wood"] = 582287,
	["stone"] = 1455716,
	["iron"] = 873430,
	["citizen"] = 1124
}
woodcutter[31] = {
	["level"] = 31,
	["wood"] = 969587,
	["stone"] = 2423967,
	["iron"] = 1454380,
	["citizen"] = 1198
}
woodcutter[32] = {
	["level"] = 32,
	["wood"] = 1051848,
	["stone"] = 2629620,
	["iron"] = 1577772,
	["citizen"] = 1276
}
woodcutter[33] = {
	["level"] = 33,
	["wood"] = 1134168,
	["stone"] = 2835420,
	["iron"] = 1701252,
	["citizen"] = 1354
}
woodcutter[34] = {
	["level"] = 34,
	["wood"] = 1216135,
	["stone"] = 3040336,
	["iron"] = 1824202,
	["citizen"] = 1436
}
woodcutter[35] = {
	["level"] = 35,
	["wood"] = 1297335,
	["stone"] = 3243336,
	["iron"] = 1946002,
	["citizen"] = 1520
}
woodcutter[36] = {
	["level"] = 36,
	["wood"] = 2065196,
	["stone"] = 5162988,
	["iron"] = 3097793,
	["citizen"] = 1606
}
woodcutter[37] = {
	["level"] = 37,
	["wood"] = 2216234,
	["stone"] = 5540584,
	["iron"] = 3324351,
	["citizen"] = 1696
}
woodcutter[38] = {
	["level"] = 38,
	["wood"] = 2370018,
	["stone"] = 5925044,
	["iron"] = 3555027,
	["citizen"] = 1786
}
woodcutter[39] = {
	["level"] = 39,
	["wood"] = 2526282,
	["stone"] = 6315704,
	["iron"] = 3789423,
	["citizen"] = 1880
}
woodcutter[40] = {
	["level"] = 40,
	["wood"] = 3761001,
	["stone"] = 9402501,
	["iron"] = 5641501,
	["citizen"] = 2000
}
