local loginDays = GameDatas.Vip.loginDays

loginDays[1] = {
	["count"] = 1,
	["expAdd"] = 100
}
loginDays[2] = {
	["count"] = 2,
	["expAdd"] = 110
}
loginDays[3] = {
	["count"] = 3,
	["expAdd"] = 120
}
loginDays[4] = {
	["count"] = 4,
	["expAdd"] = 130
}
loginDays[5] = {
	["count"] = 5,
	["expAdd"] = 140
}
loginDays[6] = {
	["count"] = 6,
	["expAdd"] = 150
}
loginDays[7] = {
	["count"] = 7,
	["expAdd"] = 160
}
loginDays[8] = {
	["count"] = 8,
	["expAdd"] = 170
}
loginDays[9] = {
	["count"] = 9,
	["expAdd"] = 180
}
loginDays[10] = {
	["count"] = 10,
	["expAdd"] = 190
}
loginDays[11] = {
	["count"] = 11,
	["expAdd"] = 200
}
loginDays[12] = {
	["count"] = 12,
	["expAdd"] = 210
}
loginDays[13] = {
	["count"] = 13,
	["expAdd"] = 220
}
loginDays[14] = {
	["count"] = 14,
	["expAdd"] = 230
}
loginDays[15] = {
	["count"] = 15,
	["expAdd"] = 240
}
loginDays[16] = {
	["count"] = 16,
	["expAdd"] = 250
}
loginDays[17] = {
	["count"] = 17,
	["expAdd"] = 260
}
loginDays[18] = {
	["count"] = 18,
	["expAdd"] = 270
}
loginDays[19] = {
	["count"] = 19,
	["expAdd"] = 280
}
loginDays[20] = {
	["count"] = 20,
	["expAdd"] = 290
}
loginDays[21] = {
	["count"] = 21,
	["expAdd"] = 300
}
