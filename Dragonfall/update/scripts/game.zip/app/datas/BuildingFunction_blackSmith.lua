local blackSmith = GameDatas.BuildingFunction.blackSmith

blackSmith[1] = {
	["level"] = 1,
	["efficiency"] = 0.010000,
	["power"] = 35
}
blackSmith[2] = {
	["level"] = 2,
	["efficiency"] = 0.020000,
	["power"] = 40
}
blackSmith[3] = {
	["level"] = 3,
	["efficiency"] = 0.030000,
	["power"] = 45
}
blackSmith[4] = {
	["level"] = 4,
	["efficiency"] = 0.040000,
	["power"] = 50
}
blackSmith[5] = {
	["level"] = 5,
	["efficiency"] = 0.050000,
	["power"] = 55
}
blackSmith[6] = {
	["level"] = 6,
	["efficiency"] = 0.060000,
	["power"] = 60
}
blackSmith[7] = {
	["level"] = 7,
	["efficiency"] = 0.070000,
	["power"] = 90
}
blackSmith[8] = {
	["level"] = 8,
	["efficiency"] = 0.080000,
	["power"] = 170
}
blackSmith[9] = {
	["level"] = 9,
	["efficiency"] = 0.090000,
	["power"] = 340
}
blackSmith[10] = {
	["level"] = 10,
	["efficiency"] = 0.100000,
	["power"] = 510
}
blackSmith[11] = {
	["level"] = 11,
	["efficiency"] = 0.110000,
	["power"] = 700
}
blackSmith[12] = {
	["level"] = 12,
	["efficiency"] = 0.120000,
	["power"] = 890
}
blackSmith[13] = {
	["level"] = 13,
	["efficiency"] = 0.130000,
	["power"] = 1170
}
blackSmith[14] = {
	["level"] = 14,
	["efficiency"] = 0.140000,
	["power"] = 2350
}
blackSmith[15] = {
	["level"] = 15,
	["efficiency"] = 0.150000,
	["power"] = 3660
}
blackSmith[16] = {
	["level"] = 16,
	["efficiency"] = 0.160000,
	["power"] = 5060
}
blackSmith[17] = {
	["level"] = 17,
	["efficiency"] = 0.170000,
	["power"] = 7390
}
blackSmith[18] = {
	["level"] = 18,
	["efficiency"] = 0.180000,
	["power"] = 9100
}
blackSmith[19] = {
	["level"] = 19,
	["efficiency"] = 0.190000,
	["power"] = 11110
}
blackSmith[20] = {
	["level"] = 20,
	["efficiency"] = 0.200000,
	["power"] = 13030
}
blackSmith[21] = {
	["level"] = 21,
	["efficiency"] = 0.210000,
	["power"] = 17700
}
blackSmith[22] = {
	["level"] = 22,
	["efficiency"] = 0.220000,
	["power"] = 20280
}
blackSmith[23] = {
	["level"] = 23,
	["efficiency"] = 0.230000,
	["power"] = 23410
}
blackSmith[24] = {
	["level"] = 24,
	["efficiency"] = 0.240000,
	["power"] = 26340
}
blackSmith[25] = {
	["level"] = 25,
	["efficiency"] = 0.250000,
	["power"] = 35980
}
blackSmith[26] = {
	["level"] = 26,
	["efficiency"] = 0.260000,
	["power"] = 40160
}
blackSmith[27] = {
	["level"] = 27,
	["efficiency"] = 0.270000,
	["power"] = 45180
}
blackSmith[28] = {
	["level"] = 28,
	["efficiency"] = 0.280000,
	["power"] = 49920
}
blackSmith[29] = {
	["level"] = 29,
	["efficiency"] = 0.290000,
	["power"] = 71050
}
blackSmith[30] = {
	["level"] = 30,
	["efficiency"] = 0.300000,
	["power"] = 82010
}
blackSmith[31] = {
	["level"] = 31,
	["efficiency"] = 0.310000,
	["power"] = 94720
}
blackSmith[32] = {
	["level"] = 32,
	["efficiency"] = 0.320000,
	["power"] = 107470
}
blackSmith[33] = {
	["level"] = 33,
	["efficiency"] = 0.330000,
	["power"] = 147090
}
blackSmith[34] = {
	["level"] = 34,
	["efficiency"] = 0.340000,
	["power"] = 165280
}
blackSmith[35] = {
	["level"] = 35,
	["efficiency"] = 0.350000,
	["power"] = 186180
}
blackSmith[36] = {
	["level"] = 36,
	["efficiency"] = 0.360000,
	["power"] = 207210
}
blackSmith[37] = {
	["level"] = 37,
	["efficiency"] = 0.370000,
	["power"] = 278660
}
blackSmith[38] = {
	["level"] = 38,
	["efficiency"] = 0.380000,
	["power"] = 308260
}
blackSmith[39] = {
	["level"] = 39,
	["efficiency"] = 0.390000,
	["power"] = 341740
}
blackSmith[40] = {
	["level"] = 40,
	["efficiency"] = 0.400000,
	["power"] = 375900
}
