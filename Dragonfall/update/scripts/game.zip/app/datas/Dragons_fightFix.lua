local fightFix = GameDatas.Dragons.fightFix

fightFix[0] = {
	["index"] = 0,
	["multipleMin"] = 0.000000,
	["multipleMax"] = 1.200000,
	["effect"] = 1.000000
}
fightFix[1] = {
	["index"] = 1,
	["multipleMin"] = 1.200000,
	["multipleMax"] = 2.000000,
	["effect"] = 1.500000
}
fightFix[2] = {
	["index"] = 2,
	["multipleMin"] = 2.000000,
	["multipleMax"] = 4.000000,
	["effect"] = 2.000000
}
fightFix[3] = {
	["index"] = 3,
	["multipleMin"] = 4.000000,
	["multipleMax"] = 0.000000,
	["effect"] = 3.000000
}
