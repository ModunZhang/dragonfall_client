local mill = GameDatas.BuildingFunction.mill

mill[1] = {
	["level"] = 1,
	["houseAdd"] = 1,
	["protection"] = 0.010000,
	["power"] = 40
}
mill[2] = {
	["level"] = 2,
	["houseAdd"] = 1,
	["protection"] = 0.020000,
	["power"] = 45
}
mill[3] = {
	["level"] = 3,
	["houseAdd"] = 1,
	["protection"] = 0.030000,
	["power"] = 50
}
mill[4] = {
	["level"] = 4,
	["houseAdd"] = 1,
	["protection"] = 0.040000,
	["power"] = 60
}
mill[5] = {
	["level"] = 5,
	["houseAdd"] = 1,
	["protection"] = 0.050000,
	["power"] = 70
}
mill[6] = {
	["level"] = 6,
	["houseAdd"] = 1,
	["protection"] = 0.060000,
	["power"] = 80
}
mill[7] = {
	["level"] = 7,
	["houseAdd"] = 1,
	["protection"] = 0.070000,
	["power"] = 100
}
mill[8] = {
	["level"] = 8,
	["houseAdd"] = 2,
	["protection"] = 0.080000,
	["power"] = 160
}
mill[9] = {
	["level"] = 9,
	["houseAdd"] = 2,
	["protection"] = 0.090000,
	["power"] = 300
}
mill[10] = {
	["level"] = 10,
	["houseAdd"] = 2,
	["protection"] = 0.100000,
	["power"] = 430
}
mill[11] = {
	["level"] = 11,
	["houseAdd"] = 2,
	["protection"] = 0.110000,
	["power"] = 590
}
mill[12] = {
	["level"] = 12,
	["houseAdd"] = 2,
	["protection"] = 0.120000,
	["power"] = 740
}
mill[13] = {
	["level"] = 13,
	["houseAdd"] = 2,
	["protection"] = 0.130000,
	["power"] = 960
}
mill[14] = {
	["level"] = 14,
	["houseAdd"] = 2,
	["protection"] = 0.140000,
	["power"] = 1920
}
mill[15] = {
	["level"] = 15,
	["houseAdd"] = 3,
	["protection"] = 0.150000,
	["power"] = 2980
}
mill[16] = {
	["level"] = 16,
	["houseAdd"] = 3,
	["protection"] = 0.160000,
	["power"] = 4110
}
mill[17] = {
	["level"] = 17,
	["houseAdd"] = 3,
	["protection"] = 0.170000,
	["power"] = 5990
}
mill[18] = {
	["level"] = 18,
	["houseAdd"] = 3,
	["protection"] = 0.180000,
	["power"] = 7370
}
mill[19] = {
	["level"] = 19,
	["houseAdd"] = 3,
	["protection"] = 0.190000,
	["power"] = 8990
}
mill[20] = {
	["level"] = 20,
	["houseAdd"] = 3,
	["protection"] = 0.200000,
	["power"] = 10540
}
mill[21] = {
	["level"] = 21,
	["houseAdd"] = 3,
	["protection"] = 0.210000,
	["power"] = 14310
}
mill[22] = {
	["level"] = 22,
	["houseAdd"] = 4,
	["protection"] = 0.220000,
	["power"] = 16400
}
mill[23] = {
	["level"] = 23,
	["houseAdd"] = 4,
	["protection"] = 0.230000,
	["power"] = 18930
}
mill[24] = {
	["level"] = 24,
	["houseAdd"] = 4,
	["protection"] = 0.240000,
	["power"] = 21300
}
mill[25] = {
	["level"] = 25,
	["houseAdd"] = 4,
	["protection"] = 0.250000,
	["power"] = 29080
}
mill[26] = {
	["level"] = 26,
	["houseAdd"] = 4,
	["protection"] = 0.260000,
	["power"] = 32460
}
mill[27] = {
	["level"] = 27,
	["houseAdd"] = 4,
	["protection"] = 0.270000,
	["power"] = 36510
}
mill[28] = {
	["level"] = 28,
	["houseAdd"] = 4,
	["protection"] = 0.280000,
	["power"] = 40340
}
mill[29] = {
	["level"] = 29,
	["houseAdd"] = 5,
	["protection"] = 0.290000,
	["power"] = 57400
}
mill[30] = {
	["level"] = 30,
	["houseAdd"] = 5,
	["protection"] = 0.300000,
	["power"] = 66260
}
mill[31] = {
	["level"] = 31,
	["houseAdd"] = 5,
	["protection"] = 0.310000,
	["power"] = 76530
}
mill[32] = {
	["level"] = 32,
	["houseAdd"] = 5,
	["protection"] = 0.320000,
	["power"] = 86820
}
mill[33] = {
	["level"] = 33,
	["houseAdd"] = 5,
	["protection"] = 0.330000,
	["power"] = 118830
}
mill[34] = {
	["level"] = 34,
	["houseAdd"] = 5,
	["protection"] = 0.340000,
	["power"] = 133520
}
mill[35] = {
	["level"] = 35,
	["houseAdd"] = 5,
	["protection"] = 0.350000,
	["power"] = 150390
}
mill[36] = {
	["level"] = 36,
	["houseAdd"] = 6,
	["protection"] = 0.360000,
	["power"] = 167390
}
mill[37] = {
	["level"] = 37,
	["houseAdd"] = 6,
	["protection"] = 0.370000,
	["power"] = 225090
}
mill[38] = {
	["level"] = 38,
	["houseAdd"] = 6,
	["protection"] = 0.380000,
	["power"] = 249000
}
mill[39] = {
	["level"] = 39,
	["houseAdd"] = 6,
	["protection"] = 0.390000,
	["power"] = 276040
}
mill[40] = {
	["level"] = 40,
	["houseAdd"] = 6,
	["protection"] = 0.400000,
	["power"] = 303630
}
