local coinVillage = GameDatas.AllianceVillage.coinVillage

coinVillage[1] = {
	["level"] = 1,
	["needHonour"] = 1190,
	["production"] = 42000
}
coinVillage[2] = {
	["level"] = 2,
	["needHonour"] = 3213,
	["production"] = 54000
}
coinVillage[3] = {
	["level"] = 3,
	["needHonour"] = 7140,
	["production"] = 72000
}
coinVillage[4] = {
	["level"] = 4,
	["needHonour"] = 10710,
	["production"] = 96000
}
coinVillage[5] = {
	["level"] = 5,
	["needHonour"] = 15708,
	["production"] = 126000
}
coinVillage[6] = {
	["level"] = 6,
	["needHonour"] = 26656,
	["production"] = 162000
}
coinVillage[7] = {
	["level"] = 7,
	["needHonour"] = 44030,
	["production"] = 204000
}
coinVillage[8] = {
	["level"] = 8,
	["needHonour"] = 72828,
	["production"] = 252000
}
coinVillage[9] = {
	["level"] = 9,
	["needHonour"] = 112455,
	["production"] = 306000
}
coinVillage[10] = {
	["level"] = 10,
	["needHonour"] = 171360,
	["production"] = 366000
}
coinVillage[11] = {
	["level"] = 11,
	["needHonour"] = 249543,
	["production"] = 432000
}
coinVillage[12] = {
	["level"] = 12,
	["needHonour"] = 374850,
	["production"] = 504000
}
coinVillage[13] = {
	["level"] = 13,
	["needHonour"] = 539308,
	["production"] = 582000
}
coinVillage[14] = {
	["level"] = 14,
	["needHonour"] = 788256,
	["production"] = 666000
}
coinVillage[15] = {
	["level"] = 15,
	["needHonour"] = 1113840,
	["production"] = 756000
}
coinVillage[16] = {
	["level"] = 16,
	["needHonour"] = 1599360,
	["production"] = 852000
}
coinVillage[17] = {
	["level"] = 17,
	["needHonour"] = 2225895,
	["production"] = 960000
}
coinVillage[18] = {
	["level"] = 18,
	["needHonour"] = 2817920,
	["production"] = 1080000
}
coinVillage[19] = {
	["level"] = 19,
	["needHonour"] = 3236800,
	["production"] = 1230000
}
coinVillage[20] = {
	["level"] = 20,
	["needHonour"] = 4284000,
	["production"] = 1410000
}
