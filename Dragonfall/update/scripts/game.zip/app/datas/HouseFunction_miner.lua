local miner = GameDatas.HouseFunction.miner

miner[1] = {
	["level"] = 1,
	["production"] = 160,
	["power"] = 2
}
miner[2] = {
	["level"] = 2,
	["production"] = 260,
	["power"] = 4
}
miner[3] = {
	["level"] = 3,
	["production"] = 380,
	["power"] = 6
}
miner[4] = {
	["level"] = 4,
	["production"] = 520,
	["power"] = 8
}
miner[5] = {
	["level"] = 5,
	["production"] = 680,
	["power"] = 10
}
miner[6] = {
	["level"] = 6,
	["production"] = 860,
	["power"] = 20
}
miner[7] = {
	["level"] = 7,
	["production"] = 1060,
	["power"] = 30
}
miner[8] = {
	["level"] = 8,
	["production"] = 1280,
	["power"] = 70
}
miner[9] = {
	["level"] = 9,
	["production"] = 1520,
	["power"] = 170
}
miner[10] = {
	["level"] = 10,
	["production"] = 1780,
	["power"] = 260
}
miner[11] = {
	["level"] = 11,
	["production"] = 2060,
	["power"] = 360
}
miner[12] = {
	["level"] = 12,
	["production"] = 2360,
	["power"] = 460
}
miner[13] = {
	["level"] = 13,
	["production"] = 2680,
	["power"] = 610
}
miner[14] = {
	["level"] = 14,
	["production"] = 3020,
	["power"] = 1250
}
miner[15] = {
	["level"] = 15,
	["production"] = 3380,
	["power"] = 1950
}
miner[16] = {
	["level"] = 16,
	["production"] = 3760,
	["power"] = 2710
}
miner[17] = {
	["level"] = 17,
	["production"] = 4160,
	["power"] = 3960
}
miner[18] = {
	["level"] = 18,
	["production"] = 4580,
	["power"] = 4880
}
miner[19] = {
	["level"] = 19,
	["production"] = 5020,
	["power"] = 5960
}
miner[20] = {
	["level"] = 20,
	["production"] = 5480,
	["power"] = 7000
}
miner[21] = {
	["level"] = 21,
	["production"] = 5960,
	["power"] = 9510
}
miner[22] = {
	["level"] = 22,
	["production"] = 6460,
	["power"] = 10900
}
miner[23] = {
	["level"] = 23,
	["production"] = 6980,
	["power"] = 12590
}
miner[24] = {
	["level"] = 24,
	["production"] = 7520,
	["power"] = 14170
}
miner[25] = {
	["level"] = 25,
	["production"] = 8080,
	["power"] = 19350
}
miner[26] = {
	["level"] = 26,
	["production"] = 8660,
	["power"] = 21610
}
miner[27] = {
	["level"] = 27,
	["production"] = 9260,
	["power"] = 24310
}
miner[28] = {
	["level"] = 28,
	["production"] = 9880,
	["power"] = 26860
}
miner[29] = {
	["level"] = 29,
	["production"] = 10520,
	["power"] = 38240
}
miner[30] = {
	["level"] = 30,
	["production"] = 11180,
	["power"] = 44140
}
miner[31] = {
	["level"] = 31,
	["production"] = 11880,
	["power"] = 50990
}
miner[32] = {
	["level"] = 32,
	["production"] = 12620,
	["power"] = 57850
}
miner[33] = {
	["level"] = 33,
	["production"] = 13400,
	["power"] = 79190
}
miner[34] = {
	["level"] = 34,
	["production"] = 14220,
	["power"] = 88980
}
miner[35] = {
	["level"] = 35,
	["production"] = 15080,
	["power"] = 100230
}
miner[36] = {
	["level"] = 36,
	["production"] = 15980,
	["power"] = 111560
}
miner[37] = {
	["level"] = 37,
	["production"] = 16920,
	["power"] = 150030
}
miner[38] = {
	["level"] = 38,
	["production"] = 17900,
	["power"] = 165970
}
miner[39] = {
	["level"] = 39,
	["production"] = 18920,
	["power"] = 184000
}
miner[40] = {
	["level"] = 40,
	["production"] = 20000,
	["power"] = 202390
}
