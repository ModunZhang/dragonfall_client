local equipmentBuff = GameDatas.DragonEquipments.equipmentBuff

equipmentBuff["infantryAtkAdd"] = {
	["buff"] = "infantryAtkAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["infantryHpAdd"] = {
	["buff"] = "infantryHpAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["infantryLoadAdd"] = {
	["buff"] = "infantryLoadAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["infantryMarchAdd"] = {
	["buff"] = "infantryMarchAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["archerAtkAdd"] = {
	["buff"] = "archerAtkAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["archerHpAdd"] = {
	["buff"] = "archerHpAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["archerLoadAdd"] = {
	["buff"] = "archerLoadAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["archerMarchAdd"] = {
	["buff"] = "archerMarchAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["cavalryAtkAdd"] = {
	["buff"] = "cavalryAtkAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["cavalryHpAdd"] = {
	["buff"] = "cavalryHpAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["cavalryLoadAdd"] = {
	["buff"] = "cavalryLoadAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["cavalryMarchAdd"] = {
	["buff"] = "cavalryMarchAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["siegeAtkAdd"] = {
	["buff"] = "siegeAtkAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["siegeHpAdd"] = {
	["buff"] = "siegeHpAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["siegeLoadAdd"] = {
	["buff"] = "siegeLoadAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["siegeMarchAdd"] = {
	["buff"] = "siegeMarchAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["troopSizeAdd"] = {
	["buff"] = "troopSizeAdd",
	["buffEffect"] = 0.020000
}
equipmentBuff["recoverAdd"] = {
	["buff"] = "recoverAdd",
	["buffEffect"] = 0.020000
}
