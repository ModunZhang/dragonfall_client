local keep = GameDatas.BuildingFunction.keep

keep[1] = {
	["level"] = 1,
	["unlock"] = 3,
	["beHelpedCount"] = 1,
	["power"] = 10
}
keep[2] = {
	["level"] = 2,
	["unlock"] = 4,
	["beHelpedCount"] = 1,
	["power"] = 20
}
keep[3] = {
	["level"] = 3,
	["unlock"] = 5,
	["beHelpedCount"] = 2,
	["power"] = 30
}
keep[4] = {
	["level"] = 4,
	["unlock"] = 6,
	["beHelpedCount"] = 2,
	["power"] = 40
}
keep[5] = {
	["level"] = 5,
	["unlock"] = 7,
	["beHelpedCount"] = 3,
	["power"] = 60
}
keep[6] = {
	["level"] = 6,
	["unlock"] = 8,
	["beHelpedCount"] = 3,
	["power"] = 70
}
keep[7] = {
	["level"] = 7,
	["unlock"] = 9,
	["beHelpedCount"] = 4,
	["power"] = 130
}
keep[8] = {
	["level"] = 8,
	["unlock"] = 10,
	["beHelpedCount"] = 4,
	["power"] = 270
}
keep[9] = {
	["level"] = 9,
	["unlock"] = 11,
	["beHelpedCount"] = 5,
	["power"] = 610
}
keep[10] = {
	["level"] = 10,
	["unlock"] = 12,
	["beHelpedCount"] = 5,
	["power"] = 930
}
keep[11] = {
	["level"] = 11,
	["unlock"] = 13,
	["beHelpedCount"] = 6,
	["power"] = 1300
}
keep[12] = {
	["level"] = 12,
	["unlock"] = 14,
	["beHelpedCount"] = 6,
	["power"] = 1650
}
keep[13] = {
	["level"] = 13,
	["unlock"] = 15,
	["beHelpedCount"] = 7,
	["power"] = 2190
}
keep[14] = {
	["level"] = 14,
	["unlock"] = 16,
	["beHelpedCount"] = 7,
	["power"] = 4460
}
keep[15] = {
	["level"] = 15,
	["unlock"] = 17,
	["beHelpedCount"] = 8,
	["power"] = 6990
}
keep[16] = {
	["level"] = 16,
	["unlock"] = 18,
	["beHelpedCount"] = 8,
	["power"] = 9680
}
keep[17] = {
	["level"] = 17,
	["unlock"] = 19,
	["beHelpedCount"] = 9,
	["power"] = 14160
}
keep[18] = {
	["level"] = 18,
	["unlock"] = 19,
	["beHelpedCount"] = 9,
	["power"] = 17440
}
keep[19] = {
	["level"] = 19,
	["unlock"] = 19,
	["beHelpedCount"] = 10,
	["power"] = 21310
}
keep[20] = {
	["level"] = 20,
	["unlock"] = 19,
	["beHelpedCount"] = 10,
	["power"] = 25000
}
keep[21] = {
	["level"] = 21,
	["unlock"] = 19,
	["beHelpedCount"] = 11,
	["power"] = 33980
}
keep[22] = {
	["level"] = 22,
	["unlock"] = 19,
	["beHelpedCount"] = 11,
	["power"] = 38950
}
keep[23] = {
	["level"] = 23,
	["unlock"] = 19,
	["beHelpedCount"] = 12,
	["power"] = 44960
}
keep[24] = {
	["level"] = 24,
	["unlock"] = 19,
	["beHelpedCount"] = 12,
	["power"] = 50600
}
keep[25] = {
	["level"] = 25,
	["unlock"] = 19,
	["beHelpedCount"] = 13,
	["power"] = 69130
}
keep[26] = {
	["level"] = 26,
	["unlock"] = 19,
	["beHelpedCount"] = 13,
	["power"] = 77180
}
keep[27] = {
	["level"] = 27,
	["unlock"] = 19,
	["beHelpedCount"] = 14,
	["power"] = 86830
}
keep[28] = {
	["level"] = 28,
	["unlock"] = 19,
	["beHelpedCount"] = 14,
	["power"] = 95950
}
keep[29] = {
	["level"] = 29,
	["unlock"] = 19,
	["beHelpedCount"] = 15,
	["power"] = 136570
}
keep[30] = {
	["level"] = 30,
	["unlock"] = 19,
	["beHelpedCount"] = 15,
	["power"] = 157660
}
keep[31] = {
	["level"] = 31,
	["unlock"] = 19,
	["beHelpedCount"] = 16,
	["power"] = 182100
}
keep[32] = {
	["level"] = 32,
	["unlock"] = 19,
	["beHelpedCount"] = 16,
	["power"] = 206620
}
keep[33] = {
	["level"] = 33,
	["unlock"] = 19,
	["beHelpedCount"] = 17,
	["power"] = 282820
}
keep[34] = {
	["level"] = 34,
	["unlock"] = 19,
	["beHelpedCount"] = 17,
	["power"] = 317800
}
keep[35] = {
	["level"] = 35,
	["unlock"] = 19,
	["beHelpedCount"] = 18,
	["power"] = 357980
}
keep[36] = {
	["level"] = 36,
	["unlock"] = 19,
	["beHelpedCount"] = 18,
	["power"] = 398440
}
keep[37] = {
	["level"] = 37,
	["unlock"] = 19,
	["beHelpedCount"] = 19,
	["power"] = 535830
}
keep[38] = {
	["level"] = 38,
	["unlock"] = 19,
	["beHelpedCount"] = 19,
	["power"] = 592750
}
keep[39] = {
	["level"] = 39,
	["unlock"] = 19,
	["beHelpedCount"] = 20,
	["power"] = 657150
}
keep[40] = {
	["level"] = 40,
	["unlock"] = 19,
	["beHelpedCount"] = 20,
	["power"] = 722840
}
