local orderHall = GameDatas.AllianceBuilding.orderHall

orderHall[1] = {
	["level"] = 1,
	["needHonour"] = 2550,
	["villageCount"] = 4,
	["power"] = 85
}
orderHall[2] = {
	["level"] = 2,
	["needHonour"] = 6885,
	["villageCount"] = 5,
	["power"] = 229
}
orderHall[3] = {
	["level"] = 3,
	["needHonour"] = 15300,
	["villageCount"] = 6,
	["power"] = 510
}
orderHall[4] = {
	["level"] = 4,
	["needHonour"] = 22950,
	["villageCount"] = 7,
	["power"] = 765
}
orderHall[5] = {
	["level"] = 5,
	["needHonour"] = 33660,
	["villageCount"] = 8,
	["power"] = 1122
}
orderHall[6] = {
	["level"] = 6,
	["needHonour"] = 57120,
	["villageCount"] = 9,
	["power"] = 1904
}
orderHall[7] = {
	["level"] = 7,
	["needHonour"] = 94350,
	["villageCount"] = 10,
	["power"] = 3145
}
orderHall[8] = {
	["level"] = 8,
	["needHonour"] = 156060,
	["villageCount"] = 12,
	["power"] = 5202
}
orderHall[9] = {
	["level"] = 9,
	["needHonour"] = 240975,
	["villageCount"] = 14,
	["power"] = 8032
}
orderHall[10] = {
	["level"] = 10,
	["needHonour"] = 367200,
	["villageCount"] = 16,
	["power"] = 12240
}
orderHall[11] = {
	["level"] = 11,
	["needHonour"] = 534735,
	["villageCount"] = 18,
	["power"] = 17824
}
orderHall[12] = {
	["level"] = 12,
	["needHonour"] = 803250,
	["villageCount"] = 20,
	["power"] = 26775
}
orderHall[13] = {
	["level"] = 13,
	["needHonour"] = 1155660,
	["villageCount"] = 22,
	["power"] = 38522
}
orderHall[14] = {
	["level"] = 14,
	["needHonour"] = 1689120,
	["villageCount"] = 24,
	["power"] = 56304
}
orderHall[15] = {
	["level"] = 15,
	["needHonour"] = 2386800,
	["villageCount"] = 26,
	["power"] = 79560
}
orderHall[16] = {
	["level"] = 16,
	["needHonour"] = 3427200,
	["villageCount"] = 28,
	["power"] = 114240
}
orderHall[17] = {
	["level"] = 17,
	["needHonour"] = 4769775,
	["villageCount"] = 30,
	["power"] = 158992
}
orderHall[18] = {
	["level"] = 18,
	["needHonour"] = 6038400,
	["villageCount"] = 32,
	["power"] = 201280
}
orderHall[19] = {
	["level"] = 19,
	["needHonour"] = 6936000,
	["villageCount"] = 34,
	["power"] = 231200
}
orderHall[20] = {
	["level"] = 20,
	["needHonour"] = 9180000,
	["villageCount"] = 36,
	["power"] = 306000
}
