local hospital = GameDatas.BuildingFunction.hospital

hospital[1] = {
	["level"] = 1,
	["maxCitizen"] = 320,
	["power"] = 30
}
hospital[2] = {
	["level"] = 2,
	["maxCitizen"] = 640,
	["power"] = 35
}
hospital[3] = {
	["level"] = 3,
	["maxCitizen"] = 960,
	["power"] = 40
}
hospital[4] = {
	["level"] = 4,
	["maxCitizen"] = 1280,
	["power"] = 50
}
hospital[5] = {
	["level"] = 5,
	["maxCitizen"] = 1600,
	["power"] = 60
}
hospital[6] = {
	["level"] = 6,
	["maxCitizen"] = 1920,
	["power"] = 70
}
hospital[7] = {
	["level"] = 7,
	["maxCitizen"] = 2240,
	["power"] = 110
}
hospital[8] = {
	["level"] = 8,
	["maxCitizen"] = 2560,
	["power"] = 200
}
hospital[9] = {
	["level"] = 9,
	["maxCitizen"] = 2880,
	["power"] = 410
}
hospital[10] = {
	["level"] = 10,
	["maxCitizen"] = 3200,
	["power"] = 610
}
hospital[11] = {
	["level"] = 11,
	["maxCitizen"] = 6400,
	["power"] = 830
}
hospital[12] = {
	["level"] = 12,
	["maxCitizen"] = 7680,
	["power"] = 1050
}
hospital[13] = {
	["level"] = 13,
	["maxCitizen"] = 8960,
	["power"] = 1390
}
hospital[14] = {
	["level"] = 14,
	["maxCitizen"] = 10240,
	["power"] = 2800
}
hospital[15] = {
	["level"] = 15,
	["maxCitizen"] = 11520,
	["power"] = 4360
}
hospital[16] = {
	["level"] = 16,
	["maxCitizen"] = 12800,
	["power"] = 6030
}
hospital[17] = {
	["level"] = 17,
	["maxCitizen"] = 14080,
	["power"] = 8810
}
hospital[18] = {
	["level"] = 18,
	["maxCitizen"] = 15360,
	["power"] = 10840
}
hospital[19] = {
	["level"] = 19,
	["maxCitizen"] = 16640,
	["power"] = 13240
}
hospital[20] = {
	["level"] = 20,
	["maxCitizen"] = 17920,
	["power"] = 15530
}
hospital[21] = {
	["level"] = 21,
	["maxCitizen"] = 35840,
	["power"] = 21090
}
hospital[22] = {
	["level"] = 22,
	["maxCitizen"] = 40960,
	["power"] = 24180
}
hospital[23] = {
	["level"] = 23,
	["maxCitizen"] = 46080,
	["power"] = 27900
}
hospital[24] = {
	["level"] = 24,
	["maxCitizen"] = 51200,
	["power"] = 31400
}
hospital[25] = {
	["level"] = 25,
	["maxCitizen"] = 56320,
	["power"] = 42890
}
hospital[26] = {
	["level"] = 26,
	["maxCitizen"] = 61440,
	["power"] = 47880
}
hospital[27] = {
	["level"] = 27,
	["maxCitizen"] = 66560,
	["power"] = 53860
}
hospital[28] = {
	["level"] = 28,
	["maxCitizen"] = 71680,
	["power"] = 59520
}
hospital[29] = {
	["level"] = 29,
	["maxCitizen"] = 76800,
	["power"] = 84700
}
hospital[30] = {
	["level"] = 30,
	["maxCitizen"] = 81920,
	["power"] = 97780
}
hospital[31] = {
	["level"] = 31,
	["maxCitizen"] = 163840,
	["power"] = 112930
}
hospital[32] = {
	["level"] = 32,
	["maxCitizen"] = 184320,
	["power"] = 128130
}
hospital[33] = {
	["level"] = 33,
	["maxCitizen"] = 204800,
	["power"] = 175380
}
hospital[34] = {
	["level"] = 34,
	["maxCitizen"] = 225280,
	["power"] = 197060
}
hospital[35] = {
	["level"] = 35,
	["maxCitizen"] = 245760,
	["power"] = 221980
}
hospital[36] = {
	["level"] = 36,
	["maxCitizen"] = 266240,
	["power"] = 247060
}
hospital[37] = {
	["level"] = 37,
	["maxCitizen"] = 286720,
	["power"] = 332240
}
hospital[38] = {
	["level"] = 38,
	["maxCitizen"] = 307200,
	["power"] = 367530
}
hospital[39] = {
	["level"] = 39,
	["maxCitizen"] = 327680,
	["power"] = 407460
}
hospital[40] = {
	["level"] = 40,
	["maxCitizen"] = 360000,
	["power"] = 448190
}
