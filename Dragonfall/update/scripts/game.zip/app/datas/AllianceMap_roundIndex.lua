local roundIndex = GameDatas.AllianceMap.roundIndex

roundIndex[0] = {
	["index"] = 0,
	["x"] = 5,
	["y"] = 5
}
roundIndex[1] = {
	["index"] = 1,
	["x"] = 4,
	["y"] = 5
}
roundIndex[2] = {
	["index"] = 2,
	["x"] = 4,
	["y"] = 4
}
roundIndex[3] = {
	["index"] = 3,
	["x"] = 5,
	["y"] = 4
}
roundIndex[4] = {
	["index"] = 4,
	["x"] = 6,
	["y"] = 4
}
roundIndex[5] = {
	["index"] = 5,
	["x"] = 6,
	["y"] = 5
}
roundIndex[6] = {
	["index"] = 6,
	["x"] = 6,
	["y"] = 6
}
roundIndex[7] = {
	["index"] = 7,
	["x"] = 5,
	["y"] = 6
}
roundIndex[8] = {
	["index"] = 8,
	["x"] = 4,
	["y"] = 6
}
roundIndex[9] = {
	["index"] = 9,
	["x"] = 3,
	["y"] = 6
}
roundIndex[10] = {
	["index"] = 10,
	["x"] = 3,
	["y"] = 5
}
roundIndex[11] = {
	["index"] = 11,
	["x"] = 3,
	["y"] = 4
}
roundIndex[12] = {
	["index"] = 12,
	["x"] = 3,
	["y"] = 3
}
roundIndex[13] = {
	["index"] = 13,
	["x"] = 4,
	["y"] = 3
}
roundIndex[14] = {
	["index"] = 14,
	["x"] = 5,
	["y"] = 3
}
roundIndex[15] = {
	["index"] = 15,
	["x"] = 6,
	["y"] = 3
}
roundIndex[16] = {
	["index"] = 16,
	["x"] = 7,
	["y"] = 3
}
roundIndex[17] = {
	["index"] = 17,
	["x"] = 7,
	["y"] = 4
}
roundIndex[18] = {
	["index"] = 18,
	["x"] = 7,
	["y"] = 5
}
roundIndex[19] = {
	["index"] = 19,
	["x"] = 7,
	["y"] = 6
}
roundIndex[20] = {
	["index"] = 20,
	["x"] = 7,
	["y"] = 7
}
roundIndex[21] = {
	["index"] = 21,
	["x"] = 6,
	["y"] = 7
}
roundIndex[22] = {
	["index"] = 22,
	["x"] = 5,
	["y"] = 7
}
roundIndex[23] = {
	["index"] = 23,
	["x"] = 4,
	["y"] = 7
}
roundIndex[24] = {
	["index"] = 24,
	["x"] = 3,
	["y"] = 7
}
roundIndex[25] = {
	["index"] = 25,
	["x"] = 3,
	["y"] = 6
}
roundIndex[26] = {
	["index"] = 26,
	["x"] = 2,
	["y"] = 5
}
roundIndex[27] = {
	["index"] = 27,
	["x"] = 2,
	["y"] = 4
}
roundIndex[28] = {
	["index"] = 28,
	["x"] = 2,
	["y"] = 3
}
roundIndex[29] = {
	["index"] = 29,
	["x"] = 2,
	["y"] = 2
}
roundIndex[30] = {
	["index"] = 30,
	["x"] = 3,
	["y"] = 2
}
roundIndex[31] = {
	["index"] = 31,
	["x"] = 4,
	["y"] = 2
}
roundIndex[32] = {
	["index"] = 32,
	["x"] = 5,
	["y"] = 2
}
roundIndex[33] = {
	["index"] = 33,
	["x"] = 6,
	["y"] = 2
}
roundIndex[34] = {
	["index"] = 34,
	["x"] = 7,
	["y"] = 2
}
roundIndex[35] = {
	["index"] = 35,
	["x"] = 8,
	["y"] = 2
}
roundIndex[36] = {
	["index"] = 36,
	["x"] = 8,
	["y"] = 3
}
roundIndex[37] = {
	["index"] = 37,
	["x"] = 8,
	["y"] = 4
}
roundIndex[38] = {
	["index"] = 38,
	["x"] = 8,
	["y"] = 5
}
roundIndex[39] = {
	["index"] = 39,
	["x"] = 8,
	["y"] = 6
}
roundIndex[40] = {
	["index"] = 40,
	["x"] = 8,
	["y"] = 7
}
roundIndex[41] = {
	["index"] = 41,
	["x"] = 8,
	["y"] = 8
}
roundIndex[42] = {
	["index"] = 42,
	["x"] = 7,
	["y"] = 8
}
roundIndex[43] = {
	["index"] = 43,
	["x"] = 6,
	["y"] = 8
}
roundIndex[44] = {
	["index"] = 44,
	["x"] = 5,
	["y"] = 8
}
roundIndex[45] = {
	["index"] = 45,
	["x"] = 4,
	["y"] = 8
}
roundIndex[46] = {
	["index"] = 46,
	["x"] = 3,
	["y"] = 8
}
roundIndex[47] = {
	["index"] = 47,
	["x"] = 2,
	["y"] = 8
}
roundIndex[48] = {
	["index"] = 48,
	["x"] = 2,
	["y"] = 7
}
roundIndex[49] = {
	["index"] = 49,
	["x"] = 2,
	["y"] = 6
}
roundIndex[50] = {
	["index"] = 50,
	["x"] = 1,
	["y"] = 5
}
roundIndex[51] = {
	["index"] = 51,
	["x"] = 1,
	["y"] = 4
}
roundIndex[52] = {
	["index"] = 52,
	["x"] = 1,
	["y"] = 3
}
roundIndex[53] = {
	["index"] = 53,
	["x"] = 1,
	["y"] = 2
}
roundIndex[54] = {
	["index"] = 54,
	["x"] = 1,
	["y"] = 1
}
roundIndex[55] = {
	["index"] = 55,
	["x"] = 2,
	["y"] = 1
}
roundIndex[56] = {
	["index"] = 56,
	["x"] = 3,
	["y"] = 1
}
roundIndex[57] = {
	["index"] = 57,
	["x"] = 4,
	["y"] = 1
}
roundIndex[58] = {
	["index"] = 58,
	["x"] = 5,
	["y"] = 1
}
roundIndex[59] = {
	["index"] = 59,
	["x"] = 6,
	["y"] = 1
}
roundIndex[60] = {
	["index"] = 60,
	["x"] = 7,
	["y"] = 1
}
roundIndex[61] = {
	["index"] = 61,
	["x"] = 8,
	["y"] = 1
}
roundIndex[62] = {
	["index"] = 62,
	["x"] = 9,
	["y"] = 1
}
roundIndex[63] = {
	["index"] = 63,
	["x"] = 9,
	["y"] = 2
}
roundIndex[64] = {
	["index"] = 64,
	["x"] = 9,
	["y"] = 3
}
roundIndex[65] = {
	["index"] = 65,
	["x"] = 9,
	["y"] = 4
}
roundIndex[66] = {
	["index"] = 66,
	["x"] = 9,
	["y"] = 5
}
roundIndex[67] = {
	["index"] = 67,
	["x"] = 9,
	["y"] = 6
}
roundIndex[68] = {
	["index"] = 68,
	["x"] = 9,
	["y"] = 7
}
roundIndex[69] = {
	["index"] = 69,
	["x"] = 9,
	["y"] = 8
}
roundIndex[70] = {
	["index"] = 70,
	["x"] = 9,
	["y"] = 9
}
roundIndex[71] = {
	["index"] = 71,
	["x"] = 8,
	["y"] = 9
}
roundIndex[72] = {
	["index"] = 72,
	["x"] = 7,
	["y"] = 9
}
roundIndex[73] = {
	["index"] = 73,
	["x"] = 6,
	["y"] = 9
}
roundIndex[74] = {
	["index"] = 74,
	["x"] = 5,
	["y"] = 9
}
roundIndex[75] = {
	["index"] = 75,
	["x"] = 4,
	["y"] = 9
}
roundIndex[76] = {
	["index"] = 76,
	["x"] = 3,
	["y"] = 9
}
roundIndex[77] = {
	["index"] = 77,
	["x"] = 2,
	["y"] = 9
}
roundIndex[78] = {
	["index"] = 78,
	["x"] = 1,
	["y"] = 9
}
roundIndex[79] = {
	["index"] = 79,
	["x"] = 1,
	["y"] = 8
}
roundIndex[80] = {
	["index"] = 80,
	["x"] = 1,
	["y"] = 7
}
roundIndex[81] = {
	["index"] = 81,
	["x"] = 1,
	["y"] = 6
}
roundIndex[82] = {
	["index"] = 82,
	["x"] = 0,
	["y"] = 5
}
roundIndex[83] = {
	["index"] = 83,
	["x"] = 0,
	["y"] = 4
}
roundIndex[84] = {
	["index"] = 84,
	["x"] = 0,
	["y"] = 3
}
roundIndex[85] = {
	["index"] = 85,
	["x"] = 0,
	["y"] = 2
}
roundIndex[86] = {
	["index"] = 86,
	["x"] = 0,
	["y"] = 1
}
roundIndex[87] = {
	["index"] = 87,
	["x"] = 0,
	["y"] = 0
}
roundIndex[88] = {
	["index"] = 88,
	["x"] = 1,
	["y"] = 0
}
roundIndex[89] = {
	["index"] = 89,
	["x"] = 2,
	["y"] = 0
}
roundIndex[90] = {
	["index"] = 90,
	["x"] = 3,
	["y"] = 0
}
roundIndex[91] = {
	["index"] = 91,
	["x"] = 4,
	["y"] = 0
}
roundIndex[92] = {
	["index"] = 92,
	["x"] = 5,
	["y"] = 0
}
roundIndex[93] = {
	["index"] = 93,
	["x"] = 6,
	["y"] = 0
}
roundIndex[94] = {
	["index"] = 94,
	["x"] = 7,
	["y"] = 0
}
roundIndex[95] = {
	["index"] = 95,
	["x"] = 8,
	["y"] = 0
}
roundIndex[96] = {
	["index"] = 96,
	["x"] = 9,
	["y"] = 0
}
roundIndex[97] = {
	["index"] = 97,
	["x"] = 10,
	["y"] = 0
}
roundIndex[98] = {
	["index"] = 98,
	["x"] = 10,
	["y"] = 1
}
roundIndex[99] = {
	["index"] = 99,
	["x"] = 10,
	["y"] = 2
}
roundIndex[100] = {
	["index"] = 100,
	["x"] = 10,
	["y"] = 3
}
roundIndex[101] = {
	["index"] = 101,
	["x"] = 10,
	["y"] = 4
}
roundIndex[102] = {
	["index"] = 102,
	["x"] = 10,
	["y"] = 5
}
roundIndex[103] = {
	["index"] = 103,
	["x"] = 10,
	["y"] = 6
}
roundIndex[104] = {
	["index"] = 104,
	["x"] = 10,
	["y"] = 7
}
roundIndex[105] = {
	["index"] = 105,
	["x"] = 10,
	["y"] = 8
}
roundIndex[106] = {
	["index"] = 106,
	["x"] = 10,
	["y"] = 9
}
roundIndex[107] = {
	["index"] = 107,
	["x"] = 10,
	["y"] = 10
}
roundIndex[108] = {
	["index"] = 108,
	["x"] = 9,
	["y"] = 10
}
roundIndex[109] = {
	["index"] = 109,
	["x"] = 8,
	["y"] = 10
}
roundIndex[110] = {
	["index"] = 110,
	["x"] = 7,
	["y"] = 10
}
roundIndex[111] = {
	["index"] = 111,
	["x"] = 6,
	["y"] = 10
}
roundIndex[112] = {
	["index"] = 112,
	["x"] = 5,
	["y"] = 10
}
roundIndex[113] = {
	["index"] = 113,
	["x"] = 4,
	["y"] = 10
}
roundIndex[114] = {
	["index"] = 114,
	["x"] = 3,
	["y"] = 10
}
roundIndex[115] = {
	["index"] = 115,
	["x"] = 2,
	["y"] = 10
}
roundIndex[116] = {
	["index"] = 116,
	["x"] = 1,
	["y"] = 10
}
roundIndex[117] = {
	["index"] = 117,
	["x"] = 0,
	["y"] = 10
}
roundIndex[118] = {
	["index"] = 118,
	["x"] = 0,
	["y"] = 9
}
roundIndex[119] = {
	["index"] = 119,
	["x"] = 0,
	["y"] = 8
}
roundIndex[120] = {
	["index"] = 120,
	["x"] = 0,
	["y"] = 7
}
roundIndex[121] = {
	["index"] = 121,
	["x"] = 0,
	["y"] = 6
}
