local dwelling = GameDatas.HouseReturn.dwelling

dwelling[0] = {
	["level"] = 0,
	["wood"] = 0,
	["stone"] = 0,
	["iron"] = 0,
	["citizen"] = 0
}
dwelling[1] = {
	["level"] = 1,
	["wood"] = 100,
	["stone"] = 75,
	["iron"] = 75,
	["citizen"] = 0
}
dwelling[2] = {
	["level"] = 2,
	["wood"] = 240,
	["stone"] = 180,
	["iron"] = 180,
	["citizen"] = 0
}
dwelling[3] = {
	["level"] = 3,
	["wood"] = 480,
	["stone"] = 360,
	["iron"] = 360,
	["citizen"] = 0
}
dwelling[4] = {
	["level"] = 4,
	["wood"] = 720,
	["stone"] = 540,
	["iron"] = 540,
	["citizen"] = 0
}
dwelling[5] = {
	["level"] = 5,
	["wood"] = 960,
	["stone"] = 720,
	["iron"] = 720,
	["citizen"] = 0
}
dwelling[6] = {
	["level"] = 6,
	["wood"] = 1200,
	["stone"] = 900,
	["iron"] = 900,
	["citizen"] = 0
}
dwelling[7] = {
	["level"] = 7,
	["wood"] = 1440,
	["stone"] = 1080,
	["iron"] = 1080,
	["citizen"] = 0
}
dwelling[8] = {
	["level"] = 8,
	["wood"] = 1872,
	["stone"] = 1404,
	["iron"] = 1404,
	["citizen"] = 0
}
dwelling[9] = {
	["level"] = 9,
	["wood"] = 4608,
	["stone"] = 3456,
	["iron"] = 3456,
	["citizen"] = 0
}
dwelling[10] = {
	["level"] = 10,
	["wood"] = 8352,
	["stone"] = 6264,
	["iron"] = 6264,
	["citizen"] = 0
}
dwelling[11] = {
	["level"] = 11,
	["wood"] = 21197,
	["stone"] = 15898,
	["iron"] = 15898,
	["citizen"] = 0
}
dwelling[12] = {
	["level"] = 12,
	["wood"] = 31104,
	["stone"] = 23328,
	["iron"] = 23328,
	["citizen"] = 0
}
dwelling[13] = {
	["level"] = 13,
	["wood"] = 43316,
	["stone"] = 32487,
	["iron"] = 32487,
	["citizen"] = 0
}
dwelling[14] = {
	["level"] = 14,
	["wood"] = 58061,
	["stone"] = 43546,
	["iron"] = 43546,
	["citizen"] = 0
}
dwelling[15] = {
	["level"] = 15,
	["wood"] = 67572,
	["stone"] = 50679,
	["iron"] = 50679,
	["citizen"] = 0
}
dwelling[16] = {
	["level"] = 16,
	["wood"] = 104096,
	["stone"] = 78072,
	["iron"] = 78072,
	["citizen"] = 0
}
dwelling[17] = {
	["level"] = 17,
	["wood"] = 123760,
	["stone"] = 92820,
	["iron"] = 92820,
	["citizen"] = 0
}
dwelling[18] = {
	["level"] = 18,
	["wood"] = 143744,
	["stone"] = 107808,
	["iron"] = 107808,
	["citizen"] = 0
}
dwelling[19] = {
	["level"] = 19,
	["wood"] = 162336,
	["stone"] = 121752,
	["iron"] = 121752,
	["citizen"] = 0
}
dwelling[20] = {
	["level"] = 20,
	["wood"] = 177824,
	["stone"] = 133368,
	["iron"] = 133368,
	["citizen"] = 0
}
dwelling[21] = {
	["level"] = 21,
	["wood"] = 314295,
	["stone"] = 235721,
	["iron"] = 235721,
	["citizen"] = 0
}
dwelling[22] = {
	["level"] = 22,
	["wood"] = 340096,
	["stone"] = 255072,
	["iron"] = 255072,
	["citizen"] = 0
}
dwelling[23] = {
	["level"] = 23,
	["wood"] = 359962,
	["stone"] = 269972,
	["iron"] = 269972,
	["citizen"] = 0
}
dwelling[24] = {
	["level"] = 24,
	["wood"] = 413018,
	["stone"] = 309764,
	["iron"] = 309764,
	["citizen"] = 0
}
dwelling[25] = {
	["level"] = 25,
	["wood"] = 463664,
	["stone"] = 347748,
	["iron"] = 347748,
	["citizen"] = 0
}
dwelling[26] = {
	["level"] = 26,
	["wood"] = 859610,
	["stone"] = 644708,
	["iron"] = 644708,
	["citizen"] = 0
}
dwelling[27] = {
	["level"] = 27,
	["wood"] = 962605,
	["stone"] = 721954,
	["iron"] = 721954,
	["citizen"] = 0
}
dwelling[28] = {
	["level"] = 28,
	["wood"] = 1065613,
	["stone"] = 799210,
	["iron"] = 799210,
	["citizen"] = 0
}
dwelling[29] = {
	["level"] = 29,
	["wood"] = 1167709,
	["stone"] = 875782,
	["iron"] = 875782,
	["citizen"] = 0
}
dwelling[30] = {
	["level"] = 30,
	["wood"] = 1267968,
	["stone"] = 950976,
	["iron"] = 950976,
	["citizen"] = 0
}
dwelling[31] = {
	["level"] = 31,
	["wood"] = 2183028,
	["stone"] = 1637271,
	["iron"] = 1637271,
	["citizen"] = 0
}
dwelling[32] = {
	["level"] = 32,
	["wood"] = 2383642,
	["stone"] = 1787732,
	["iron"] = 1787732,
	["citizen"] = 0
}
dwelling[33] = {
	["level"] = 33,
	["wood"] = 2588042,
	["stone"] = 1941032,
	["iron"] = 1941032,
	["citizen"] = 0
}
dwelling[34] = {
	["level"] = 34,
	["wood"] = 2795610,
	["stone"] = 2096708,
	["iron"] = 2096708,
	["citizen"] = 0
}
dwelling[35] = {
	["level"] = 35,
	["wood"] = 3005728,
	["stone"] = 2254296,
	["iron"] = 2254296,
	["citizen"] = 0
}
dwelling[36] = {
	["level"] = 36,
	["wood"] = 4836224,
	["stone"] = 3627168,
	["iron"] = 3627168,
	["citizen"] = 0
}
dwelling[37] = {
	["level"] = 37,
	["wood"] = 5220432,
	["stone"] = 3915324,
	["iron"] = 3915324,
	["citizen"] = 0
}
dwelling[38] = {
	["level"] = 38,
	["wood"] = 5616512,
	["stone"] = 4212384,
	["iron"] = 4212384,
	["citizen"] = 0
}
dwelling[39] = {
	["level"] = 39,
	["wood"] = 6024192,
	["stone"] = 4518144,
	["iron"] = 4518144,
	["citizen"] = 0
}
dwelling[40] = {
	["level"] = 40,
	["wood"] = 8984000,
	["stone"] = 6738000,
	["iron"] = 6738000,
	["citizen"] = 0
}
