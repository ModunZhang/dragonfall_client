local levelup = GameDatas.Activities.levelup

levelup[1] = {
	["index"] = 1,
	["level"] = 6,
	["rewards"] = "special:dragonChest_1:1,resource:gemClass_1:1"
}
levelup[2] = {
	["index"] = 2,
	["level"] = 7,
	["rewards"] = "speedup:speedup_2:10,resource:gemClass_1:2"
}
levelup[3] = {
	["index"] = 3,
	["level"] = 8,
	["rewards"] = "special:stamina_1:2,resource:gemClass_1:3"
}
levelup[4] = {
	["index"] = 4,
	["level"] = 9,
	["rewards"] = "special:vipActive_3:1,resource:gemClass_1:4"
}
levelup[5] = {
	["index"] = 5,
	["level"] = 10,
	["rewards"] = "resource:casinoTokenClass_1:2,resource:gemClass_1:5"
}
levelup[6] = {
	["index"] = 6,
	["level"] = 11,
	["rewards"] = "speedup:warSpeedupClass_2:2,resource:gemClass_1:6"
}
levelup[7] = {
	["index"] = 7,
	["level"] = 12,
	["rewards"] = "speedup:speedup_3:10,resource:gemClass_1:7"
}
levelup[8] = {
	["index"] = 8,
	["level"] = 13,
	["rewards"] = "special:heroBlood_1:1,resource:gemClass_1:8"
}
levelup[9] = {
	["index"] = 9,
	["level"] = 14,
	["rewards"] = "resource:casinoTokenClass_2:1,resource:gemClass_1:9"
}
levelup[10] = {
	["index"] = 10,
	["level"] = 15,
	["rewards"] = "speedup:speedup_4:10,resource:gemClass_2:1"
}
