local woodcutter = GameDatas.HouseFunction.woodcutter

woodcutter[1] = {
	["level"] = 1,
	["production"] = 160,
	["power"] = 2
}
woodcutter[2] = {
	["level"] = 2,
	["production"] = 260,
	["power"] = 4
}
woodcutter[3] = {
	["level"] = 3,
	["production"] = 380,
	["power"] = 6
}
woodcutter[4] = {
	["level"] = 4,
	["production"] = 520,
	["power"] = 8
}
woodcutter[5] = {
	["level"] = 5,
	["production"] = 680,
	["power"] = 10
}
woodcutter[6] = {
	["level"] = 6,
	["production"] = 860,
	["power"] = 15
}
woodcutter[7] = {
	["level"] = 7,
	["production"] = 1060,
	["power"] = 30
}
woodcutter[8] = {
	["level"] = 8,
	["production"] = 1280,
	["power"] = 60
}
woodcutter[9] = {
	["level"] = 9,
	["production"] = 1520,
	["power"] = 140
}
woodcutter[10] = {
	["level"] = 10,
	["production"] = 1780,
	["power"] = 220
}
woodcutter[11] = {
	["level"] = 11,
	["production"] = 2060,
	["power"] = 310
}
woodcutter[12] = {
	["level"] = 12,
	["production"] = 2360,
	["power"] = 390
}
woodcutter[13] = {
	["level"] = 13,
	["production"] = 2680,
	["power"] = 520
}
woodcutter[14] = {
	["level"] = 14,
	["production"] = 3020,
	["power"] = 1070
}
woodcutter[15] = {
	["level"] = 15,
	["production"] = 3380,
	["power"] = 1670
}
woodcutter[16] = {
	["level"] = 16,
	["production"] = 3760,
	["power"] = 2320
}
woodcutter[17] = {
	["level"] = 17,
	["production"] = 4160,
	["power"] = 3400
}
woodcutter[18] = {
	["level"] = 18,
	["production"] = 4580,
	["power"] = 4180
}
woodcutter[19] = {
	["level"] = 19,
	["production"] = 5020,
	["power"] = 5110
}
woodcutter[20] = {
	["level"] = 20,
	["production"] = 5480,
	["power"] = 6000
}
woodcutter[21] = {
	["level"] = 21,
	["production"] = 5960,
	["power"] = 8150
}
woodcutter[22] = {
	["level"] = 22,
	["production"] = 6460,
	["power"] = 9350
}
woodcutter[23] = {
	["level"] = 23,
	["production"] = 6980,
	["power"] = 10790
}
woodcutter[24] = {
	["level"] = 24,
	["production"] = 7520,
	["power"] = 12140
}
woodcutter[25] = {
	["level"] = 25,
	["production"] = 8080,
	["power"] = 16590
}
woodcutter[26] = {
	["level"] = 26,
	["production"] = 8660,
	["power"] = 18520
}
woodcutter[27] = {
	["level"] = 27,
	["production"] = 9260,
	["power"] = 20830
}
woodcutter[28] = {
	["level"] = 28,
	["production"] = 9880,
	["power"] = 23020
}
woodcutter[29] = {
	["level"] = 29,
	["production"] = 10520,
	["power"] = 32770
}
woodcutter[30] = {
	["level"] = 30,
	["production"] = 11180,
	["power"] = 37840
}
woodcutter[31] = {
	["level"] = 31,
	["production"] = 11880,
	["power"] = 43700
}
woodcutter[32] = {
	["level"] = 32,
	["production"] = 12620,
	["power"] = 49580
}
woodcutter[33] = {
	["level"] = 33,
	["production"] = 13400,
	["power"] = 67870
}
woodcutter[34] = {
	["level"] = 34,
	["production"] = 14220,
	["power"] = 76270
}
woodcutter[35] = {
	["level"] = 35,
	["production"] = 15080,
	["power"] = 85910
}
woodcutter[36] = {
	["level"] = 36,
	["production"] = 15980,
	["power"] = 95620
}
woodcutter[37] = {
	["level"] = 37,
	["production"] = 16920,
	["power"] = 128590
}
woodcutter[38] = {
	["level"] = 38,
	["production"] = 17900,
	["power"] = 142260
}
woodcutter[39] = {
	["level"] = 39,
	["production"] = 18920,
	["power"] = 157710
}
woodcutter[40] = {
	["level"] = 40,
	["production"] = 20000,
	["power"] = 173480
}
