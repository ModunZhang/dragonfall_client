local allianceMap_2 = GameDatas.AllianceMap.allianceMap_2

allianceMap_2[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 1
}
allianceMap_2[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 1
}
allianceMap_2[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 1
}
allianceMap_2[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 1
}
allianceMap_2[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 1
}
allianceMap_2[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 1
}
allianceMap_2[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 1
}
allianceMap_2[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 1
}
allianceMap_2[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 2
}
allianceMap_2[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 2
}
allianceMap_2[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 2
}
allianceMap_2[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 2
}
allianceMap_2[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 2
}
allianceMap_2[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 2
}
allianceMap_2[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 2
}
allianceMap_2[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 2
}
allianceMap_2[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 2
}
allianceMap_2[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 2
}
allianceMap_2[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_3",
	["x"] = 20,
	["y"] = 2
}
allianceMap_2[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_1",
	["x"] = 21,
	["y"] = 2
}
allianceMap_2[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 2
}
allianceMap_2[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 2
}
allianceMap_2[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_2",
	["x"] = 24,
	["y"] = 2
}
allianceMap_2[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 2
}
allianceMap_2[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 2
}
allianceMap_2[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 3
}
allianceMap_2[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 3
}
allianceMap_2[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 3
}
allianceMap_2[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 3
}
allianceMap_2[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 3
}
allianceMap_2[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 3
}
allianceMap_2[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 3
}
allianceMap_2[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 3
}
allianceMap_2[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 3
}
allianceMap_2[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 3
}
allianceMap_2[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 3
}
allianceMap_2[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 3
}
allianceMap_2[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 4
}
allianceMap_2[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 4
}
allianceMap_2[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 4
}
allianceMap_2[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 4
}
allianceMap_2[41] = {
	["index"] = 41,
	["name"] = "decorate_lake_2",
	["x"] = 10,
	["y"] = 4
}
allianceMap_2[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_8",
	["x"] = 12,
	["y"] = 4
}
allianceMap_2[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 4
}
allianceMap_2[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 4
}
allianceMap_2[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 4
}
allianceMap_2[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 4
}
allianceMap_2[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 4
}
allianceMap_2[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 4
}
allianceMap_2[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 4
}
allianceMap_2[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 4
}
allianceMap_2[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 5
}
allianceMap_2[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 5
}
allianceMap_2[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 5
}
allianceMap_2[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 5
}
allianceMap_2[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 5
}
allianceMap_2[56] = {
	["index"] = 56,
	["name"] = "decorate_mountain_1",
	["x"] = 22,
	["y"] = 5
}
allianceMap_2[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 5
}
allianceMap_2[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 6
}
allianceMap_2[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 6
}
allianceMap_2[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 6
}
allianceMap_2[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 6
}
allianceMap_2[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 6
}
allianceMap_2[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 6
}
allianceMap_2[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 6
}
allianceMap_2[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 6
}
allianceMap_2[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 6
}
allianceMap_2[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 6
}
allianceMap_2[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 6
}
allianceMap_2[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 7
}
allianceMap_2[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 7
}
allianceMap_2[71] = {
	["index"] = 71,
	["name"] = "decorate_mountain_2",
	["x"] = 5,
	["y"] = 7
}
allianceMap_2[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 7
}
allianceMap_2[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 7
}
allianceMap_2[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 7
}
allianceMap_2[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 7
}
allianceMap_2[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 8
}
allianceMap_2[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 8
}
allianceMap_2[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 8
}
allianceMap_2[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 8
}
allianceMap_2[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 8
}
allianceMap_2[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 8
}
allianceMap_2[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 8
}
allianceMap_2[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 8
}
allianceMap_2[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 9
}
allianceMap_2[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 9
}
allianceMap_2[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_9",
	["x"] = 5,
	["y"] = 9
}
allianceMap_2[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 9
}
allianceMap_2[88] = {
	["index"] = 88,
	["name"] = "decorate_mountain_2",
	["x"] = 27,
	["y"] = 9
}
allianceMap_2[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 9
}
allianceMap_2[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 10
}
allianceMap_2[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 10
}
allianceMap_2[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 10
}
allianceMap_2[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 10
}
allianceMap_2[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 10
}
allianceMap_2[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 10
}
allianceMap_2[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 11
}
allianceMap_2[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 11
}
allianceMap_2[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 11
}
allianceMap_2[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 11
}
allianceMap_2[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 12
}
allianceMap_2[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 12
}
allianceMap_2[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 12
}
allianceMap_2[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 12
}
allianceMap_2[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 12
}
allianceMap_2[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 12
}
allianceMap_2[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 12
}
allianceMap_2[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 12
}
allianceMap_2[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 12
}
allianceMap_2[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 13
}
allianceMap_2[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 13
}
allianceMap_2[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 13
}
allianceMap_2[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 13
}
allianceMap_2[113] = {
	["index"] = 113,
	["name"] = "palace",
	["x"] = 13,
	["y"] = 13
}
allianceMap_2[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 13
}
allianceMap_2[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 13
}
allianceMap_2[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 13
}
allianceMap_2[117] = {
	["index"] = 117,
	["name"] = "bloodSpring",
	["x"] = 17,
	["y"] = 13
}
allianceMap_2[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 13
}
allianceMap_2[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 13
}
allianceMap_2[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 13
}
allianceMap_2[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 13
}
allianceMap_2[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 13
}
allianceMap_2[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 14
}
allianceMap_2[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 14
}
allianceMap_2[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 14
}
allianceMap_2[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 14
}
allianceMap_2[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 14
}
allianceMap_2[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 14
}
allianceMap_2[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
allianceMap_2[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 14
}
allianceMap_2[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 14
}
allianceMap_2[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 14
}
allianceMap_2[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 14
}
allianceMap_2[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 14
}
allianceMap_2[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 15
}
allianceMap_2[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 15
}
allianceMap_2[137] = {
	["index"] = 137,
	["name"] = "orderHall",
	["x"] = 13,
	["y"] = 15
}
allianceMap_2[138] = {
	["index"] = 138,
	["name"] = "shop",
	["x"] = 17,
	["y"] = 15
}
allianceMap_2[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 15
}
allianceMap_2[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 15
}
allianceMap_2[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 16
}
allianceMap_2[142] = {
	["index"] = 142,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 16
}
allianceMap_2[143] = {
	["index"] = 143,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 16
}
allianceMap_2[144] = {
	["index"] = 144,
	["name"] = "decorate_lake_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_2[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_2[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 16
}
allianceMap_2[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 16
}
allianceMap_2[148] = {
	["index"] = 148,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 16
}
allianceMap_2[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 17
}
allianceMap_2[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 17
}
allianceMap_2[151] = {
	["index"] = 151,
	["name"] = "decorate_mountain_1",
	["x"] = 6,
	["y"] = 17
}
allianceMap_2[152] = {
	["index"] = 152,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 17
}
allianceMap_2[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 17
}
allianceMap_2[154] = {
	["index"] = 154,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 17
}
allianceMap_2[155] = {
	["index"] = 155,
	["name"] = "shrine",
	["x"] = 13,
	["y"] = 17
}
allianceMap_2[156] = {
	["index"] = 156,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
allianceMap_2[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 17
}
allianceMap_2[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 17
}
allianceMap_2[159] = {
	["index"] = 159,
	["name"] = "watchTower",
	["x"] = 17,
	["y"] = 17
}
allianceMap_2[160] = {
	["index"] = 160,
	["name"] = "decorate_lake_2",
	["x"] = 28,
	["y"] = 17
}
allianceMap_2[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 18
}
allianceMap_2[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 18
}
allianceMap_2[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 18
}
allianceMap_2[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 18
}
allianceMap_2[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 18
}
allianceMap_2[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 18
}
allianceMap_2[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 18
}
allianceMap_2[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 18
}
allianceMap_2[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 18
}
allianceMap_2[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 18
}
allianceMap_2[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 18
}
allianceMap_2[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 18
}
allianceMap_2[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 19
}
allianceMap_2[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 19
}
allianceMap_2[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 19
}
allianceMap_2[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 19
}
allianceMap_2[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 19
}
allianceMap_2[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 20
}
allianceMap_2[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 20
}
allianceMap_2[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 20
}
allianceMap_2[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 20
}
allianceMap_2[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 21
}
allianceMap_2[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 21
}
allianceMap_2[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_8",
	["x"] = 28,
	["y"] = 21
}
allianceMap_2[185] = {
	["index"] = 185,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 22
}
allianceMap_2[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 22
}
allianceMap_2[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 22
}
allianceMap_2[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 22
}
allianceMap_2[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 22
}
allianceMap_2[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 22
}
allianceMap_2[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 23
}
allianceMap_2[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 23
}
allianceMap_2[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 23
}
allianceMap_2[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 23
}
allianceMap_2[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 23
}
allianceMap_2[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 24
}
allianceMap_2[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 24
}
allianceMap_2[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 24
}
allianceMap_2[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 24
}
allianceMap_2[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 24
}
allianceMap_2[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 24
}
allianceMap_2[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 24
}
allianceMap_2[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 25
}
allianceMap_2[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 25
}
allianceMap_2[205] = {
	["index"] = 205,
	["name"] = "decorate_lake_2",
	["x"] = 5,
	["y"] = 25
}
allianceMap_2[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 25
}
allianceMap_2[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 25
}
allianceMap_2[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_6",
	["x"] = 9,
	["y"] = 25
}
allianceMap_2[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 25
}
allianceMap_2[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 25
}
allianceMap_2[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 26
}
allianceMap_2[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 26
}
allianceMap_2[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 26
}
allianceMap_2[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 26
}
allianceMap_2[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 26
}
allianceMap_2[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 26
}
allianceMap_2[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 26
}
allianceMap_2[218] = {
	["index"] = 218,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 26
}
allianceMap_2[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 26
}
allianceMap_2[220] = {
	["index"] = 220,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 26
}
allianceMap_2[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 26
}
allianceMap_2[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 26
}
allianceMap_2[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 27
}
allianceMap_2[224] = {
	["index"] = 224,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 27
}
allianceMap_2[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 27
}
allianceMap_2[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 27
}
allianceMap_2[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 27
}
allianceMap_2[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 27
}
allianceMap_2[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 27
}
allianceMap_2[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 27
}
allianceMap_2[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 27
}
allianceMap_2[232] = {
	["index"] = 232,
	["name"] = "decorate_mountain_1",
	["x"] = 25,
	["y"] = 27
}
allianceMap_2[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 27
}
allianceMap_2[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 27
}
allianceMap_2[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 28
}
allianceMap_2[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 28
}
allianceMap_2[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 28
}
allianceMap_2[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 28
}
allianceMap_2[239] = {
	["index"] = 239,
	["name"] = "decorate_mountain_2",
	["x"] = 13,
	["y"] = 28
}
allianceMap_2[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 28
}
allianceMap_2[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 28
}
allianceMap_2[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 28
}
allianceMap_2[243] = {
	["index"] = 243,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 28
}
allianceMap_2[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 28
}
allianceMap_2[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 28
}
allianceMap_2[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 28
}
allianceMap_2[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 28
}
allianceMap_2[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_4",
	["x"] = 24,
	["y"] = 28
}
allianceMap_2[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 28
}
allianceMap_2[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 28
}
allianceMap_2[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 28
}
allianceMap_2[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 29
}
allianceMap_2[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 29
}
allianceMap_2[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 29
}
allianceMap_2[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 29
}
allianceMap_2[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 29
}
allianceMap_2[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 29
}
allianceMap_2[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_4",
	["x"] = 23,
	["y"] = 29
}
allianceMap_2[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 29
}
allianceMap_2[260] = {
	["index"] = 260,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 29
}
