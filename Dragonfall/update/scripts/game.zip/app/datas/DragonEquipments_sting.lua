local sting = GameDatas.DragonEquipments.sting

sting["2_0"] = {
	["star"] = "2_0",
	["enhanceExp"] = 400,
	["strength"] = 8,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["2_1"] = {
	["star"] = "2_1",
	["enhanceExp"] = 800,
	["strength"] = 11,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["2_2"] = {
	["star"] = "2_2",
	["enhanceExp"] = 2400,
	["strength"] = 14,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["3_0"] = {
	["star"] = "3_0",
	["enhanceExp"] = 1600,
	["strength"] = 18,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["3_1"] = {
	["star"] = "3_1",
	["enhanceExp"] = 3200,
	["strength"] = 23,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["3_2"] = {
	["star"] = "3_2",
	["enhanceExp"] = 9600,
	["strength"] = 28,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["3_3"] = {
	["star"] = "3_3",
	["enhanceExp"] = 12800,
	["strength"] = 36,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["4_0"] = {
	["star"] = "4_0",
	["enhanceExp"] = 5600,
	["strength"] = 40,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["4_1"] = {
	["star"] = "4_1",
	["enhanceExp"] = 11200,
	["strength"] = 50,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["4_2"] = {
	["star"] = "4_2",
	["enhanceExp"] = 33600,
	["strength"] = 62,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["4_3"] = {
	["star"] = "4_3",
	["enhanceExp"] = 44800,
	["strength"] = 77,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["4_4"] = {
	["star"] = "4_4",
	["enhanceExp"] = 89600,
	["strength"] = 96,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_0"] = {
	["star"] = "5_0",
	["enhanceExp"] = 22400,
	["strength"] = 116,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_1"] = {
	["star"] = "5_1",
	["enhanceExp"] = 44800,
	["strength"] = 136,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_2"] = {
	["star"] = "5_2",
	["enhanceExp"] = 134400,
	["strength"] = 160,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_3"] = {
	["star"] = "5_3",
	["enhanceExp"] = 179200,
	["strength"] = 188,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_4"] = {
	["star"] = "5_4",
	["enhanceExp"] = 358400,
	["strength"] = 221,
	["vitality"] = 0,
	["leadership"] = 0
}
sting["5_5"] = {
	["star"] = "5_5",
	["enhanceExp"] = 716800,
	["strength"] = 260,
	["vitality"] = 0,
	["leadership"] = 0
}
