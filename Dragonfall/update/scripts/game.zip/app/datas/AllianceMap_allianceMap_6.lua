local allianceMap_6 = GameDatas.AllianceMap.allianceMap_6

allianceMap_6[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 1
}
allianceMap_6[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 1
}
allianceMap_6[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 1
}
allianceMap_6[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 1
}
allianceMap_6[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 1
}
allianceMap_6[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 1
}
allianceMap_6[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 2
}
allianceMap_6[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 2
}
allianceMap_6[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 2
}
allianceMap_6[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 2
}
allianceMap_6[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 2
}
allianceMap_6[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 2
}
allianceMap_6[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 2
}
allianceMap_6[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 2
}
allianceMap_6[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 2
}
allianceMap_6[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_2",
	["x"] = 20,
	["y"] = 2
}
allianceMap_6[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 2
}
allianceMap_6[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 2
}
allianceMap_6[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 3
}
allianceMap_6[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 3
}
allianceMap_6[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 3
}
allianceMap_6[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 3
}
allianceMap_6[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 3
}
allianceMap_6[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 3
}
allianceMap_6[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 3
}
allianceMap_6[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 3
}
allianceMap_6[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 3
}
allianceMap_6[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 3
}
allianceMap_6[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 3
}
allianceMap_6[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 3
}
allianceMap_6[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 3
}
allianceMap_6[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 3
}
allianceMap_6[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 3
}
allianceMap_6[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 3
}
allianceMap_6[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 4
}
allianceMap_6[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 4
}
allianceMap_6[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 4
}
allianceMap_6[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 4
}
allianceMap_6[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 4
}
allianceMap_6[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 4
}
allianceMap_6[40] = {
	["index"] = 40,
	["name"] = "decorate_mountain_2",
	["x"] = 16,
	["y"] = 4
}
allianceMap_6[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 4
}
allianceMap_6[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 4
}
allianceMap_6[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 4
}
allianceMap_6[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 5
}
allianceMap_6[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 5
}
allianceMap_6[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 5
}
allianceMap_6[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 5
}
allianceMap_6[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 5
}
allianceMap_6[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 5
}
allianceMap_6[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 5
}
allianceMap_6[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 5
}
allianceMap_6[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 5
}
allianceMap_6[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 5
}
allianceMap_6[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 5
}
allianceMap_6[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 6
}
allianceMap_6[56] = {
	["index"] = 56,
	["name"] = "decorate_lake_1",
	["x"] = 6,
	["y"] = 6
}
allianceMap_6[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 6
}
allianceMap_6[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 6
}
allianceMap_6[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 6
}
allianceMap_6[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 21,
	["y"] = 6
}
allianceMap_6[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_2",
	["x"] = 22,
	["y"] = 6
}
allianceMap_6[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 6
}
allianceMap_6[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 6
}
allianceMap_6[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 6
}
allianceMap_6[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 6
}
allianceMap_6[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 7
}
allianceMap_6[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 7
}
allianceMap_6[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_1",
	["x"] = 22,
	["y"] = 7
}
allianceMap_6[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 7
}
allianceMap_6[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 7
}
allianceMap_6[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 8
}
allianceMap_6[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 8
}
allianceMap_6[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_1",
	["x"] = 24,
	["y"] = 8
}
allianceMap_6[74] = {
	["index"] = 74,
	["name"] = "decorate_lake_1",
	["x"] = 27,
	["y"] = 8
}
allianceMap_6[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_6",
	["x"] = 29,
	["y"] = 8
}
allianceMap_6[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 9
}
allianceMap_6[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 9
}
allianceMap_6[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 9
}
allianceMap_6[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 9
}
allianceMap_6[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 9
}
allianceMap_6[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 9
}
allianceMap_6[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 10
}
allianceMap_6[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 10
}
allianceMap_6[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 10
}
allianceMap_6[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_1",
	["x"] = 27,
	["y"] = 10
}
allianceMap_6[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 10
}
allianceMap_6[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 11
}
allianceMap_6[88] = {
	["index"] = 88,
	["name"] = "decorate_lake_2",
	["x"] = 4,
	["y"] = 11
}
allianceMap_6[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 11
}
allianceMap_6[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 11
}
allianceMap_6[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 11
}
allianceMap_6[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 11
}
allianceMap_6[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 12
}
allianceMap_6[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 12
}
allianceMap_6[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 12
}
allianceMap_6[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 12
}
allianceMap_6[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 12
}
allianceMap_6[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 12
}
allianceMap_6[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 12
}
allianceMap_6[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 12
}
allianceMap_6[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 12
}
allianceMap_6[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 12
}
allianceMap_6[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_3",
	["x"] = 27,
	["y"] = 12
}
allianceMap_6[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 12
}
allianceMap_6[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 13
}
allianceMap_6[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 13
}
allianceMap_6[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_8",
	["x"] = 4,
	["y"] = 13
}
allianceMap_6[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 13
}
allianceMap_6[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 13
}
allianceMap_6[110] = {
	["index"] = 110,
	["name"] = "palace",
	["x"] = 13,
	["y"] = 13
}
allianceMap_6[111] = {
	["index"] = 111,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 13
}
allianceMap_6[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 13
}
allianceMap_6[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 13
}
allianceMap_6[114] = {
	["index"] = 114,
	["name"] = "bloodSpring",
	["x"] = 17,
	["y"] = 13
}
allianceMap_6[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 13
}
allianceMap_6[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 13
}
allianceMap_6[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 13
}
allianceMap_6[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_2",
	["x"] = 28,
	["y"] = 13
}
allianceMap_6[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 13
}
allianceMap_6[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 14
}
allianceMap_6[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 14
}
allianceMap_6[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 14
}
allianceMap_6[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 14
}
allianceMap_6[124] = {
	["index"] = 124,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 14
}
allianceMap_6[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 14
}
allianceMap_6[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 14
}
allianceMap_6[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 14
}
allianceMap_6[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_2",
	["x"] = 29,
	["y"] = 14
}
allianceMap_6[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 15
}
allianceMap_6[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 15
}
allianceMap_6[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 15
}
allianceMap_6[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 15
}
allianceMap_6[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 15
}
allianceMap_6[134] = {
	["index"] = 134,
	["name"] = "orderHall",
	["x"] = 13,
	["y"] = 15
}
allianceMap_6[135] = {
	["index"] = 135,
	["name"] = "shop",
	["x"] = 17,
	["y"] = 15
}
allianceMap_6[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_2",
	["x"] = 25,
	["y"] = 15
}
allianceMap_6[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 15
}
allianceMap_6[138] = {
	["index"] = 138,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 16
}
allianceMap_6[139] = {
	["index"] = 139,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 16
}
allianceMap_6[140] = {
	["index"] = 140,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 16
}
allianceMap_6[141] = {
	["index"] = 141,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 16
}
allianceMap_6[142] = {
	["index"] = 142,
	["name"] = "decorate_mountain_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_6[143] = {
	["index"] = 143,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_6[144] = {
	["index"] = 144,
	["name"] = "decorate_mountain_2",
	["x"] = 28,
	["y"] = 16
}
allianceMap_6[145] = {
	["index"] = 145,
	["name"] = "decorate_tree_4",
	["x"] = 29,
	["y"] = 16
}
allianceMap_6[146] = {
	["index"] = 146,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 17
}
allianceMap_6[147] = {
	["index"] = 147,
	["name"] = "decorate_tree_4",
	["x"] = 12,
	["y"] = 17
}
allianceMap_6[148] = {
	["index"] = 148,
	["name"] = "shrine",
	["x"] = 13,
	["y"] = 17
}
allianceMap_6[149] = {
	["index"] = 149,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
allianceMap_6[150] = {
	["index"] = 150,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 17
}
allianceMap_6[151] = {
	["index"] = 151,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 17
}
allianceMap_6[152] = {
	["index"] = 152,
	["name"] = "watchTower",
	["x"] = 17,
	["y"] = 17
}
allianceMap_6[153] = {
	["index"] = 153,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 17
}
allianceMap_6[154] = {
	["index"] = 154,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 17
}
allianceMap_6[155] = {
	["index"] = 155,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 17
}
allianceMap_6[156] = {
	["index"] = 156,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 17
}
allianceMap_6[157] = {
	["index"] = 157,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 17
}
allianceMap_6[158] = {
	["index"] = 158,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 18
}
allianceMap_6[159] = {
	["index"] = 159,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 18
}
allianceMap_6[160] = {
	["index"] = 160,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 18
}
allianceMap_6[161] = {
	["index"] = 161,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 18
}
allianceMap_6[162] = {
	["index"] = 162,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 18
}
allianceMap_6[163] = {
	["index"] = 163,
	["name"] = "decorate_tree_2",
	["x"] = 27,
	["y"] = 18
}
allianceMap_6[164] = {
	["index"] = 164,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 18
}
allianceMap_6[165] = {
	["index"] = 165,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 19
}
allianceMap_6[166] = {
	["index"] = 166,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 19
}
allianceMap_6[167] = {
	["index"] = 167,
	["name"] = "decorate_tree_8",
	["x"] = 28,
	["y"] = 19
}
allianceMap_6[168] = {
	["index"] = 168,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 20
}
allianceMap_6[169] = {
	["index"] = 169,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 20
}
allianceMap_6[170] = {
	["index"] = 170,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 20
}
allianceMap_6[171] = {
	["index"] = 171,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 20
}
allianceMap_6[172] = {
	["index"] = 172,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 20
}
allianceMap_6[173] = {
	["index"] = 173,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 21
}
allianceMap_6[174] = {
	["index"] = 174,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 21
}
allianceMap_6[175] = {
	["index"] = 175,
	["name"] = "decorate_tree_3",
	["x"] = 25,
	["y"] = 21
}
allianceMap_6[176] = {
	["index"] = 176,
	["name"] = "decorate_tree_2",
	["x"] = 26,
	["y"] = 21
}
allianceMap_6[177] = {
	["index"] = 177,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 22
}
allianceMap_6[178] = {
	["index"] = 178,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 22
}
allianceMap_6[179] = {
	["index"] = 179,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 22
}
allianceMap_6[180] = {
	["index"] = 180,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 22
}
allianceMap_6[181] = {
	["index"] = 181,
	["name"] = "decorate_tree_4",
	["x"] = 25,
	["y"] = 22
}
allianceMap_6[182] = {
	["index"] = 182,
	["name"] = "decorate_tree_4",
	["x"] = 26,
	["y"] = 22
}
allianceMap_6[183] = {
	["index"] = 183,
	["name"] = "decorate_tree_3",
	["x"] = 28,
	["y"] = 22
}
allianceMap_6[184] = {
	["index"] = 184,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 23
}
allianceMap_6[185] = {
	["index"] = 185,
	["name"] = "decorate_mountain_2",
	["x"] = 5,
	["y"] = 23
}
allianceMap_6[186] = {
	["index"] = 186,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 23
}
allianceMap_6[187] = {
	["index"] = 187,
	["name"] = "decorate_tree_2",
	["x"] = 23,
	["y"] = 23
}
allianceMap_6[188] = {
	["index"] = 188,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 23
}
allianceMap_6[189] = {
	["index"] = 189,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 23
}
allianceMap_6[190] = {
	["index"] = 190,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 23
}
allianceMap_6[191] = {
	["index"] = 191,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 23
}
allianceMap_6[192] = {
	["index"] = 192,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 24
}
allianceMap_6[193] = {
	["index"] = 193,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 24
}
allianceMap_6[194] = {
	["index"] = 194,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 24
}
allianceMap_6[195] = {
	["index"] = 195,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 24
}
allianceMap_6[196] = {
	["index"] = 196,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 24
}
allianceMap_6[197] = {
	["index"] = 197,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 24
}
allianceMap_6[198] = {
	["index"] = 198,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 24
}
allianceMap_6[199] = {
	["index"] = 199,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 24
}
allianceMap_6[200] = {
	["index"] = 200,
	["name"] = "decorate_tree_1",
	["x"] = 29,
	["y"] = 24
}
allianceMap_6[201] = {
	["index"] = 201,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 25
}
allianceMap_6[202] = {
	["index"] = 202,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 25
}
allianceMap_6[203] = {
	["index"] = 203,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 25
}
allianceMap_6[204] = {
	["index"] = 204,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 25
}
allianceMap_6[205] = {
	["index"] = 205,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 25
}
allianceMap_6[206] = {
	["index"] = 206,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 25
}
allianceMap_6[207] = {
	["index"] = 207,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 25
}
allianceMap_6[208] = {
	["index"] = 208,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 25
}
allianceMap_6[209] = {
	["index"] = 209,
	["name"] = "decorate_tree_3",
	["x"] = 26,
	["y"] = 25
}
allianceMap_6[210] = {
	["index"] = 210,
	["name"] = "decorate_tree_1",
	["x"] = 28,
	["y"] = 25
}
allianceMap_6[211] = {
	["index"] = 211,
	["name"] = "decorate_tree_9",
	["x"] = 3,
	["y"] = 26
}
allianceMap_6[212] = {
	["index"] = 212,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 26
}
allianceMap_6[213] = {
	["index"] = 213,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 26
}
allianceMap_6[214] = {
	["index"] = 214,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 26
}
allianceMap_6[215] = {
	["index"] = 215,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 26
}
allianceMap_6[216] = {
	["index"] = 216,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 26
}
allianceMap_6[217] = {
	["index"] = 217,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 26
}
allianceMap_6[218] = {
	["index"] = 218,
	["name"] = "decorate_tree_4",
	["x"] = 21,
	["y"] = 26
}
allianceMap_6[219] = {
	["index"] = 219,
	["name"] = "decorate_tree_3",
	["x"] = 22,
	["y"] = 26
}
allianceMap_6[220] = {
	["index"] = 220,
	["name"] = "decorate_lake_2",
	["x"] = 25,
	["y"] = 26
}
allianceMap_6[221] = {
	["index"] = 221,
	["name"] = "decorate_tree_1",
	["x"] = 26,
	["y"] = 26
}
allianceMap_6[222] = {
	["index"] = 222,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 27
}
allianceMap_6[223] = {
	["index"] = 223,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 27
}
allianceMap_6[224] = {
	["index"] = 224,
	["name"] = "decorate_lake_2",
	["x"] = 9,
	["y"] = 27
}
allianceMap_6[225] = {
	["index"] = 225,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 27
}
allianceMap_6[226] = {
	["index"] = 226,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 27
}
allianceMap_6[227] = {
	["index"] = 227,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 27
}
allianceMap_6[228] = {
	["index"] = 228,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 27
}
allianceMap_6[229] = {
	["index"] = 229,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 27
}
allianceMap_6[230] = {
	["index"] = 230,
	["name"] = "decorate_tree_4",
	["x"] = 22,
	["y"] = 27
}
allianceMap_6[231] = {
	["index"] = 231,
	["name"] = "decorate_tree_1",
	["x"] = 23,
	["y"] = 27
}
allianceMap_6[232] = {
	["index"] = 232,
	["name"] = "decorate_tree_3",
	["x"] = 24,
	["y"] = 27
}
allianceMap_6[233] = {
	["index"] = 233,
	["name"] = "decorate_tree_1",
	["x"] = 25,
	["y"] = 27
}
allianceMap_6[234] = {
	["index"] = 234,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 28
}
allianceMap_6[235] = {
	["index"] = 235,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 28
}
allianceMap_6[236] = {
	["index"] = 236,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 28
}
allianceMap_6[237] = {
	["index"] = 237,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 28
}
allianceMap_6[238] = {
	["index"] = 238,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 28
}
allianceMap_6[239] = {
	["index"] = 239,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 28
}
allianceMap_6[240] = {
	["index"] = 240,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 28
}
allianceMap_6[241] = {
	["index"] = 241,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 28
}
allianceMap_6[242] = {
	["index"] = 242,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 28
}
allianceMap_6[243] = {
	["index"] = 243,
	["name"] = "decorate_lake_1",
	["x"] = 18,
	["y"] = 28
}
allianceMap_6[244] = {
	["index"] = 244,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 28
}
allianceMap_6[245] = {
	["index"] = 245,
	["name"] = "decorate_tree_4",
	["x"] = 20,
	["y"] = 28
}
allianceMap_6[246] = {
	["index"] = 246,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 28
}
allianceMap_6[247] = {
	["index"] = 247,
	["name"] = "decorate_tree_3",
	["x"] = 29,
	["y"] = 28
}
allianceMap_6[248] = {
	["index"] = 248,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 29
}
allianceMap_6[249] = {
	["index"] = 249,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 29
}
allianceMap_6[250] = {
	["index"] = 250,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 29
}
allianceMap_6[251] = {
	["index"] = 251,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 29
}
allianceMap_6[252] = {
	["index"] = 252,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 29
}
allianceMap_6[253] = {
	["index"] = 253,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 29
}
allianceMap_6[254] = {
	["index"] = 254,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 29
}
allianceMap_6[255] = {
	["index"] = 255,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 29
}
allianceMap_6[256] = {
	["index"] = 256,
	["name"] = "decorate_tree_3",
	["x"] = 21,
	["y"] = 29
}
allianceMap_6[257] = {
	["index"] = 257,
	["name"] = "decorate_tree_3",
	["x"] = 23,
	["y"] = 29
}
allianceMap_6[258] = {
	["index"] = 258,
	["name"] = "decorate_tree_4",
	["x"] = 27,
	["y"] = 29
}
allianceMap_6[259] = {
	["index"] = 259,
	["name"] = "decorate_tree_4",
	["x"] = 28,
	["y"] = 29
}
