local alliance_name_single_name = GameDatas.ClientInitGame.alliance_name_single_name

alliance_name_single_name[1] = {
	["index"] = 1,
	["value"] = "Atlas"
}
alliance_name_single_name[2] = {
	["index"] = 2,
	["value"] = "Titan"
}
alliance_name_single_name[3] = {
	["index"] = 3,
	["value"] = "Cronos"
}
alliance_name_single_name[4] = {
	["index"] = 4,
	["value"] = "Pandora"
}
alliance_name_single_name[5] = {
	["index"] = 5,
	["value"] = "Olympic"
}
alliance_name_single_name[6] = {
	["index"] = 6,
	["value"] = "Vulcan"
}
alliance_name_single_name[7] = {
	["index"] = 7,
	["value"] = "Venus"
}
alliance_name_single_name[8] = {
	["index"] = 8,
	["value"] = "Muses"
}
alliance_name_single_name[9] = {
	["index"] = 9,
	["value"] = "Pan"
}
alliance_name_single_name[10] = {
	["index"] = 10,
	["value"] = "Flora"
}
alliance_name_single_name[11] = {
	["index"] = 11,
	["value"] = "Hygeia"
}
alliance_name_single_name[12] = {
	["index"] = 12,
	["value"] = "Gaea"
}
alliance_name_single_name[13] = {
	["index"] = 13,
	["value"] = "Uranus"
}
alliance_name_single_name[14] = {
	["index"] = 14,
	["value"] = "Rhea"
}
alliance_name_single_name[15] = {
	["index"] = 15,
	["value"] = "Hera"
}
alliance_name_single_name[16] = {
	["index"] = 16,
	["value"] = "Zeus"
}
alliance_name_single_name[17] = {
	["index"] = 17,
	["value"] = "Hades"
}
alliance_name_single_name[18] = {
	["index"] = 18,
	["value"] = "Demeter"
}
alliance_name_single_name[19] = {
	["index"] = 19,
	["value"] = "Hestia"
}
alliance_name_single_name[20] = {
	["index"] = 20,
	["value"] = "Apollo"
}
alliance_name_single_name[21] = {
	["index"] = 21,
	["value"] = "Artemis"
}
alliance_name_single_name[22] = {
	["index"] = 22,
	["value"] = "Athene"
}
alliance_name_single_name[23] = {
	["index"] = 23,
	["value"] = "Ares"
}
alliance_name_single_name[24] = {
	["index"] = 24,
	["value"] = "Hebe"
}
alliance_name_single_name[25] = {
	["index"] = 25,
	["value"] = "Hermes"
}
alliance_name_single_name[26] = {
	["index"] = 26,
	["value"] = "Eros"
}
alliance_name_single_name[27] = {
	["index"] = 27,
	["value"] = "Oceanus"
}
alliance_name_single_name[28] = {
	["index"] = 28,
	["value"] = "Crius"
}
alliance_name_single_name[29] = {
	["index"] = 29,
	["value"] = "Iapetus"
}
alliance_name_single_name[30] = {
	["index"] = 30,
	["value"] = "Thethys"
}
alliance_name_single_name[31] = {
	["index"] = 31,
	["value"] = "Odin"
}
alliance_name_single_name[32] = {
	["index"] = 32,
	["value"] = "Frigg"
}
alliance_name_single_name[33] = {
	["index"] = 33,
	["value"] = "Thor"
}
alliance_name_single_name[34] = {
	["index"] = 34,
	["value"] = "Sif"
}
alliance_name_single_name[35] = {
	["index"] = 35,
	["value"] = "Freyr"
}
alliance_name_single_name[36] = {
	["index"] = 36,
	["value"] = "Freyja"
}
alliance_name_single_name[37] = {
	["index"] = 37,
	["value"] = "Loki"
}
alliance_name_single_name[38] = {
	["index"] = 38,
	["value"] = "Tyr"
}
alliance_name_single_name[39] = {
	["index"] = 39,
	["value"] = "Baldur"
}
alliance_name_single_name[40] = {
	["index"] = 40,
	["value"] = "Hodr"
}
alliance_name_single_name[41] = {
	["index"] = 41,
	["value"] = "Forseti"
}
alliance_name_single_name[42] = {
	["index"] = 42,
	["value"] = "Bragi"
}
