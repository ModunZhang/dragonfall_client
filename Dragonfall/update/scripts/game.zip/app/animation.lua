local animation = {}
animation["Box_guang"] = {"animations/ui_animation_0.pvr.ccz"}
return animation