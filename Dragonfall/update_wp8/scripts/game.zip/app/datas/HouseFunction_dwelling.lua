local dwelling = GameDatas.HouseFunction.dwelling

dwelling[1] = {
	["level"] = 1,
	["citizen"] = 50,
	["production"] = 80,
	["power"] = 2
}
dwelling[2] = {
	["level"] = 2,
	["citizen"] = 80,
	["production"] = 130,
	["power"] = 4
}
dwelling[3] = {
	["level"] = 3,
	["citizen"] = 110,
	["production"] = 190,
	["power"] = 6
}
dwelling[4] = {
	["level"] = 4,
	["citizen"] = 160,
	["production"] = 260,
	["power"] = 8
}
dwelling[5] = {
	["level"] = 5,
	["citizen"] = 220,
	["production"] = 340,
	["power"] = 10
}
dwelling[6] = {
	["level"] = 6,
	["citizen"] = 290,
	["production"] = 430,
	["power"] = 20
}
dwelling[7] = {
	["level"] = 7,
	["citizen"] = 380,
	["production"] = 530,
	["power"] = 30
}
dwelling[8] = {
	["level"] = 8,
	["citizen"] = 470,
	["production"] = 640,
	["power"] = 80
}
dwelling[9] = {
	["level"] = 9,
	["citizen"] = 580,
	["production"] = 760,
	["power"] = 180
}
dwelling[10] = {
	["level"] = 10,
	["citizen"] = 700,
	["production"] = 890,
	["power"] = 280
}
dwelling[11] = {
	["level"] = 11,
	["citizen"] = 830,
	["production"] = 1030,
	["power"] = 390
}
dwelling[12] = {
	["level"] = 12,
	["citizen"] = 980,
	["production"] = 1180,
	["power"] = 490
}
dwelling[13] = {
	["level"] = 13,
	["citizen"] = 1130,
	["production"] = 1340,
	["power"] = 650
}
dwelling[14] = {
	["level"] = 14,
	["citizen"] = 1300,
	["production"] = 1510,
	["power"] = 1340
}
dwelling[15] = {
	["level"] = 15,
	["citizen"] = 1480,
	["production"] = 1690,
	["power"] = 2090
}
dwelling[16] = {
	["level"] = 16,
	["citizen"] = 1670,
	["production"] = 1880,
	["power"] = 2900
}
dwelling[17] = {
	["level"] = 17,
	["citizen"] = 1880,
	["production"] = 2080,
	["power"] = 4250
}
dwelling[18] = {
	["level"] = 18,
	["citizen"] = 2090,
	["production"] = 2290,
	["power"] = 5230
}
dwelling[19] = {
	["level"] = 19,
	["citizen"] = 2320,
	["production"] = 2510,
	["power"] = 6390
}
dwelling[20] = {
	["level"] = 20,
	["citizen"] = 2560,
	["production"] = 2740,
	["power"] = 7500
}
dwelling[21] = {
	["level"] = 21,
	["citizen"] = 2810,
	["production"] = 2980,
	["power"] = 10190
}
dwelling[22] = {
	["level"] = 22,
	["citizen"] = 3080,
	["production"] = 3230,
	["power"] = 11680
}
dwelling[23] = {
	["level"] = 23,
	["citizen"] = 3350,
	["production"] = 3490,
	["power"] = 13480
}
dwelling[24] = {
	["level"] = 24,
	["citizen"] = 3640,
	["production"] = 3760,
	["power"] = 15180
}
dwelling[25] = {
	["level"] = 25,
	["citizen"] = 3940,
	["production"] = 4040,
	["power"] = 20740
}
dwelling[26] = {
	["level"] = 26,
	["citizen"] = 4250,
	["production"] = 4330,
	["power"] = 23150
}
dwelling[27] = {
	["level"] = 27,
	["citizen"] = 4580,
	["production"] = 4630,
	["power"] = 26040
}
dwelling[28] = {
	["level"] = 28,
	["citizen"] = 4910,
	["production"] = 4940,
	["power"] = 28780
}
dwelling[29] = {
	["level"] = 29,
	["citizen"] = 5260,
	["production"] = 5260,
	["power"] = 40970
}
dwelling[30] = {
	["level"] = 30,
	["citizen"] = 5620,
	["production"] = 5590,
	["power"] = 47300
}
dwelling[31] = {
	["level"] = 31,
	["citizen"] = 5990,
	["production"] = 5940,
	["power"] = 54630
}
dwelling[32] = {
	["level"] = 32,
	["citizen"] = 6380,
	["production"] = 6310,
	["power"] = 61980
}
dwelling[33] = {
	["level"] = 33,
	["citizen"] = 6770,
	["production"] = 6700,
	["power"] = 84840
}
dwelling[34] = {
	["level"] = 34,
	["citizen"] = 7180,
	["production"] = 7110,
	["power"] = 95340
}
dwelling[35] = {
	["level"] = 35,
	["citizen"] = 7600,
	["production"] = 7540,
	["power"] = 107390
}
dwelling[36] = {
	["level"] = 36,
	["citizen"] = 8030,
	["production"] = 7990,
	["power"] = 119530
}
dwelling[37] = {
	["level"] = 37,
	["citizen"] = 8480,
	["production"] = 8460,
	["power"] = 160740
}
dwelling[38] = {
	["level"] = 38,
	["citizen"] = 8930,
	["production"] = 8950,
	["power"] = 177820
}
dwelling[39] = {
	["level"] = 39,
	["citizen"] = 9400,
	["production"] = 9460,
	["power"] = 197140
}
dwelling[40] = {
	["level"] = 40,
	["citizen"] = 10000,
	["production"] = 10000,
	["power"] = 216850
}
