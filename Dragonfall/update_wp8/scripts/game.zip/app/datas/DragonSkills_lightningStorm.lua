local lightningStorm = GameDatas.DragonSkills.lightningStorm

lightningStorm[1] = {
	["level"] = 1,
	["effect"] = 0.105000,
	["bloodCost"] = 280
}
lightningStorm[2] = {
	["level"] = 2,
	["effect"] = 0.120000,
	["bloodCost"] = 680
}
lightningStorm[3] = {
	["level"] = 3,
	["effect"] = 0.135000,
	["bloodCost"] = 1160
}
lightningStorm[4] = {
	["level"] = 4,
	["effect"] = 0.150000,
	["bloodCost"] = 1680
}
lightningStorm[5] = {
	["level"] = 5,
	["effect"] = 0.165000,
	["bloodCost"] = 2280
}
lightningStorm[6] = {
	["level"] = 6,
	["effect"] = 0.180000,
	["bloodCost"] = 5560
}
lightningStorm[7] = {
	["level"] = 7,
	["effect"] = 0.195000,
	["bloodCost"] = 8080
}
lightningStorm[8] = {
	["level"] = 8,
	["effect"] = 0.210000,
	["bloodCost"] = 10800
}
lightningStorm[9] = {
	["level"] = 9,
	["effect"] = 0.225000,
	["bloodCost"] = 13840
}
lightningStorm[10] = {
	["level"] = 10,
	["effect"] = 0.240000,
	["bloodCost"] = 17080
}
lightningStorm[11] = {
	["level"] = 11,
	["effect"] = 0.255000,
	["bloodCost"] = 44320
}
lightningStorm[12] = {
	["level"] = 12,
	["effect"] = 0.270000,
	["bloodCost"] = 65800
}
lightningStorm[13] = {
	["level"] = 13,
	["effect"] = 0.285000,
	["bloodCost"] = 91400
}
lightningStorm[14] = {
	["level"] = 14,
	["effect"] = 0.300000,
	["bloodCost"] = 121120
}
lightningStorm[15] = {
	["level"] = 15,
	["effect"] = 0.315000,
	["bloodCost"] = 154880
}
lightningStorm[16] = {
	["level"] = 16,
	["effect"] = 0.330000,
	["bloodCost"] = 294920
}
lightningStorm[17] = {
	["level"] = 17,
	["effect"] = 0.345000,
	["bloodCost"] = 401440
}
lightningStorm[18] = {
	["level"] = 18,
	["effect"] = 0.360000,
	["bloodCost"] = 524320
}
lightningStorm[19] = {
	["level"] = 19,
	["effect"] = 0.375000,
	["bloodCost"] = 663560
}
lightningStorm[20] = {
	["level"] = 20,
	["effect"] = 0.390000,
	["bloodCost"] = 819200
}
