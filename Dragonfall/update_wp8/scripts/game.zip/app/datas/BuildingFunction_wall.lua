local wall = GameDatas.BuildingFunction.wall

wall[1] = {
	["level"] = 1,
	["wallHp"] = 124,
	["wallRecovery"] = 31,
	["power"] = 30
}
wall[2] = {
	["level"] = 2,
	["wallHp"] = 229,
	["wallRecovery"] = 57,
	["power"] = 40
}
wall[3] = {
	["level"] = 3,
	["wallHp"] = 306,
	["wallRecovery"] = 77,
	["power"] = 50
}
wall[4] = {
	["level"] = 4,
	["wallHp"] = 367,
	["wallRecovery"] = 92,
	["power"] = 60
}
wall[5] = {
	["level"] = 5,
	["wallHp"] = 417,
	["wallRecovery"] = 104,
	["power"] = 70
}
wall[6] = {
	["level"] = 6,
	["wallHp"] = 457,
	["wallRecovery"] = 114,
	["power"] = 90
}
wall[7] = {
	["level"] = 7,
	["wallHp"] = 490,
	["wallRecovery"] = 123,
	["power"] = 130
}
wall[8] = {
	["level"] = 8,
	["wallHp"] = 519,
	["wallRecovery"] = 130,
	["power"] = 240
}
wall[9] = {
	["level"] = 9,
	["wallHp"] = 542,
	["wallRecovery"] = 136,
	["power"] = 520
}
wall[10] = {
	["level"] = 10,
	["wallHp"] = 562,
	["wallRecovery"] = 141,
	["power"] = 770
}
wall[11] = {
	["level"] = 11,
	["wallHp"] = 1054,
	["wallRecovery"] = 264,
	["power"] = 1070
}
wall[12] = {
	["level"] = 12,
	["wallHp"] = 1190,
	["wallRecovery"] = 298,
	["power"] = 1350
}
wall[13] = {
	["level"] = 13,
	["wallHp"] = 1310,
	["wallRecovery"] = 328,
	["power"] = 1780
}
wall[14] = {
	["level"] = 14,
	["wallHp"] = 1417,
	["wallRecovery"] = 354,
	["power"] = 3600
}
wall[15] = {
	["level"] = 15,
	["wallHp"] = 1512,
	["wallRecovery"] = 378,
	["power"] = 5620
}
wall[16] = {
	["level"] = 16,
	["wallHp"] = 1598,
	["wallRecovery"] = 399,
	["power"] = 7770
}
wall[17] = {
	["level"] = 17,
	["wallHp"] = 1675,
	["wallRecovery"] = 419,
	["power"] = 11360
}
wall[18] = {
	["level"] = 18,
	["wallHp"] = 1745,
	["wallRecovery"] = 436,
	["power"] = 13980
}
wall[19] = {
	["level"] = 19,
	["wallHp"] = 1809,
	["wallRecovery"] = 452,
	["power"] = 17080
}
wall[20] = {
	["level"] = 20,
	["wallHp"] = 1867,
	["wallRecovery"] = 467,
	["power"] = 20030
}
wall[21] = {
	["level"] = 21,
	["wallHp"] = 3846,
	["wallRecovery"] = 961,
	["power"] = 27210
}
wall[22] = {
	["level"] = 22,
	["wallHp"] = 4500,
	["wallRecovery"] = 1125,
	["power"] = 31190
}
wall[23] = {
	["level"] = 23,
	["wallHp"] = 5157,
	["wallRecovery"] = 1289,
	["power"] = 36000
}
wall[24] = {
	["level"] = 24,
	["wallHp"] = 5813,
	["wallRecovery"] = 1453,
	["power"] = 40510
}
wall[25] = {
	["level"] = 25,
	["wallHp"] = 6465,
	["wallRecovery"] = 1616,
	["power"] = 55330
}
wall[26] = {
	["level"] = 26,
	["wallHp"] = 7111,
	["wallRecovery"] = 1778,
	["power"] = 61770
}
wall[27] = {
	["level"] = 27,
	["wallHp"] = 7749,
	["wallRecovery"] = 1937,
	["power"] = 69490
}
wall[28] = {
	["level"] = 28,
	["wallHp"] = 8377,
	["wallRecovery"] = 2094,
	["power"] = 76790
}
wall[29] = {
	["level"] = 29,
	["wallHp"] = 8994,
	["wallRecovery"] = 2249,
	["power"] = 109290
}
wall[30] = {
	["level"] = 30,
	["wallHp"] = 9600,
	["wallRecovery"] = 2400,
	["power"] = 126160
}
wall[31] = {
	["level"] = 31,
	["wallHp"] = 15077,
	["wallRecovery"] = 3769,
	["power"] = 145710
}
wall[32] = {
	["level"] = 32,
	["wallHp"] = 16980,
	["wallRecovery"] = 4245,
	["power"] = 165320
}
wall[33] = {
	["level"] = 33,
	["wallHp"] = 18899,
	["wallRecovery"] = 4725,
	["power"] = 226290
}
wall[34] = {
	["level"] = 34,
	["wallHp"] = 20826,
	["wallRecovery"] = 5207,
	["power"] = 254270
}
wall[35] = {
	["level"] = 35,
	["wallHp"] = 22756,
	["wallRecovery"] = 5689,
	["power"] = 286410
}
wall[36] = {
	["level"] = 36,
	["wallHp"] = 24681,
	["wallRecovery"] = 6170,
	["power"] = 318780
}
wall[37] = {
	["level"] = 37,
	["wallHp"] = 26597,
	["wallRecovery"] = 6649,
	["power"] = 428690
}
wall[38] = {
	["level"] = 38,
	["wallHp"] = 28500,
	["wallRecovery"] = 7125,
	["power"] = 474230
}
wall[39] = {
	["level"] = 39,
	["wallHp"] = 30387,
	["wallRecovery"] = 7597,
	["power"] = 525750
}
wall[40] = {
	["level"] = 40,
	["wallHp"] = 32256,
	["wallRecovery"] = 8064,
	["power"] = 578300
}
