local noManMap_3 = GameDatas.NoManMap.noManMap_3

noManMap_3[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 1
}
noManMap_3[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 1
}
noManMap_3[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 1
}
noManMap_3[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 1
}
noManMap_3[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 1
}
noManMap_3[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 1
}
noManMap_3[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 2
}
noManMap_3[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 2
}
noManMap_3[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 2
}
noManMap_3[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 2
}
noManMap_3[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 2
}
noManMap_3[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_9",
	["x"] = 15,
	["y"] = 2
}
noManMap_3[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 3
}
noManMap_3[13] = {
	["index"] = 13,
	["name"] = "decorate_mountain_2",
	["x"] = 4,
	["y"] = 3
}
noManMap_3[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 3
}
noManMap_3[15] = {
	["index"] = 15,
	["name"] = "decorate_lake_1",
	["x"] = 13,
	["y"] = 3
}
noManMap_3[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 3
}
noManMap_3[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 3
}
noManMap_3[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_9",
	["x"] = 2,
	["y"] = 4
}
noManMap_3[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 4
}
noManMap_3[20] = {
	["index"] = 20,
	["name"] = "decorate_lake_2",
	["x"] = 7,
	["y"] = 4
}
noManMap_3[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 4
}
noManMap_3[22] = {
	["index"] = 22,
	["name"] = "decorate_mountain_2",
	["x"] = 18,
	["y"] = 4
}
noManMap_3[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 5
}
noManMap_3[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 5
}
noManMap_3[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 5
}
noManMap_3[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 5
}
noManMap_3[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 5
}
noManMap_3[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_6",
	["x"] = 13,
	["y"] = 5
}
noManMap_3[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 5
}
noManMap_3[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 5
}
noManMap_3[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 6
}
noManMap_3[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 6
}
noManMap_3[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_5",
	["x"] = 9,
	["y"] = 6
}
noManMap_3[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 6
}
noManMap_3[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 6
}
noManMap_3[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 6
}
noManMap_3[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 6
}
noManMap_3[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 6
}
noManMap_3[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 6
}
noManMap_3[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 6
}
noManMap_3[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 7
}
noManMap_3[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_7",
	["x"] = 5,
	["y"] = 7
}
noManMap_3[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 7
}
noManMap_3[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 7
}
noManMap_3[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 7
}
noManMap_3[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 7
}
noManMap_3[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 7
}
noManMap_3[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_6",
	["x"] = 18,
	["y"] = 7
}
noManMap_3[49] = {
	["index"] = 49,
	["name"] = "decorate_mountain_2",
	["x"] = 3,
	["y"] = 8
}
noManMap_3[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 8
}
noManMap_3[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 8
}
noManMap_3[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 8
}
noManMap_3[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 8
}
noManMap_3[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 8
}
noManMap_3[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 8
}
noManMap_3[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 9
}
noManMap_3[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 9
}
noManMap_3[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 9
}
noManMap_3[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 9
}
noManMap_3[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 9
}
noManMap_3[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 9
}
noManMap_3[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 10
}
noManMap_3[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 10
}
noManMap_3[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 10
}
noManMap_3[65] = {
	["index"] = 65,
	["name"] = "decorate_mountain_1",
	["x"] = 14,
	["y"] = 10
}
noManMap_3[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 10
}
noManMap_3[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_8",
	["x"] = 17,
	["y"] = 10
}
noManMap_3[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 10
}
noManMap_3[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_6",
	["x"] = 2,
	["y"] = 11
}
noManMap_3[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 11
}
noManMap_3[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 11
}
noManMap_3[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 11
}
noManMap_3[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 11
}
noManMap_3[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 11
}
noManMap_3[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 11
}
noManMap_3[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 11
}
noManMap_3[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 12
}
noManMap_3[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 12
}
noManMap_3[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 12
}
noManMap_3[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 12
}
noManMap_3[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 12
}
noManMap_3[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 12
}
noManMap_3[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 12
}
noManMap_3[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 12
}
noManMap_3[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 13
}
noManMap_3[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 13
}
noManMap_3[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 13
}
noManMap_3[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_8",
	["x"] = 9,
	["y"] = 13
}
noManMap_3[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 13
}
noManMap_3[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 13
}
noManMap_3[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 13
}
noManMap_3[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 14
}
noManMap_3[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_6",
	["x"] = 7,
	["y"] = 14
}
noManMap_3[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 14
}
noManMap_3[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 14
}
noManMap_3[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 14
}
noManMap_3[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_4",
	["x"] = 16,
	["y"] = 14
}
noManMap_3[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 14
}
noManMap_3[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_9",
	["x"] = 1,
	["y"] = 15
}
noManMap_3[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 15
}
noManMap_3[101] = {
	["index"] = 101,
	["name"] = "decorate_lake_1",
	["x"] = 5,
	["y"] = 15
}
noManMap_3[102] = {
	["index"] = 102,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 15
}
noManMap_3[103] = {
	["index"] = 103,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 15
}
noManMap_3[104] = {
	["index"] = 104,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 15
}
noManMap_3[105] = {
	["index"] = 105,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 15
}
noManMap_3[106] = {
	["index"] = 106,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 15
}
noManMap_3[107] = {
	["index"] = 107,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 16
}
noManMap_3[108] = {
	["index"] = 108,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 16
}
noManMap_3[109] = {
	["index"] = 109,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 16
}
noManMap_3[110] = {
	["index"] = 110,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 16
}
noManMap_3[111] = {
	["index"] = 111,
	["name"] = "decorate_lake_2",
	["x"] = 14,
	["y"] = 16
}
noManMap_3[112] = {
	["index"] = 112,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 16
}
noManMap_3[113] = {
	["index"] = 113,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 16
}
noManMap_3[114] = {
	["index"] = 114,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 16
}
noManMap_3[115] = {
	["index"] = 115,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 17
}
noManMap_3[116] = {
	["index"] = 116,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 17
}
noManMap_3[117] = {
	["index"] = 117,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 17
}
noManMap_3[118] = {
	["index"] = 118,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 17
}
noManMap_3[119] = {
	["index"] = 119,
	["name"] = "decorate_tree_4",
	["x"] = 17,
	["y"] = 17
}
noManMap_3[120] = {
	["index"] = 120,
	["name"] = "decorate_tree_8",
	["x"] = 19,
	["y"] = 17
}
noManMap_3[121] = {
	["index"] = 121,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 18
}
noManMap_3[122] = {
	["index"] = 122,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 18
}
noManMap_3[123] = {
	["index"] = 123,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 18
}
noManMap_3[124] = {
	["index"] = 124,
	["name"] = "decorate_mountain_2",
	["x"] = 9,
	["y"] = 18
}
noManMap_3[125] = {
	["index"] = 125,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 18
}
noManMap_3[126] = {
	["index"] = 126,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 18
}
noManMap_3[127] = {
	["index"] = 127,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 18
}
noManMap_3[128] = {
	["index"] = 128,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 18
}
noManMap_3[129] = {
	["index"] = 129,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 18
}
noManMap_3[130] = {
	["index"] = 130,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 19
}
noManMap_3[131] = {
	["index"] = 131,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 19
}
noManMap_3[132] = {
	["index"] = 132,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 19
}
noManMap_3[133] = {
	["index"] = 133,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 19
}
noManMap_3[134] = {
	["index"] = 134,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 19
}
noManMap_3[135] = {
	["index"] = 135,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 19
}
noManMap_3[136] = {
	["index"] = 136,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 19
}
noManMap_3[137] = {
	["index"] = 137,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 19
}
