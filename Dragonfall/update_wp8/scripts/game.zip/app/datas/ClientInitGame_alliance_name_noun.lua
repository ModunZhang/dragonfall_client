local alliance_name_noun = GameDatas.ClientInitGame.alliance_name_noun

alliance_name_noun[1] = {
	["index"] = 1,
	["value"] = "Kingdom"
}
alliance_name_noun[2] = {
	["index"] = 2,
	["value"] = "Nation"
}
alliance_name_noun[3] = {
	["index"] = 3,
	["value"] = "Territory"
}
alliance_name_noun[4] = {
	["index"] = 4,
	["value"] = "Chaos"
}
alliance_name_noun[5] = {
	["index"] = 5,
	["value"] = "Empire"
}
alliance_name_noun[6] = {
	["index"] = 6,
	["value"] = "Legend"
}
alliance_name_noun[7] = {
	["index"] = 7,
	["value"] = "History"
}
alliance_name_noun[8] = {
	["index"] = 8,
	["value"] = "Area"
}
alliance_name_noun[9] = {
	["index"] = 9,
	["value"] = "Region"
}
alliance_name_noun[10] = {
	["index"] = 10,
	["value"] = "Sword"
}
alliance_name_noun[11] = {
	["index"] = 11,
	["value"] = "Warriors"
}
alliance_name_noun[12] = {
	["index"] = 12,
	["value"] = "Sons"
}
alliance_name_noun[13] = {
	["index"] = 13,
	["value"] = "Alliance"
}
alliance_name_noun[14] = {
	["index"] = 14,
	["value"] = "Annal"
}
alliance_name_noun[15] = {
	["index"] = 15,
	["value"] = "Guild"
}
alliance_name_noun[16] = {
	["index"] = 16,
	["value"] = "World"
}
alliance_name_noun[17] = {
	["index"] = 17,
	["value"] = "Rise"
}
