local material = GameDatas.GemsPayment.material

material[1] = {
	["index"] = 1,
	["blueprints"] = 50,
	["tools"] = 50,
	["tiles"] = 50,
	["pulley"] = 50,
	["trainingFigure"] = 50,
	["bowTarget"] = 50,
	["saddle"] = 50,
	["ironPart"] = 50
}
