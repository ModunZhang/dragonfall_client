local terrainStyle = GameDatas.AllianceMap.terrainStyle

terrainStyle["grassLand_1"] = {
	["style"] = "grassLand_1",
	["index"] = 1
}
terrainStyle["grassLand_2"] = {
	["style"] = "grassLand_2",
	["index"] = 2
}
terrainStyle["grassLand_3"] = {
	["style"] = "grassLand_3",
	["index"] = 3
}
terrainStyle["grassLand_4"] = {
	["style"] = "grassLand_4",
	["index"] = 4
}
terrainStyle["grassLand_5"] = {
	["style"] = "grassLand_5",
	["index"] = 5
}
terrainStyle["grassLand_6"] = {
	["style"] = "grassLand_6",
	["index"] = 6
}
terrainStyle["desert_1"] = {
	["style"] = "desert_1",
	["index"] = 7
}
terrainStyle["desert_2"] = {
	["style"] = "desert_2",
	["index"] = 8
}
terrainStyle["desert_3"] = {
	["style"] = "desert_3",
	["index"] = 9
}
terrainStyle["desert_4"] = {
	["style"] = "desert_4",
	["index"] = 10
}
terrainStyle["desert_5"] = {
	["style"] = "desert_5",
	["index"] = 11
}
terrainStyle["desert_6"] = {
	["style"] = "desert_6",
	["index"] = 12
}
terrainStyle["iceField_1"] = {
	["style"] = "iceField_1",
	["index"] = 13
}
terrainStyle["iceField_2"] = {
	["style"] = "iceField_2",
	["index"] = 14
}
terrainStyle["iceField_3"] = {
	["style"] = "iceField_3",
	["index"] = 15
}
terrainStyle["iceField_4"] = {
	["style"] = "iceField_4",
	["index"] = 16
}
terrainStyle["iceField_5"] = {
	["style"] = "iceField_5",
	["index"] = 17
}
terrainStyle["iceField_6"] = {
	["style"] = "iceField_6",
	["index"] = 18
}
