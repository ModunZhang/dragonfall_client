local dragonBlood = GameDatas.DragonSkills.dragonBlood

dragonBlood[1] = {
	["level"] = 1,
	["effect"] = 0.020000,
	["bloodCost"] = 60
}
dragonBlood[2] = {
	["level"] = 2,
	["effect"] = 0.040000,
	["bloodCost"] = 140
}
dragonBlood[3] = {
	["level"] = 3,
	["effect"] = 0.060000,
	["bloodCost"] = 240
}
dragonBlood[4] = {
	["level"] = 4,
	["effect"] = 0.080000,
	["bloodCost"] = 340
}
dragonBlood[5] = {
	["level"] = 5,
	["effect"] = 0.100000,
	["bloodCost"] = 460
}
dragonBlood[6] = {
	["level"] = 6,
	["effect"] = 0.120000,
	["bloodCost"] = 1120
}
dragonBlood[7] = {
	["level"] = 7,
	["effect"] = 0.140000,
	["bloodCost"] = 1620
}
dragonBlood[8] = {
	["level"] = 8,
	["effect"] = 0.160000,
	["bloodCost"] = 2160
}
dragonBlood[9] = {
	["level"] = 9,
	["effect"] = 0.180000,
	["bloodCost"] = 2780
}
dragonBlood[10] = {
	["level"] = 10,
	["effect"] = 0.200000,
	["bloodCost"] = 3420
}
dragonBlood[11] = {
	["level"] = 11,
	["effect"] = 0.220000,
	["bloodCost"] = 8860
}
dragonBlood[12] = {
	["level"] = 12,
	["effect"] = 0.240000,
	["bloodCost"] = 13160
}
dragonBlood[13] = {
	["level"] = 13,
	["effect"] = 0.260000,
	["bloodCost"] = 18280
}
dragonBlood[14] = {
	["level"] = 14,
	["effect"] = 0.280000,
	["bloodCost"] = 24220
}
dragonBlood[15] = {
	["level"] = 15,
	["effect"] = 0.300000,
	["bloodCost"] = 30980
}
dragonBlood[16] = {
	["level"] = 16,
	["effect"] = 0.320000,
	["bloodCost"] = 59000
}
dragonBlood[17] = {
	["level"] = 17,
	["effect"] = 0.340000,
	["bloodCost"] = 80300
}
dragonBlood[18] = {
	["level"] = 18,
	["effect"] = 0.360000,
	["bloodCost"] = 104860
}
dragonBlood[19] = {
	["level"] = 19,
	["effect"] = 0.380000,
	["bloodCost"] = 132720
}
dragonBlood[20] = {
	["level"] = 20,
	["effect"] = 0.400000,
	["bloodCost"] = 163840
}
