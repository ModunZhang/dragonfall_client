local stringInit = GameDatas.PlayerInitData.stringInit

stringInit["firstIAPRewards"] = {
	["type"] = "firstIAPRewards",
	["value"] = "items:casinoTokenClass_2:1,items:vipActive_3:1,items:stamina_2:1,items:moveTheCity:1,items:dragonExp_1:1,items:heroBlood_1:1"
}
stringInit["firstJoinAllianceRewards"] = {
	["type"] = "firstJoinAllianceRewards",
	["value"] = "resources:gem:200"
}
