local alliance_name_adj = GameDatas.ClientInitGame.alliance_name_adj

alliance_name_adj[1] = {
	["index"] = 1,
	["value"] = "Furious"
}
alliance_name_adj[2] = {
	["index"] = 2,
	["value"] = "Wrathful"
}
alliance_name_adj[3] = {
	["index"] = 3,
	["value"] = "Bright"
}
alliance_name_adj[4] = {
	["index"] = 4,
	["value"] = "Valiant"
}
alliance_name_adj[5] = {
	["index"] = 5,
	["value"] = "Naïve"
}
alliance_name_adj[6] = {
	["index"] = 6,
	["value"] = "Noble"
}
alliance_name_adj[7] = {
	["index"] = 7,
	["value"] = "Mighty"
}
alliance_name_adj[8] = {
	["index"] = 8,
	["value"] = "Skillful"
}
alliance_name_adj[9] = {
	["index"] = 9,
	["value"] = "Devoted"
}
alliance_name_adj[10] = {
	["index"] = 10,
	["value"] = "Brave"
}
alliance_name_adj[11] = {
	["index"] = 11,
	["value"] = "Powerful"
}
alliance_name_adj[12] = {
	["index"] = 12,
	["value"] = "Divine"
}
alliance_name_adj[13] = {
	["index"] = 13,
	["value"] = "Immortal"
}
