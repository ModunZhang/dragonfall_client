local surge = GameDatas.DragonSkills.surge

surge[1] = {
	["level"] = 1,
	["effect"] = 0.010000,
	["bloodCost"] = 140
}
surge[2] = {
	["level"] = 2,
	["effect"] = 0.020000,
	["bloodCost"] = 340
}
surge[3] = {
	["level"] = 3,
	["effect"] = 0.030000,
	["bloodCost"] = 580
}
surge[4] = {
	["level"] = 4,
	["effect"] = 0.040000,
	["bloodCost"] = 840
}
surge[5] = {
	["level"] = 5,
	["effect"] = 0.050000,
	["bloodCost"] = 1140
}
surge[6] = {
	["level"] = 6,
	["effect"] = 0.060000,
	["bloodCost"] = 2780
}
surge[7] = {
	["level"] = 7,
	["effect"] = 0.070000,
	["bloodCost"] = 4040
}
surge[8] = {
	["level"] = 8,
	["effect"] = 0.080000,
	["bloodCost"] = 5400
}
surge[9] = {
	["level"] = 9,
	["effect"] = 0.090000,
	["bloodCost"] = 6920
}
surge[10] = {
	["level"] = 10,
	["effect"] = 0.100000,
	["bloodCost"] = 8540
}
surge[11] = {
	["level"] = 11,
	["effect"] = 0.110000,
	["bloodCost"] = 22160
}
surge[12] = {
	["level"] = 12,
	["effect"] = 0.120000,
	["bloodCost"] = 32900
}
surge[13] = {
	["level"] = 13,
	["effect"] = 0.130000,
	["bloodCost"] = 45700
}
surge[14] = {
	["level"] = 14,
	["effect"] = 0.140000,
	["bloodCost"] = 60560
}
surge[15] = {
	["level"] = 15,
	["effect"] = 0.150000,
	["bloodCost"] = 77440
}
surge[16] = {
	["level"] = 16,
	["effect"] = 0.160000,
	["bloodCost"] = 147460
}
surge[17] = {
	["level"] = 17,
	["effect"] = 0.170000,
	["bloodCost"] = 200720
}
surge[18] = {
	["level"] = 18,
	["effect"] = 0.180000,
	["bloodCost"] = 262160
}
surge[19] = {
	["level"] = 19,
	["effect"] = 0.190000,
	["bloodCost"] = 331780
}
surge[20] = {
	["level"] = 20,
	["effect"] = 0.200000,
	["bloodCost"] = 409600
}
