local watchTower = GameDatas.AllianceBuilding.watchTower

watchTower[1] = {
	["level"] = 1,
	["needHonour"] = 2380,
	["power"] = 79
}
watchTower[2] = {
	["level"] = 2,
	["needHonour"] = 6426,
	["power"] = 214
}
watchTower[3] = {
	["level"] = 3,
	["needHonour"] = 14280,
	["power"] = 476
}
watchTower[4] = {
	["level"] = 4,
	["needHonour"] = 21420,
	["power"] = 714
}
watchTower[5] = {
	["level"] = 5,
	["needHonour"] = 31416,
	["power"] = 1047
}
watchTower[6] = {
	["level"] = 6,
	["needHonour"] = 53312,
	["power"] = 1777
}
watchTower[7] = {
	["level"] = 7,
	["needHonour"] = 88060,
	["power"] = 2935
}
watchTower[8] = {
	["level"] = 8,
	["needHonour"] = 145656,
	["power"] = 4855
}
watchTower[9] = {
	["level"] = 9,
	["needHonour"] = 224910,
	["power"] = 7497
}
watchTower[10] = {
	["level"] = 10,
	["needHonour"] = 342720,
	["power"] = 11424
}
watchTower[11] = {
	["level"] = 11,
	["needHonour"] = 499086,
	["power"] = 16636
}
watchTower[12] = {
	["level"] = 12,
	["needHonour"] = 749700,
	["power"] = 24990
}
watchTower[13] = {
	["level"] = 13,
	["needHonour"] = 1078616,
	["power"] = 35953
}
watchTower[14] = {
	["level"] = 14,
	["needHonour"] = 1576512,
	["power"] = 52550
}
watchTower[15] = {
	["level"] = 15,
	["needHonour"] = 2227680,
	["power"] = 74256
}
watchTower[16] = {
	["level"] = 16,
	["needHonour"] = 3198720,
	["power"] = 106624
}
watchTower[17] = {
	["level"] = 17,
	["needHonour"] = 4451790,
	["power"] = 148393
}
watchTower[18] = {
	["level"] = 18,
	["needHonour"] = 5635840,
	["power"] = 187861
}
watchTower[19] = {
	["level"] = 19,
	["needHonour"] = 6473600,
	["power"] = 215786
}
watchTower[20] = {
	["level"] = 20,
	["needHonour"] = 8568000,
	["power"] = 285600
}
