local hellFire = GameDatas.DragonSkills.hellFire

hellFire[1] = {
	["level"] = 1,
	["effect"] = 0.240000,
	["bloodCost"] = 280
}
hellFire[2] = {
	["level"] = 2,
	["effect"] = 0.270000,
	["bloodCost"] = 680
}
hellFire[3] = {
	["level"] = 3,
	["effect"] = 0.300000,
	["bloodCost"] = 1160
}
hellFire[4] = {
	["level"] = 4,
	["effect"] = 0.330000,
	["bloodCost"] = 1680
}
hellFire[5] = {
	["level"] = 5,
	["effect"] = 0.360000,
	["bloodCost"] = 2280
}
hellFire[6] = {
	["level"] = 6,
	["effect"] = 0.390000,
	["bloodCost"] = 5560
}
hellFire[7] = {
	["level"] = 7,
	["effect"] = 0.420000,
	["bloodCost"] = 8080
}
hellFire[8] = {
	["level"] = 8,
	["effect"] = 0.450000,
	["bloodCost"] = 10800
}
hellFire[9] = {
	["level"] = 9,
	["effect"] = 0.480000,
	["bloodCost"] = 13840
}
hellFire[10] = {
	["level"] = 10,
	["effect"] = 0.510000,
	["bloodCost"] = 17080
}
hellFire[11] = {
	["level"] = 11,
	["effect"] = 0.540000,
	["bloodCost"] = 44320
}
hellFire[12] = {
	["level"] = 12,
	["effect"] = 0.570000,
	["bloodCost"] = 65800
}
hellFire[13] = {
	["level"] = 13,
	["effect"] = 0.600000,
	["bloodCost"] = 91400
}
hellFire[14] = {
	["level"] = 14,
	["effect"] = 0.630000,
	["bloodCost"] = 121120
}
hellFire[15] = {
	["level"] = 15,
	["effect"] = 0.660000,
	["bloodCost"] = 154880
}
hellFire[16] = {
	["level"] = 16,
	["effect"] = 0.690000,
	["bloodCost"] = 294920
}
hellFire[17] = {
	["level"] = 17,
	["effect"] = 0.720000,
	["bloodCost"] = 401440
}
hellFire[18] = {
	["level"] = 18,
	["effect"] = 0.750000,
	["bloodCost"] = 524320
}
hellFire[19] = {
	["level"] = 19,
	["effect"] = 0.780000,
	["bloodCost"] = 663560
}
hellFire[20] = {
	["level"] = 20,
	["effect"] = 0.810000,
	["bloodCost"] = 819200
}
