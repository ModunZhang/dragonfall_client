local pve_level = GameDatas.ClientInitGame.pve_level

pve_level[1] = {
	["floor"] = 1,
	["itemName"] = "resource:gemClass_2",
	["count"] = 1
}
pve_level[2] = {
	["floor"] = 2,
	["itemName"] = "resource:gemClass_2",
	["count"] = 2
}
pve_level[3] = {
	["floor"] = 3,
	["itemName"] = "resource:gemClass_2",
	["count"] = 3
}
pve_level[4] = {
	["floor"] = 4,
	["itemName"] = "resource:gemClass_2",
	["count"] = 4
}
pve_level[5] = {
	["floor"] = 5,
	["itemName"] = "resource:gemClass_2",
	["count"] = 5
}
pve_level[6] = {
	["floor"] = 6,
	["itemName"] = "resource:gemClass_2",
	["count"] = 6
}
pve_level[7] = {
	["floor"] = 7,
	["itemName"] = "resource:gemClass_2",
	["count"] = 7
}
pve_level[8] = {
	["floor"] = 8,
	["itemName"] = "resource:gemClass_2",
	["count"] = 8
}
pve_level[9] = {
	["floor"] = 9,
	["itemName"] = "resource:gemClass_2",
	["count"] = 9
}
pve_level[10] = {
	["floor"] = 10,
	["itemName"] = "resource:gemClass_3",
	["count"] = 1
}
pve_level[11] = {
	["floor"] = 11,
	["itemName"] = "resource:gemClass_2",
	["count"] = 11
}
pve_level[12] = {
	["floor"] = 12,
	["itemName"] = "resource:gemClass_2",
	["count"] = 12
}
pve_level[13] = {
	["floor"] = 13,
	["itemName"] = "resource:gemClass_2",
	["count"] = 13
}
pve_level[14] = {
	["floor"] = 14,
	["itemName"] = "resource:gemClass_2",
	["count"] = 14
}
pve_level[15] = {
	["floor"] = 15,
	["itemName"] = "resource:gemClass_2",
	["count"] = 15
}
pve_level[16] = {
	["floor"] = 16,
	["itemName"] = "resource:gemClass_2",
	["count"] = 16
}
pve_level[17] = {
	["floor"] = 17,
	["itemName"] = "resource:gemClass_2",
	["count"] = 17
}
pve_level[18] = {
	["floor"] = 18,
	["itemName"] = "resource:gemClass_2",
	["count"] = 18
}
pve_level[19] = {
	["floor"] = 19,
	["itemName"] = "resource:gemClass_2",
	["count"] = 19
}
pve_level[20] = {
	["floor"] = 20,
	["itemName"] = "resource:gemClass_3",
	["count"] = 2
}
pve_level[21] = {
	["floor"] = 21,
	["itemName"] = "resource:gemClass_2",
	["count"] = 21
}
pve_level[22] = {
	["floor"] = 22,
	["itemName"] = "resource:gemClass_2",
	["count"] = 22
}
pve_level[23] = {
	["floor"] = 23,
	["itemName"] = "resource:gemClass_2",
	["count"] = 23
}
pve_level[24] = {
	["floor"] = 24,
	["itemName"] = "resource:gemClass_2",
	["count"] = 24
}
