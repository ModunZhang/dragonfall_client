local palace = GameDatas.AllianceBuilding.palace

palace[1] = {
	["level"] = 1,
	["needHonour"] = 2040,
	["memberCount"] = 11,
	["power"] = 68
}
palace[2] = {
	["level"] = 2,
	["needHonour"] = 5508,
	["memberCount"] = 12,
	["power"] = 183
}
palace[3] = {
	["level"] = 3,
	["needHonour"] = 12240,
	["memberCount"] = 13,
	["power"] = 408
}
palace[4] = {
	["level"] = 4,
	["needHonour"] = 18360,
	["memberCount"] = 14,
	["power"] = 612
}
palace[5] = {
	["level"] = 5,
	["needHonour"] = 26928,
	["memberCount"] = 15,
	["power"] = 897
}
palace[6] = {
	["level"] = 6,
	["needHonour"] = 45696,
	["memberCount"] = 16,
	["power"] = 1523
}
palace[7] = {
	["level"] = 7,
	["needHonour"] = 75480,
	["memberCount"] = 17,
	["power"] = 2516
}
palace[8] = {
	["level"] = 8,
	["needHonour"] = 124848,
	["memberCount"] = 18,
	["power"] = 4161
}
palace[9] = {
	["level"] = 9,
	["needHonour"] = 192780,
	["memberCount"] = 19,
	["power"] = 6426
}
palace[10] = {
	["level"] = 10,
	["needHonour"] = 293760,
	["memberCount"] = 20,
	["power"] = 9792
}
palace[11] = {
	["level"] = 11,
	["needHonour"] = 427788,
	["memberCount"] = 22,
	["power"] = 14259
}
palace[12] = {
	["level"] = 12,
	["needHonour"] = 642600,
	["memberCount"] = 24,
	["power"] = 21420
}
palace[13] = {
	["level"] = 13,
	["needHonour"] = 924528,
	["memberCount"] = 26,
	["power"] = 30817
}
palace[14] = {
	["level"] = 14,
	["needHonour"] = 1351296,
	["memberCount"] = 28,
	["power"] = 45043
}
palace[15] = {
	["level"] = 15,
	["needHonour"] = 1909440,
	["memberCount"] = 30,
	["power"] = 63648
}
palace[16] = {
	["level"] = 16,
	["needHonour"] = 2741760,
	["memberCount"] = 32,
	["power"] = 91392
}
palace[17] = {
	["level"] = 17,
	["needHonour"] = 3815820,
	["memberCount"] = 34,
	["power"] = 127194
}
palace[18] = {
	["level"] = 18,
	["needHonour"] = 4830720,
	["memberCount"] = 36,
	["power"] = 161024
}
palace[19] = {
	["level"] = 19,
	["needHonour"] = 5548800,
	["memberCount"] = 38,
	["power"] = 184960
}
palace[20] = {
	["level"] = 20,
	["needHonour"] = 7344000,
	["memberCount"] = 40,
	["power"] = 244800
}
