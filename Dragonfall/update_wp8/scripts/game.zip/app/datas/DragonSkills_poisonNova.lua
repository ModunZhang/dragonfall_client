local poisonNova = GameDatas.DragonSkills.poisonNova

poisonNova[1] = {
	["level"] = 1,
	["effect"] = 0.080000,
	["bloodCost"] = 280
}
poisonNova[2] = {
	["level"] = 2,
	["effect"] = 0.090000,
	["bloodCost"] = 680
}
poisonNova[3] = {
	["level"] = 3,
	["effect"] = 0.100000,
	["bloodCost"] = 1160
}
poisonNova[4] = {
	["level"] = 4,
	["effect"] = 0.110000,
	["bloodCost"] = 1680
}
poisonNova[5] = {
	["level"] = 5,
	["effect"] = 0.120000,
	["bloodCost"] = 2280
}
poisonNova[6] = {
	["level"] = 6,
	["effect"] = 0.130000,
	["bloodCost"] = 5560
}
poisonNova[7] = {
	["level"] = 7,
	["effect"] = 0.140000,
	["bloodCost"] = 8080
}
poisonNova[8] = {
	["level"] = 8,
	["effect"] = 0.150000,
	["bloodCost"] = 10800
}
poisonNova[9] = {
	["level"] = 9,
	["effect"] = 0.160000,
	["bloodCost"] = 13840
}
poisonNova[10] = {
	["level"] = 10,
	["effect"] = 0.170000,
	["bloodCost"] = 17080
}
poisonNova[11] = {
	["level"] = 11,
	["effect"] = 0.180000,
	["bloodCost"] = 44320
}
poisonNova[12] = {
	["level"] = 12,
	["effect"] = 0.190000,
	["bloodCost"] = 65800
}
poisonNova[13] = {
	["level"] = 13,
	["effect"] = 0.200000,
	["bloodCost"] = 91400
}
poisonNova[14] = {
	["level"] = 14,
	["effect"] = 0.210000,
	["bloodCost"] = 121120
}
poisonNova[15] = {
	["level"] = 15,
	["effect"] = 0.220000,
	["bloodCost"] = 154880
}
poisonNova[16] = {
	["level"] = 16,
	["effect"] = 0.230000,
	["bloodCost"] = 294920
}
poisonNova[17] = {
	["level"] = 17,
	["effect"] = 0.240000,
	["bloodCost"] = 401440
}
poisonNova[18] = {
	["level"] = 18,
	["effect"] = 0.250000,
	["bloodCost"] = 524320
}
poisonNova[19] = {
	["level"] = 19,
	["effect"] = 0.260000,
	["bloodCost"] = 663560
}
poisonNova[20] = {
	["level"] = 20,
	["effect"] = 0.270000,
	["bloodCost"] = 819200
}
