local fightFix = GameDatas.Soldiers.fightFix

fightFix[0] = {
	["index"] = 0,
	["multipleMin"] = 0.000000,
	["multipleMax"] = 0.100000,
	["effect"] = 0.700000
}
fightFix[1] = {
	["index"] = 1,
	["multipleMin"] = 0.100000,
	["multipleMax"] = 0.250000,
	["effect"] = 0.550000
}
fightFix[2] = {
	["index"] = 2,
	["multipleMin"] = 0.250000,
	["multipleMax"] = 0.400000,
	["effect"] = 0.400000
}
fightFix[3] = {
	["index"] = 3,
	["multipleMin"] = 0.400000,
	["multipleMax"] = 0.550000,
	["effect"] = 0.300000
}
fightFix[4] = {
	["index"] = 4,
	["multipleMin"] = 0.550000,
	["multipleMax"] = 0.700000,
	["effect"] = 0.200000
}
fightFix[5] = {
	["index"] = 5,
	["multipleMin"] = 0.700000,
	["multipleMax"] = 0.850000,
	["effect"] = 0.100000
}
fightFix[6] = {
	["index"] = 6,
	["multipleMin"] = 0.850000,
	["multipleMax"] = 0.000000,
	["effect"] = 0.000000
}
