local stoneVillage = GameDatas.AllianceVillage.stoneVillage

stoneVillage[1] = {
	["level"] = 1,
	["needHonour"] = 1190,
	["production"] = 84000
}
stoneVillage[2] = {
	["level"] = 2,
	["needHonour"] = 3213,
	["production"] = 108000
}
stoneVillage[3] = {
	["level"] = 3,
	["needHonour"] = 7140,
	["production"] = 144000
}
stoneVillage[4] = {
	["level"] = 4,
	["needHonour"] = 10710,
	["production"] = 192000
}
stoneVillage[5] = {
	["level"] = 5,
	["needHonour"] = 15708,
	["production"] = 252000
}
stoneVillage[6] = {
	["level"] = 6,
	["needHonour"] = 26656,
	["production"] = 324000
}
stoneVillage[7] = {
	["level"] = 7,
	["needHonour"] = 44030,
	["production"] = 408000
}
stoneVillage[8] = {
	["level"] = 8,
	["needHonour"] = 72828,
	["production"] = 504000
}
stoneVillage[9] = {
	["level"] = 9,
	["needHonour"] = 112455,
	["production"] = 612000
}
stoneVillage[10] = {
	["level"] = 10,
	["needHonour"] = 171360,
	["production"] = 732000
}
stoneVillage[11] = {
	["level"] = 11,
	["needHonour"] = 249543,
	["production"] = 864000
}
stoneVillage[12] = {
	["level"] = 12,
	["needHonour"] = 374850,
	["production"] = 1008000
}
stoneVillage[13] = {
	["level"] = 13,
	["needHonour"] = 539308,
	["production"] = 1164000
}
stoneVillage[14] = {
	["level"] = 14,
	["needHonour"] = 788256,
	["production"] = 1332000
}
stoneVillage[15] = {
	["level"] = 15,
	["needHonour"] = 1113840,
	["production"] = 1512000
}
stoneVillage[16] = {
	["level"] = 16,
	["needHonour"] = 1599360,
	["production"] = 1704000
}
stoneVillage[17] = {
	["level"] = 17,
	["needHonour"] = 2225895,
	["production"] = 1920000
}
stoneVillage[18] = {
	["level"] = 18,
	["needHonour"] = 2817920,
	["production"] = 2160000
}
stoneVillage[19] = {
	["level"] = 19,
	["needHonour"] = 3236800,
	["production"] = 2460000
}
stoneVillage[20] = {
	["level"] = 20,
	["needHonour"] = 4284000,
	["production"] = 2820000
}
