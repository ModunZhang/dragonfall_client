local alliance_name_fixed = GameDatas.ClientInitGame.alliance_name_fixed

alliance_name_fixed[1] = {
	["index"] = 1,
	["value"] = "Sword of Damocles"
}
alliance_name_fixed[2] = {
	["index"] = 2,
	["value"] = "Damon and Pythias"
}
alliance_name_fixed[3] = {
	["index"] = 3,
	["value"] = "Apple of Discord"
}
alliance_name_fixed[4] = {
	["index"] = 4,
	["value"] = "Judgment of Paris"
}
alliance_name_fixed[5] = {
	["index"] = 5,
	["value"] = "Helen of Troy"
}
alliance_name_fixed[6] = {
	["index"] = 6,
	["value"] = "The Trojan Horse"
}
alliance_name_fixed[7] = {
	["index"] = 7,
	["value"] = "Stables of Augeas"
}
alliance_name_fixed[8] = {
	["index"] = 8,
	["value"] = "Swan Song"
}
alliance_name_fixed[9] = {
	["index"] = 9,
	["value"] = "Under the Rose"
}
alliance_name_fixed[10] = {
	["index"] = 10,
	["value"] = "Cadmean Victory"
}
alliance_name_fixed[11] = {
	["index"] = 11,
	["value"] = "Cask of Danaide"
}
alliance_name_fixed[12] = {
	["index"] = 12,
	["value"] = "Freedom of Pan"
}
alliance_name_fixed[13] = {
	["index"] = 13,
	["value"] = "Lord of War"
}
alliance_name_fixed[14] = {
	["index"] = 14,
	["value"] = "God of War"
}
alliance_name_fixed[15] = {
	["index"] = 15,
	["value"] = "Chaos of War"
}
alliance_name_fixed[16] = {
	["index"] = 16,
	["value"] = "Honor of War"
}
alliance_name_fixed[17] = {
	["index"] = 17,
	["value"] = "The Crusades"
}
alliance_name_fixed[18] = {
	["index"] = 18,
	["value"] = "Blood Rose"
}
alliance_name_fixed[19] = {
	["index"] = 19,
	["value"] = "Free Lancer"
}
alliance_name_fixed[20] = {
	["index"] = 20,
	["value"] = "Gun and Rose"
}
