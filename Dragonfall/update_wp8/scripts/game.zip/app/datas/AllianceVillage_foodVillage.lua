local foodVillage = GameDatas.AllianceVillage.foodVillage

foodVillage[1] = {
	["level"] = 1,
	["needHonour"] = 1190,
	["production"] = 84000
}
foodVillage[2] = {
	["level"] = 2,
	["needHonour"] = 3213,
	["production"] = 108000
}
foodVillage[3] = {
	["level"] = 3,
	["needHonour"] = 7140,
	["production"] = 144000
}
foodVillage[4] = {
	["level"] = 4,
	["needHonour"] = 10710,
	["production"] = 192000
}
foodVillage[5] = {
	["level"] = 5,
	["needHonour"] = 15708,
	["production"] = 252000
}
foodVillage[6] = {
	["level"] = 6,
	["needHonour"] = 26656,
	["production"] = 324000
}
foodVillage[7] = {
	["level"] = 7,
	["needHonour"] = 44030,
	["production"] = 408000
}
foodVillage[8] = {
	["level"] = 8,
	["needHonour"] = 72828,
	["production"] = 504000
}
foodVillage[9] = {
	["level"] = 9,
	["needHonour"] = 112455,
	["production"] = 612000
}
foodVillage[10] = {
	["level"] = 10,
	["needHonour"] = 171360,
	["production"] = 732000
}
foodVillage[11] = {
	["level"] = 11,
	["needHonour"] = 249543,
	["production"] = 864000
}
foodVillage[12] = {
	["level"] = 12,
	["needHonour"] = 374850,
	["production"] = 1008000
}
foodVillage[13] = {
	["level"] = 13,
	["needHonour"] = 539308,
	["production"] = 1164000
}
foodVillage[14] = {
	["level"] = 14,
	["needHonour"] = 788256,
	["production"] = 1332000
}
foodVillage[15] = {
	["level"] = 15,
	["needHonour"] = 1113840,
	["production"] = 1512000
}
foodVillage[16] = {
	["level"] = 16,
	["needHonour"] = 1599360,
	["production"] = 1704000
}
foodVillage[17] = {
	["level"] = 17,
	["needHonour"] = 2225895,
	["production"] = 1920000
}
foodVillage[18] = {
	["level"] = 18,
	["needHonour"] = 2817920,
	["production"] = 2160000
}
foodVillage[19] = {
	["level"] = 19,
	["needHonour"] = 3236800,
	["production"] = 2460000
}
foodVillage[20] = {
	["level"] = 20,
	["needHonour"] = 4284000,
	["production"] = 2820000
}
