local earthquake = GameDatas.DragonSkills.earthquake

earthquake[1] = {
	["level"] = 1,
	["effect"] = 0.030000,
	["bloodCost"] = 140
}
earthquake[2] = {
	["level"] = 2,
	["effect"] = 0.060000,
	["bloodCost"] = 340
}
earthquake[3] = {
	["level"] = 3,
	["effect"] = 0.090000,
	["bloodCost"] = 580
}
earthquake[4] = {
	["level"] = 4,
	["effect"] = 0.120000,
	["bloodCost"] = 840
}
earthquake[5] = {
	["level"] = 5,
	["effect"] = 0.150000,
	["bloodCost"] = 1140
}
earthquake[6] = {
	["level"] = 6,
	["effect"] = 0.180000,
	["bloodCost"] = 2780
}
earthquake[7] = {
	["level"] = 7,
	["effect"] = 0.210000,
	["bloodCost"] = 4040
}
earthquake[8] = {
	["level"] = 8,
	["effect"] = 0.240000,
	["bloodCost"] = 5400
}
earthquake[9] = {
	["level"] = 9,
	["effect"] = 0.270000,
	["bloodCost"] = 6920
}
earthquake[10] = {
	["level"] = 10,
	["effect"] = 0.300000,
	["bloodCost"] = 8540
}
earthquake[11] = {
	["level"] = 11,
	["effect"] = 0.330000,
	["bloodCost"] = 22160
}
earthquake[12] = {
	["level"] = 12,
	["effect"] = 0.360000,
	["bloodCost"] = 32900
}
earthquake[13] = {
	["level"] = 13,
	["effect"] = 0.390000,
	["bloodCost"] = 45700
}
earthquake[14] = {
	["level"] = 14,
	["effect"] = 0.420000,
	["bloodCost"] = 60560
}
earthquake[15] = {
	["level"] = 15,
	["effect"] = 0.450000,
	["bloodCost"] = 77440
}
earthquake[16] = {
	["level"] = 16,
	["effect"] = 0.480000,
	["bloodCost"] = 147460
}
earthquake[17] = {
	["level"] = 17,
	["effect"] = 0.510000,
	["bloodCost"] = 200720
}
earthquake[18] = {
	["level"] = 18,
	["effect"] = 0.540000,
	["bloodCost"] = 262160
}
earthquake[19] = {
	["level"] = 19,
	["effect"] = 0.570000,
	["bloodCost"] = 331780
}
earthquake[20] = {
	["level"] = 20,
	["effect"] = 0.600000,
	["bloodCost"] = 409600
}
