local resources = GameDatas.PlayerInitData.resources

resources[1] = {
	["level"] = 1,
	["gem"] = 1000,
	["wood"] = 25000,
	["stone"] = 25000,
	["iron"] = 25000,
	["food"] = 25000,
	["citizen"] = 90,
	["coin"] = 50000,
	["cart"] = 20,
	["blood"] = 300,
	["stamina"] = 100,
	["casinoToken"] = 5000
}
