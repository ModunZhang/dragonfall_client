local townHall = GameDatas.BuildingFunction.townHall

townHall[1] = {
	["level"] = 1,
	["houseAdd"] = 1,
	["efficiency"] = 0.500000,
	["power"] = 60
}
townHall[2] = {
	["level"] = 2,
	["houseAdd"] = 1,
	["efficiency"] = 1.000000,
	["power"] = 65
}
townHall[3] = {
	["level"] = 3,
	["houseAdd"] = 1,
	["efficiency"] = 1.500000,
	["power"] = 70
}
townHall[4] = {
	["level"] = 4,
	["houseAdd"] = 1,
	["efficiency"] = 2.000000,
	["power"] = 80
}
townHall[5] = {
	["level"] = 5,
	["houseAdd"] = 1,
	["efficiency"] = 2.500000,
	["power"] = 90
}
townHall[6] = {
	["level"] = 6,
	["houseAdd"] = 1,
	["efficiency"] = 3.000000,
	["power"] = 100
}
townHall[7] = {
	["level"] = 7,
	["houseAdd"] = 1,
	["efficiency"] = 3.500000,
	["power"] = 130
}
townHall[8] = {
	["level"] = 8,
	["houseAdd"] = 2,
	["efficiency"] = 4.000000,
	["power"] = 200
}
townHall[9] = {
	["level"] = 9,
	["houseAdd"] = 2,
	["efficiency"] = 4.500000,
	["power"] = 390
}
townHall[10] = {
	["level"] = 10,
	["houseAdd"] = 2,
	["efficiency"] = 5.000000,
	["power"] = 560
}
townHall[11] = {
	["level"] = 11,
	["houseAdd"] = 2,
	["efficiency"] = 5.500000,
	["power"] = 760
}
townHall[12] = {
	["level"] = 12,
	["houseAdd"] = 2,
	["efficiency"] = 6.000000,
	["power"] = 950
}
townHall[13] = {
	["level"] = 13,
	["houseAdd"] = 2,
	["efficiency"] = 6.500000,
	["power"] = 1240
}
townHall[14] = {
	["level"] = 14,
	["houseAdd"] = 2,
	["efficiency"] = 7.000000,
	["power"] = 2470
}
townHall[15] = {
	["level"] = 15,
	["houseAdd"] = 3,
	["efficiency"] = 7.500000,
	["power"] = 3830
}
townHall[16] = {
	["level"] = 16,
	["houseAdd"] = 3,
	["efficiency"] = 8.000000,
	["power"] = 5290
}
townHall[17] = {
	["level"] = 17,
	["houseAdd"] = 3,
	["efficiency"] = 8.500000,
	["power"] = 7710
}
townHall[18] = {
	["level"] = 18,
	["houseAdd"] = 3,
	["efficiency"] = 9.000000,
	["power"] = 9480
}
townHall[19] = {
	["level"] = 19,
	["houseAdd"] = 3,
	["efficiency"] = 9.500000,
	["power"] = 11570
}
townHall[20] = {
	["level"] = 20,
	["houseAdd"] = 3,
	["efficiency"] = 10.000000,
	["power"] = 13560
}
townHall[21] = {
	["level"] = 21,
	["houseAdd"] = 3,
	["efficiency"] = 10.500000,
	["power"] = 18410
}
townHall[22] = {
	["level"] = 22,
	["houseAdd"] = 4,
	["efficiency"] = 11.000000,
	["power"] = 21090
}
townHall[23] = {
	["level"] = 23,
	["houseAdd"] = 4,
	["efficiency"] = 11.500000,
	["power"] = 24340
}
townHall[24] = {
	["level"] = 24,
	["houseAdd"] = 4,
	["efficiency"] = 12.000000,
	["power"] = 27380
}
townHall[25] = {
	["level"] = 25,
	["houseAdd"] = 4,
	["efficiency"] = 12.500000,
	["power"] = 37390
}
townHall[26] = {
	["level"] = 26,
	["houseAdd"] = 4,
	["efficiency"] = 13.000000,
	["power"] = 41730
}
townHall[27] = {
	["level"] = 27,
	["houseAdd"] = 4,
	["efficiency"] = 13.500000,
	["power"] = 46940
}
townHall[28] = {
	["level"] = 28,
	["houseAdd"] = 4,
	["efficiency"] = 14.000000,
	["power"] = 51870
}
townHall[29] = {
	["level"] = 29,
	["houseAdd"] = 5,
	["efficiency"] = 14.500000,
	["power"] = 73810
}
townHall[30] = {
	["level"] = 30,
	["houseAdd"] = 5,
	["efficiency"] = 15.000000,
	["power"] = 85200
}
townHall[31] = {
	["level"] = 31,
	["houseAdd"] = 5,
	["efficiency"] = 15.500000,
	["power"] = 98390
}
townHall[32] = {
	["level"] = 32,
	["houseAdd"] = 5,
	["efficiency"] = 16.000000,
	["power"] = 111630
}
townHall[33] = {
	["level"] = 33,
	["houseAdd"] = 5,
	["efficiency"] = 16.500000,
	["power"] = 152780
}
townHall[34] = {
	["level"] = 34,
	["houseAdd"] = 5,
	["efficiency"] = 17.000000,
	["power"] = 171670
}
townHall[35] = {
	["level"] = 35,
	["houseAdd"] = 5,
	["efficiency"] = 17.500000,
	["power"] = 193370
}
townHall[36] = {
	["level"] = 36,
	["houseAdd"] = 6,
	["efficiency"] = 18.000000,
	["power"] = 215210
}
townHall[37] = {
	["level"] = 37,
	["houseAdd"] = 6,
	["efficiency"] = 18.500000,
	["power"] = 289400
}
townHall[38] = {
	["level"] = 38,
	["houseAdd"] = 6,
	["efficiency"] = 19.000000,
	["power"] = 320140
}
townHall[39] = {
	["level"] = 39,
	["houseAdd"] = 6,
	["efficiency"] = 19.500000,
	["power"] = 354920
}
townHall[40] = {
	["level"] = 40,
	["houseAdd"] = 6,
	["efficiency"] = 20.000000,
	["power"] = 390390
}
