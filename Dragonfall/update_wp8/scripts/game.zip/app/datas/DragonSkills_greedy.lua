local greedy = GameDatas.DragonSkills.greedy

greedy[1] = {
	["level"] = 1,
	["effect"] = 0.020000,
	["bloodCost"] = 140
}
greedy[2] = {
	["level"] = 2,
	["effect"] = 0.040000,
	["bloodCost"] = 340
}
greedy[3] = {
	["level"] = 3,
	["effect"] = 0.060000,
	["bloodCost"] = 580
}
greedy[4] = {
	["level"] = 4,
	["effect"] = 0.080000,
	["bloodCost"] = 840
}
greedy[5] = {
	["level"] = 5,
	["effect"] = 0.100000,
	["bloodCost"] = 1140
}
greedy[6] = {
	["level"] = 6,
	["effect"] = 0.120000,
	["bloodCost"] = 2780
}
greedy[7] = {
	["level"] = 7,
	["effect"] = 0.140000,
	["bloodCost"] = 4040
}
greedy[8] = {
	["level"] = 8,
	["effect"] = 0.160000,
	["bloodCost"] = 5400
}
greedy[9] = {
	["level"] = 9,
	["effect"] = 0.180000,
	["bloodCost"] = 6920
}
greedy[10] = {
	["level"] = 10,
	["effect"] = 0.200000,
	["bloodCost"] = 8540
}
greedy[11] = {
	["level"] = 11,
	["effect"] = 0.220000,
	["bloodCost"] = 22160
}
greedy[12] = {
	["level"] = 12,
	["effect"] = 0.240000,
	["bloodCost"] = 32900
}
greedy[13] = {
	["level"] = 13,
	["effect"] = 0.260000,
	["bloodCost"] = 45700
}
greedy[14] = {
	["level"] = 14,
	["effect"] = 0.280000,
	["bloodCost"] = 60560
}
greedy[15] = {
	["level"] = 15,
	["effect"] = 0.300000,
	["bloodCost"] = 77440
}
greedy[16] = {
	["level"] = 16,
	["effect"] = 0.320000,
	["bloodCost"] = 147460
}
greedy[17] = {
	["level"] = 17,
	["effect"] = 0.340000,
	["bloodCost"] = 200720
}
greedy[18] = {
	["level"] = 18,
	["effect"] = 0.360000,
	["bloodCost"] = 262160
}
greedy[19] = {
	["level"] = 19,
	["effect"] = 0.380000,
	["bloodCost"] = 331780
}
greedy[20] = {
	["level"] = 20,
	["effect"] = 0.400000,
	["bloodCost"] = 409600
}
