local trainingGround = GameDatas.BuildingFunction.trainingGround

trainingGround[1] = {
	["level"] = 1,
	["efficiency"] = 0.010000,
	["power"] = 100
}
trainingGround[2] = {
	["level"] = 2,
	["efficiency"] = 0.020000,
	["power"] = 110
}
trainingGround[3] = {
	["level"] = 3,
	["efficiency"] = 0.030000,
	["power"] = 120
}
trainingGround[4] = {
	["level"] = 4,
	["efficiency"] = 0.040000,
	["power"] = 130
}
trainingGround[5] = {
	["level"] = 5,
	["efficiency"] = 0.050000,
	["power"] = 140
}
trainingGround[6] = {
	["level"] = 6,
	["efficiency"] = 0.060000,
	["power"] = 160
}
trainingGround[7] = {
	["level"] = 7,
	["efficiency"] = 0.070000,
	["power"] = 200
}
trainingGround[8] = {
	["level"] = 8,
	["efficiency"] = 0.080000,
	["power"] = 300
}
trainingGround[9] = {
	["level"] = 9,
	["efficiency"] = 0.090000,
	["power"] = 540
}
trainingGround[10] = {
	["level"] = 10,
	["efficiency"] = 0.100000,
	["power"] = 770
}
trainingGround[11] = {
	["level"] = 11,
	["efficiency"] = 0.110000,
	["power"] = 1040
}
trainingGround[12] = {
	["level"] = 12,
	["efficiency"] = 0.120000,
	["power"] = 1290
}
trainingGround[13] = {
	["level"] = 13,
	["efficiency"] = 0.130000,
	["power"] = 1680
}
trainingGround[14] = {
	["level"] = 14,
	["efficiency"] = 0.140000,
	["power"] = 3320
}
trainingGround[15] = {
	["level"] = 15,
	["efficiency"] = 0.150000,
	["power"] = 5130
}
trainingGround[16] = {
	["level"] = 16,
	["efficiency"] = 0.160000,
	["power"] = 7070
}
trainingGround[17] = {
	["level"] = 17,
	["efficiency"] = 0.170000,
	["power"] = 10300
}
trainingGround[18] = {
	["level"] = 18,
	["efficiency"] = 0.180000,
	["power"] = 12660
}
trainingGround[19] = {
	["level"] = 19,
	["efficiency"] = 0.190000,
	["power"] = 15450
}
trainingGround[20] = {
	["level"] = 20,
	["efficiency"] = 0.200000,
	["power"] = 18110
}
trainingGround[21] = {
	["level"] = 21,
	["efficiency"] = 0.210000,
	["power"] = 24570
}
trainingGround[22] = {
	["level"] = 22,
	["efficiency"] = 0.220000,
	["power"] = 28150
}
trainingGround[23] = {
	["level"] = 23,
	["efficiency"] = 0.230000,
	["power"] = 32480
}
trainingGround[24] = {
	["level"] = 24,
	["efficiency"] = 0.240000,
	["power"] = 36540
}
trainingGround[25] = {
	["level"] = 25,
	["efficiency"] = 0.250000,
	["power"] = 49880
}
trainingGround[26] = {
	["level"] = 26,
	["efficiency"] = 0.260000,
	["power"] = 55670
}
trainingGround[27] = {
	["level"] = 27,
	["efficiency"] = 0.270000,
	["power"] = 62620
}
trainingGround[28] = {
	["level"] = 28,
	["efficiency"] = 0.280000,
	["power"] = 69190
}
trainingGround[29] = {
	["level"] = 29,
	["efficiency"] = 0.290000,
	["power"] = 98440
}
trainingGround[30] = {
	["level"] = 30,
	["efficiency"] = 0.300000,
	["power"] = 113620
}
trainingGround[31] = {
	["level"] = 31,
	["efficiency"] = 0.310000,
	["power"] = 131220
}
trainingGround[32] = {
	["level"] = 32,
	["efficiency"] = 0.320000,
	["power"] = 148870
}
trainingGround[33] = {
	["level"] = 33,
	["efficiency"] = 0.330000,
	["power"] = 203730
}
trainingGround[34] = {
	["level"] = 34,
	["efficiency"] = 0.340000,
	["power"] = 228920
}
trainingGround[35] = {
	["level"] = 35,
	["efficiency"] = 0.350000,
	["power"] = 257850
}
trainingGround[36] = {
	["level"] = 36,
	["efficiency"] = 0.360000,
	["power"] = 286980
}
trainingGround[37] = {
	["level"] = 37,
	["efficiency"] = 0.370000,
	["power"] = 385900
}
trainingGround[38] = {
	["level"] = 38,
	["efficiency"] = 0.380000,
	["power"] = 426880
}
trainingGround[39] = {
	["level"] = 39,
	["efficiency"] = 0.390000,
	["power"] = 473250
}
trainingGround[40] = {
	["level"] = 40,
	["efficiency"] = 0.400000,
	["power"] = 520550
}
