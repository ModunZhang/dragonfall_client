local dailyQuestStyle = GameDatas.DailyQuests.dailyQuestStyle

dailyQuestStyle[1] = {
	["style"] = 1,
	["star_1"] = 2,
	["star_2"] = 4,
	["star_3"] = 2,
	["star_4"] = 0,
	["star_5"] = 0
}
dailyQuestStyle[2] = {
	["style"] = 2,
	["star_1"] = 3,
	["star_2"] = 3,
	["star_3"] = 1,
	["star_4"] = 1,
	["star_5"] = 0
}
dailyQuestStyle[3] = {
	["style"] = 3,
	["star_1"] = 4,
	["star_2"] = 2,
	["star_3"] = 1,
	["star_4"] = 1,
	["star_5"] = 0
}
dailyQuestStyle[4] = {
	["style"] = 4,
	["star_1"] = 5,
	["star_2"] = 1,
	["star_3"] = 1,
	["star_4"] = 1,
	["star_5"] = 0
}
dailyQuestStyle[5] = {
	["style"] = 5,
	["star_1"] = 6,
	["star_2"] = 0,
	["star_3"] = 1,
	["star_4"] = 0,
	["star_5"] = 1
}
