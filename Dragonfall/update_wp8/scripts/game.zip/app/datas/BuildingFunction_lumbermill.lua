local lumbermill = GameDatas.BuildingFunction.lumbermill

lumbermill[1] = {
	["level"] = 1,
	["houseAdd"] = 1,
	["protection"] = 0.005000,
	["power"] = 40
}
lumbermill[2] = {
	["level"] = 2,
	["houseAdd"] = 1,
	["protection"] = 0.010000,
	["power"] = 45
}
lumbermill[3] = {
	["level"] = 3,
	["houseAdd"] = 1,
	["protection"] = 0.015000,
	["power"] = 50
}
lumbermill[4] = {
	["level"] = 4,
	["houseAdd"] = 1,
	["protection"] = 0.020000,
	["power"] = 60
}
lumbermill[5] = {
	["level"] = 5,
	["houseAdd"] = 1,
	["protection"] = 0.025000,
	["power"] = 70
}
lumbermill[6] = {
	["level"] = 6,
	["houseAdd"] = 1,
	["protection"] = 0.030000,
	["power"] = 80
}
lumbermill[7] = {
	["level"] = 7,
	["houseAdd"] = 1,
	["protection"] = 0.035000,
	["power"] = 100
}
lumbermill[8] = {
	["level"] = 8,
	["houseAdd"] = 2,
	["protection"] = 0.040000,
	["power"] = 160
}
lumbermill[9] = {
	["level"] = 9,
	["houseAdd"] = 2,
	["protection"] = 0.045000,
	["power"] = 310
}
lumbermill[10] = {
	["level"] = 10,
	["houseAdd"] = 2,
	["protection"] = 0.050000,
	["power"] = 450
}
lumbermill[11] = {
	["level"] = 11,
	["houseAdd"] = 2,
	["protection"] = 0.055000,
	["power"] = 610
}
lumbermill[12] = {
	["level"] = 12,
	["houseAdd"] = 2,
	["protection"] = 0.060000,
	["power"] = 770
}
lumbermill[13] = {
	["level"] = 13,
	["houseAdd"] = 2,
	["protection"] = 0.065000,
	["power"] = 1010
}
lumbermill[14] = {
	["level"] = 14,
	["houseAdd"] = 2,
	["protection"] = 0.070000,
	["power"] = 2010
}
lumbermill[15] = {
	["level"] = 15,
	["houseAdd"] = 3,
	["protection"] = 0.075000,
	["power"] = 3120
}
lumbermill[16] = {
	["level"] = 16,
	["houseAdd"] = 3,
	["protection"] = 0.080000,
	["power"] = 4300
}
lumbermill[17] = {
	["level"] = 17,
	["houseAdd"] = 3,
	["protection"] = 0.085000,
	["power"] = 6270
}
lumbermill[18] = {
	["level"] = 18,
	["houseAdd"] = 3,
	["protection"] = 0.090000,
	["power"] = 7720
}
lumbermill[19] = {
	["level"] = 19,
	["houseAdd"] = 3,
	["protection"] = 0.095000,
	["power"] = 9420
}
lumbermill[20] = {
	["level"] = 20,
	["houseAdd"] = 3,
	["protection"] = 0.100000,
	["power"] = 11040
}
lumbermill[21] = {
	["level"] = 21,
	["houseAdd"] = 3,
	["protection"] = 0.105000,
	["power"] = 14990
}
lumbermill[22] = {
	["level"] = 22,
	["houseAdd"] = 4,
	["protection"] = 0.110000,
	["power"] = 17180
}
lumbermill[23] = {
	["level"] = 23,
	["houseAdd"] = 4,
	["protection"] = 0.115000,
	["power"] = 19830
}
lumbermill[24] = {
	["level"] = 24,
	["houseAdd"] = 4,
	["protection"] = 0.120000,
	["power"] = 22310
}
lumbermill[25] = {
	["level"] = 25,
	["houseAdd"] = 4,
	["protection"] = 0.125000,
	["power"] = 30460
}
lumbermill[26] = {
	["level"] = 26,
	["houseAdd"] = 4,
	["protection"] = 0.130000,
	["power"] = 34000
}
lumbermill[27] = {
	["level"] = 27,
	["houseAdd"] = 4,
	["protection"] = 0.135000,
	["power"] = 38250
}
lumbermill[28] = {
	["level"] = 28,
	["houseAdd"] = 4,
	["protection"] = 0.140000,
	["power"] = 42260
}
lumbermill[29] = {
	["level"] = 29,
	["houseAdd"] = 5,
	["protection"] = 0.145000,
	["power"] = 60130
}
lumbermill[30] = {
	["level"] = 30,
	["houseAdd"] = 5,
	["protection"] = 0.150000,
	["power"] = 69410
}
lumbermill[31] = {
	["level"] = 31,
	["houseAdd"] = 5,
	["protection"] = 0.155000,
	["power"] = 80170
}
lumbermill[32] = {
	["level"] = 32,
	["houseAdd"] = 5,
	["protection"] = 0.160000,
	["power"] = 90950
}
lumbermill[33] = {
	["level"] = 33,
	["houseAdd"] = 5,
	["protection"] = 0.165000,
	["power"] = 124480
}
lumbermill[34] = {
	["level"] = 34,
	["houseAdd"] = 5,
	["protection"] = 0.170000,
	["power"] = 139870
}
lumbermill[35] = {
	["level"] = 35,
	["houseAdd"] = 5,
	["protection"] = 0.175000,
	["power"] = 157550
}
lumbermill[36] = {
	["level"] = 36,
	["houseAdd"] = 6,
	["protection"] = 0.180000,
	["power"] = 175350
}
lumbermill[37] = {
	["level"] = 37,
	["houseAdd"] = 6,
	["protection"] = 0.185000,
	["power"] = 235810
}
lumbermill[38] = {
	["level"] = 38,
	["houseAdd"] = 6,
	["protection"] = 0.190000,
	["power"] = 260850
}
lumbermill[39] = {
	["level"] = 39,
	["houseAdd"] = 6,
	["protection"] = 0.195000,
	["power"] = 289190
}
lumbermill[40] = {
	["level"] = 40,
	["houseAdd"] = 6,
	["protection"] = 0.200000,
	["power"] = 318090
}
