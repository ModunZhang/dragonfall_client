local chest = GameDatas.DragonEquipments.chest

chest["2_0"] = {
	["star"] = "2_0",
	["enhanceExp"] = 400,
	["strength"] = 0,
	["vitality"] = 11,
	["leadership"] = 0
}
chest["2_1"] = {
	["star"] = "2_1",
	["enhanceExp"] = 800,
	["strength"] = 0,
	["vitality"] = 13,
	["leadership"] = 0
}
chest["2_2"] = {
	["star"] = "2_2",
	["enhanceExp"] = 2400,
	["strength"] = 0,
	["vitality"] = 16,
	["leadership"] = 0
}
chest["3_0"] = {
	["star"] = "3_0",
	["enhanceExp"] = 1600,
	["strength"] = 0,
	["vitality"] = 22,
	["leadership"] = 0
}
chest["3_1"] = {
	["star"] = "3_1",
	["enhanceExp"] = 3200,
	["strength"] = 0,
	["vitality"] = 27,
	["leadership"] = 0
}
chest["3_2"] = {
	["star"] = "3_2",
	["enhanceExp"] = 9600,
	["strength"] = 0,
	["vitality"] = 34,
	["leadership"] = 0
}
chest["3_3"] = {
	["star"] = "3_3",
	["enhanceExp"] = 12800,
	["strength"] = 0,
	["vitality"] = 42,
	["leadership"] = 0
}
chest["4_0"] = {
	["star"] = "4_0",
	["enhanceExp"] = 5600,
	["strength"] = 0,
	["vitality"] = 46,
	["leadership"] = 0
}
chest["4_1"] = {
	["star"] = "4_1",
	["enhanceExp"] = 11200,
	["strength"] = 0,
	["vitality"] = 58,
	["leadership"] = 0
}
chest["4_2"] = {
	["star"] = "4_2",
	["enhanceExp"] = 33600,
	["strength"] = 0,
	["vitality"] = 72,
	["leadership"] = 0
}
chest["4_3"] = {
	["star"] = "4_3",
	["enhanceExp"] = 44800,
	["strength"] = 0,
	["vitality"] = 90,
	["leadership"] = 0
}
chest["4_4"] = {
	["star"] = "4_4",
	["enhanceExp"] = 89600,
	["strength"] = 0,
	["vitality"] = 112,
	["leadership"] = 0
}
chest["5_0"] = {
	["star"] = "5_0",
	["enhanceExp"] = 22400,
	["strength"] = 0,
	["vitality"] = 133,
	["leadership"] = 0
}
chest["5_1"] = {
	["star"] = "5_1",
	["enhanceExp"] = 44800,
	["strength"] = 0,
	["vitality"] = 156,
	["leadership"] = 0
}
chest["5_2"] = {
	["star"] = "5_2",
	["enhanceExp"] = 134400,
	["strength"] = 0,
	["vitality"] = 184,
	["leadership"] = 0
}
chest["5_3"] = {
	["star"] = "5_3",
	["enhanceExp"] = 179200,
	["strength"] = 0,
	["vitality"] = 216,
	["leadership"] = 0
}
chest["5_4"] = {
	["star"] = "5_4",
	["enhanceExp"] = 358400,
	["strength"] = 0,
	["vitality"] = 254,
	["leadership"] = 0
}
chest["5_5"] = {
	["star"] = "5_5",
	["enhanceExp"] = 716800,
	["strength"] = 0,
	["vitality"] = 300,
	["leadership"] = 0
}
