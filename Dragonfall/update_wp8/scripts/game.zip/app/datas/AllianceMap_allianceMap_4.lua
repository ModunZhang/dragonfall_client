local allianceMap_4 = GameDatas.AllianceMap.allianceMap_4

allianceMap_4[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 1
}
allianceMap_4[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_3",
	["x"] = 4,
	["y"] = 1
}
allianceMap_4[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 1
}
allianceMap_4[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 1
}
allianceMap_4[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 1
}
allianceMap_4[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 2
}
allianceMap_4[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 2
}
allianceMap_4[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 2
}
allianceMap_4[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 2
}
allianceMap_4[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 2
}
allianceMap_4[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 2
}
allianceMap_4[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 3
}
allianceMap_4[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 3
}
allianceMap_4[13] = {
	["index"] = 13,
	["name"] = "decorate_lake_1",
	["x"] = 18,
	["y"] = 3
}
allianceMap_4[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_3",
	["x"] = 19,
	["y"] = 3
}
allianceMap_4[15] = {
	["index"] = 15,
	["name"] = "decorate_lake_2",
	["x"] = 3,
	["y"] = 4
}
allianceMap_4[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_5",
	["x"] = 4,
	["y"] = 4
}
allianceMap_4[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_8",
	["x"] = 16,
	["y"] = 4
}
allianceMap_4[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 4
}
allianceMap_4[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 4
}
allianceMap_4[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 5
}
allianceMap_4[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 5
}
allianceMap_4[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 5
}
allianceMap_4[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 5
}
allianceMap_4[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 6
}
allianceMap_4[25] = {
	["index"] = 25,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 6
}
allianceMap_4[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 6
}
allianceMap_4[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 6
}
allianceMap_4[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 7
}
allianceMap_4[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 7
}
allianceMap_4[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_4",
	["x"] = 11,
	["y"] = 7
}
allianceMap_4[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 7
}
allianceMap_4[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 8
}
allianceMap_4[33] = {
	["index"] = 33,
	["name"] = "palace",
	["x"] = 8,
	["y"] = 8
}
allianceMap_4[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 8
}
allianceMap_4[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 8
}
allianceMap_4[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 8
}
allianceMap_4[37] = {
	["index"] = 37,
	["name"] = "bloodSpring",
	["x"] = 12,
	["y"] = 8
}
allianceMap_4[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 8
}
allianceMap_4[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_4",
	["x"] = 5,
	["y"] = 9
}
allianceMap_4[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 9
}
allianceMap_4[41] = {
	["index"] = 41,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 9
}
allianceMap_4[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 9
}
allianceMap_4[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 9
}
allianceMap_4[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 9
}
allianceMap_4[45] = {
	["index"] = 45,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 10
}
allianceMap_4[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 10
}
allianceMap_4[47] = {
	["index"] = 47,
	["name"] = "orderHall",
	["x"] = 8,
	["y"] = 10
}
allianceMap_4[48] = {
	["index"] = 48,
	["name"] = "shop",
	["x"] = 12,
	["y"] = 10
}
allianceMap_4[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 10
}
allianceMap_4[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_2",
	["x"] = 14,
	["y"] = 10
}
allianceMap_4[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 11
}
allianceMap_4[52] = {
	["index"] = 52,
	["name"] = "decorate_mountain_1",
	["x"] = 11,
	["y"] = 11
}
allianceMap_4[53] = {
	["index"] = 53,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 11
}
allianceMap_4[54] = {
	["index"] = 54,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 11
}
allianceMap_4[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 11
}
allianceMap_4[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 12
}
allianceMap_4[57] = {
	["index"] = 57,
	["name"] = "shrine",
	["x"] = 8,
	["y"] = 12
}
allianceMap_4[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_3",
	["x"] = 9,
	["y"] = 12
}
allianceMap_4[59] = {
	["index"] = 59,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 12
}
allianceMap_4[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 12
}
allianceMap_4[61] = {
	["index"] = 61,
	["name"] = "watchTower",
	["x"] = 12,
	["y"] = 12
}
allianceMap_4[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_3",
	["x"] = 13,
	["y"] = 12
}
allianceMap_4[63] = {
	["index"] = 63,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 13
}
allianceMap_4[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 13
}
allianceMap_4[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 13
}
allianceMap_4[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 13
}
allianceMap_4[67] = {
	["index"] = 67,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 13
}
allianceMap_4[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 14
}
allianceMap_4[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 14
}
allianceMap_4[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 14
}
allianceMap_4[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 15
}
allianceMap_4[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 15
}
allianceMap_4[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_3",
	["x"] = 8,
	["y"] = 15
}
allianceMap_4[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_7",
	["x"] = 16,
	["y"] = 15
}
allianceMap_4[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_3",
	["x"] = 17,
	["y"] = 15
}
allianceMap_4[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 15
}
allianceMap_4[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 16
}
allianceMap_4[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 16
}
allianceMap_4[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 16
}
allianceMap_4[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_1",
	["x"] = 1,
	["y"] = 17
}
allianceMap_4[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 17
}
allianceMap_4[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_9",
	["x"] = 3,
	["y"] = 17
}
allianceMap_4[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 17
}
allianceMap_4[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 17
}
allianceMap_4[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_1",
	["x"] = 14,
	["y"] = 17
}
allianceMap_4[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 17
}
allianceMap_4[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 18
}
allianceMap_4[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 18
}
allianceMap_4[89] = {
	["index"] = 89,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 18
}
allianceMap_4[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 18
}
allianceMap_4[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_3",
	["x"] = 15,
	["y"] = 18
}
allianceMap_4[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 18
}
allianceMap_4[93] = {
	["index"] = 93,
	["name"] = "decorate_mountain_2",
	["x"] = 19,
	["y"] = 18
}
allianceMap_4[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 19
}
allianceMap_4[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 19
}
allianceMap_4[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 19
}
allianceMap_4[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 19
}
allianceMap_4[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 19
}
allianceMap_4[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_1",
	["x"] = 16,
	["y"] = 19
}
allianceMap_4[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 19
}
allianceMap_4[101] = {
	["index"] = 101,
	["name"] = "decorate_tree_4",
	["x"] = 18,
	["y"] = 19
}
