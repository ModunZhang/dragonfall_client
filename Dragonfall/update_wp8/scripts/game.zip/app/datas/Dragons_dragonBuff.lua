local dragonBuff = GameDatas.Dragons.dragonBuff

dragonBuff[0] = {
	["index"] = 0,
	["hpFrom"] = 80,
	["hpTo"] = 100,
	["buffPercent"] = 1.000000
}
dragonBuff[1] = {
	["index"] = 1,
	["hpFrom"] = 60,
	["hpTo"] = 80,
	["buffPercent"] = 0.850000
}
dragonBuff[2] = {
	["index"] = 2,
	["hpFrom"] = 40,
	["hpTo"] = 60,
	["buffPercent"] = 0.700000
}
dragonBuff[3] = {
	["index"] = 3,
	["hpFrom"] = 20,
	["hpTo"] = 40,
	["buffPercent"] = 0.550000
}
dragonBuff[4] = {
	["index"] = 4,
	["hpFrom"] = 0,
	["hpTo"] = 20,
	["buffPercent"] = 0.400000
}
dragonBuff[5] = {
	["index"] = 5,
	["hpFrom"] = 0,
	["hpTo"] = 0,
	["buffPercent"] = 0.250000
}
