local time = GameDatas.GemsPayment.time

time[1] = {
	["index"] = 1,
	["min"] = 0,
	["max"] = 240,
	["speedup"] = 60,
	["gem"] = 5
}
time[2] = {
	["index"] = 2,
	["min"] = 240,
	["max"] = 750,
	["speedup"] = 300,
	["gem"] = 20
}
time[3] = {
	["index"] = 3,
	["min"] = 750,
	["max"] = 2340,
	["speedup"] = 900,
	["gem"] = 50
}
time[4] = {
	["index"] = 4,
	["min"] = 2340,
	["max"] = 8308,
	["speedup"] = 3600,
	["gem"] = 130
}
time[5] = {
	["index"] = 5,
	["min"] = 8308,
	["max"] = 23400,
	["speedup"] = 10800,
	["gem"] = 300
}
time[6] = {
	["index"] = 6,
	["min"] = 23400,
	["max"] = 44308,
	["speedup"] = 28800,
	["gem"] = 650
}
time[7] = {
	["index"] = 7,
	["min"] = 44308,
	["max"] = 81000,
	["speedup"] = 54000,
	["gem"] = 1000
}
time[8] = {
	["index"] = 8,
	["min"] = 81000,
	["speedup"] = 86400,
	["gem"] = 1500
}
