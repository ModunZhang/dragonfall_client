local farmer = GameDatas.HouseReturn.farmer

farmer[1] = {
	["level"] = 1,
	["wood"] = 100,
	["stone"] = 60,
	["iron"] = 40,
	["citizen"] = 10
}
farmer[2] = {
	["level"] = 2,
	["wood"] = 240,
	["stone"] = 144,
	["iron"] = 96,
	["citizen"] = 16
}
farmer[3] = {
	["level"] = 3,
	["wood"] = 480,
	["stone"] = 288,
	["iron"] = 192,
	["citizen"] = 22
}
farmer[4] = {
	["level"] = 4,
	["wood"] = 720,
	["stone"] = 432,
	["iron"] = 288,
	["citizen"] = 32
}
farmer[5] = {
	["level"] = 5,
	["wood"] = 960,
	["stone"] = 576,
	["iron"] = 384,
	["citizen"] = 44
}
farmer[6] = {
	["level"] = 6,
	["wood"] = 1200,
	["stone"] = 720,
	["iron"] = 480,
	["citizen"] = 58
}
farmer[7] = {
	["level"] = 7,
	["wood"] = 1440,
	["stone"] = 864,
	["iron"] = 576,
	["citizen"] = 76
}
farmer[8] = {
	["level"] = 8,
	["wood"] = 1872,
	["stone"] = 1124,
	["iron"] = 749,
	["citizen"] = 94
}
farmer[9] = {
	["level"] = 9,
	["wood"] = 4608,
	["stone"] = 2765,
	["iron"] = 1844,
	["citizen"] = 116
}
farmer[10] = {
	["level"] = 10,
	["wood"] = 8352,
	["stone"] = 5012,
	["iron"] = 3341,
	["citizen"] = 140
}
farmer[11] = {
	["level"] = 11,
	["wood"] = 21197,
	["stone"] = 12719,
	["iron"] = 8479,
	["citizen"] = 166
}
farmer[12] = {
	["level"] = 12,
	["wood"] = 31104,
	["stone"] = 18663,
	["iron"] = 12442,
	["citizen"] = 196
}
farmer[13] = {
	["level"] = 13,
	["wood"] = 43316,
	["stone"] = 25990,
	["iron"] = 17327,
	["citizen"] = 226
}
farmer[14] = {
	["level"] = 14,
	["wood"] = 58061,
	["stone"] = 34837,
	["iron"] = 23225,
	["citizen"] = 260
}
farmer[15] = {
	["level"] = 15,
	["wood"] = 75572,
	["stone"] = 45343,
	["iron"] = 30229,
	["citizen"] = 296
}
farmer[16] = {
	["level"] = 16,
	["wood"] = 110096,
	["stone"] = 66058,
	["iron"] = 44039,
	["citizen"] = 334
}
farmer[17] = {
	["level"] = 17,
	["wood"] = 134760,
	["stone"] = 80856,
	["iron"] = 53904,
	["citizen"] = 376
}
farmer[18] = {
	["level"] = 18,
	["wood"] = 161244,
	["stone"] = 96747,
	["iron"] = 64498,
	["citizen"] = 418
}
farmer[19] = {
	["level"] = 19,
	["wood"] = 187336,
	["stone"] = 112402,
	["iron"] = 74935,
	["citizen"] = 464
}
farmer[20] = {
	["level"] = 20,
	["wood"] = 210824,
	["stone"] = 126495,
	["iron"] = 84330,
	["citizen"] = 512
}
farmer[21] = {
	["level"] = 21,
	["wood"] = 355295,
	["stone"] = 213177,
	["iron"] = 142118,
	["citizen"] = 562
}
farmer[22] = {
	["level"] = 22,
	["wood"] = 388596,
	["stone"] = 233158,
	["iron"] = 155439,
	["citizen"] = 616
}
farmer[23] = {
	["level"] = 23,
	["wood"] = 414962,
	["stone"] = 248977,
	["iron"] = 165985,
	["citizen"] = 670
}
farmer[24] = {
	["level"] = 24,
	["wood"] = 473018,
	["stone"] = 283811,
	["iron"] = 189208,
	["citizen"] = 728
}
farmer[25] = {
	["level"] = 25,
	["wood"] = 526664,
	["stone"] = 315999,
	["iron"] = 210666,
	["citizen"] = 788
}
farmer[26] = {
	["level"] = 26,
	["wood"] = 923110,
	["stone"] = 553866,
	["iron"] = 369244,
	["citizen"] = 850
}
farmer[27] = {
	["level"] = 27,
	["wood"] = 1023605,
	["stone"] = 614163,
	["iron"] = 409442,
	["citizen"] = 916
}
farmer[28] = {
	["level"] = 28,
	["wood"] = 1120613,
	["stone"] = 672368,
	["iron"] = 448246,
	["citizen"] = 982
}
farmer[29] = {
	["level"] = 29,
	["wood"] = 1212709,
	["stone"] = 727626,
	["iron"] = 485084,
	["citizen"] = 1052
}
farmer[30] = {
	["level"] = 30,
	["wood"] = 1298468,
	["stone"] = 779081,
	["iron"] = 519388,
	["citizen"] = 1124
}
farmer[31] = {
	["level"] = 31,
	["wood"] = 2194028,
	["stone"] = 1316417,
	["iron"] = 877611,
	["citizen"] = 1198
}
farmer[32] = {
	["level"] = 32,
	["wood"] = 2369642,
	["stone"] = 1421785,
	["iron"] = 947857,
	["citizen"] = 1276
}
farmer[33] = {
	["level"] = 33,
	["wood"] = 2543042,
	["stone"] = 1525825,
	["iron"] = 1017217,
	["citizen"] = 1354
}
farmer[34] = {
	["level"] = 34,
	["wood"] = 2713110,
	["stone"] = 1627866,
	["iron"] = 1085244,
	["citizen"] = 1436
}
farmer[35] = {
	["level"] = 35,
	["wood"] = 2878728,
	["stone"] = 1727237,
	["iron"] = 1151492,
	["citizen"] = 1520
}
farmer[36] = {
	["level"] = 36,
	["wood"] = 4657224,
	["stone"] = 2794335,
	["iron"] = 1862890,
	["citizen"] = 1606
}
farmer[37] = {
	["level"] = 37,
	["wood"] = 4981432,
	["stone"] = 2988860,
	["iron"] = 1992573,
	["citizen"] = 1696
}
farmer[38] = {
	["level"] = 38,
	["wood"] = 5309012,
	["stone"] = 3185408,
	["iron"] = 2123605,
	["citizen"] = 1786
}
farmer[39] = {
	["level"] = 39,
	["wood"] = 5639192,
	["stone"] = 3383516,
	["iron"] = 2255677,
	["citizen"] = 1880
}
farmer[40] = {
	["level"] = 40,
	["wood"] = 8477500,
	["stone"] = 5086500,
	["iron"] = 3391000,
	["citizen"] = 2000
}
