local allianceMap_2 = GameDatas.AllianceMap.allianceMap_2

allianceMap_2[0] = {
	["index"] = 0,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 1
}
allianceMap_2[1] = {
	["index"] = 1,
	["name"] = "decorate_tree_4",
	["x"] = 4,
	["y"] = 1
}
allianceMap_2[2] = {
	["index"] = 2,
	["name"] = "decorate_tree_4",
	["x"] = 6,
	["y"] = 1
}
allianceMap_2[3] = {
	["index"] = 3,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 1
}
allianceMap_2[4] = {
	["index"] = 4,
	["name"] = "decorate_tree_1",
	["x"] = 15,
	["y"] = 1
}
allianceMap_2[5] = {
	["index"] = 5,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 1
}
allianceMap_2[6] = {
	["index"] = 6,
	["name"] = "decorate_tree_3",
	["x"] = 18,
	["y"] = 1
}
allianceMap_2[7] = {
	["index"] = 7,
	["name"] = "decorate_tree_2",
	["x"] = 2,
	["y"] = 2
}
allianceMap_2[8] = {
	["index"] = 8,
	["name"] = "decorate_tree_5",
	["x"] = 3,
	["y"] = 2
}
allianceMap_2[9] = {
	["index"] = 9,
	["name"] = "decorate_tree_1",
	["x"] = 5,
	["y"] = 2
}
allianceMap_2[10] = {
	["index"] = 10,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 2
}
allianceMap_2[11] = {
	["index"] = 11,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 2
}
allianceMap_2[12] = {
	["index"] = 12,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 2
}
allianceMap_2[13] = {
	["index"] = 13,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 2
}
allianceMap_2[14] = {
	["index"] = 14,
	["name"] = "decorate_tree_8",
	["x"] = 16,
	["y"] = 2
}
allianceMap_2[15] = {
	["index"] = 15,
	["name"] = "decorate_tree_2",
	["x"] = 1,
	["y"] = 3
}
allianceMap_2[16] = {
	["index"] = 16,
	["name"] = "decorate_tree_3",
	["x"] = 2,
	["y"] = 3
}
allianceMap_2[17] = {
	["index"] = 17,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 3
}
allianceMap_2[18] = {
	["index"] = 18,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 3
}
allianceMap_2[19] = {
	["index"] = 19,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 3
}
allianceMap_2[20] = {
	["index"] = 20,
	["name"] = "decorate_tree_3",
	["x"] = 6,
	["y"] = 3
}
allianceMap_2[21] = {
	["index"] = 21,
	["name"] = "decorate_tree_2",
	["x"] = 15,
	["y"] = 3
}
allianceMap_2[22] = {
	["index"] = 22,
	["name"] = "decorate_tree_3",
	["x"] = 16,
	["y"] = 3
}
allianceMap_2[23] = {
	["index"] = 23,
	["name"] = "decorate_tree_4",
	["x"] = 3,
	["y"] = 4
}
allianceMap_2[24] = {
	["index"] = 24,
	["name"] = "decorate_tree_2",
	["x"] = 16,
	["y"] = 4
}
allianceMap_2[25] = {
	["index"] = 25,
	["name"] = "decorate_lake_2",
	["x"] = 19,
	["y"] = 4
}
allianceMap_2[26] = {
	["index"] = 26,
	["name"] = "decorate_tree_4",
	["x"] = 1,
	["y"] = 5
}
allianceMap_2[27] = {
	["index"] = 27,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 5
}
allianceMap_2[28] = {
	["index"] = 28,
	["name"] = "decorate_tree_1",
	["x"] = 17,
	["y"] = 5
}
allianceMap_2[29] = {
	["index"] = 29,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 5
}
allianceMap_2[30] = {
	["index"] = 30,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 6
}
allianceMap_2[31] = {
	["index"] = 31,
	["name"] = "decorate_tree_4",
	["x"] = 10,
	["y"] = 6
}
allianceMap_2[32] = {
	["index"] = 32,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 6
}
allianceMap_2[33] = {
	["index"] = 33,
	["name"] = "decorate_tree_2",
	["x"] = 19,
	["y"] = 6
}
allianceMap_2[34] = {
	["index"] = 34,
	["name"] = "decorate_tree_2",
	["x"] = 3,
	["y"] = 7
}
allianceMap_2[35] = {
	["index"] = 35,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 7
}
allianceMap_2[36] = {
	["index"] = 36,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 7
}
allianceMap_2[37] = {
	["index"] = 37,
	["name"] = "decorate_tree_2",
	["x"] = 10,
	["y"] = 7
}
allianceMap_2[38] = {
	["index"] = 38,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 7
}
allianceMap_2[39] = {
	["index"] = 39,
	["name"] = "decorate_tree_1",
	["x"] = 2,
	["y"] = 8
}
allianceMap_2[40] = {
	["index"] = 40,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 8
}
allianceMap_2[41] = {
	["index"] = 41,
	["name"] = "palace",
	["x"] = 8,
	["y"] = 8
}
allianceMap_2[42] = {
	["index"] = 42,
	["name"] = "decorate_tree_1",
	["x"] = 9,
	["y"] = 8
}
allianceMap_2[43] = {
	["index"] = 43,
	["name"] = "decorate_tree_1",
	["x"] = 10,
	["y"] = 8
}
allianceMap_2[44] = {
	["index"] = 44,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 8
}
allianceMap_2[45] = {
	["index"] = 45,
	["name"] = "bloodSpring",
	["x"] = 12,
	["y"] = 8
}
allianceMap_2[46] = {
	["index"] = 46,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 8
}
allianceMap_2[47] = {
	["index"] = 47,
	["name"] = "decorate_tree_4",
	["x"] = 7,
	["y"] = 9
}
allianceMap_2[48] = {
	["index"] = 48,
	["name"] = "decorate_tree_2",
	["x"] = 8,
	["y"] = 9
}
allianceMap_2[49] = {
	["index"] = 49,
	["name"] = "decorate_tree_2",
	["x"] = 12,
	["y"] = 9
}
allianceMap_2[50] = {
	["index"] = 50,
	["name"] = "decorate_tree_1",
	["x"] = 13,
	["y"] = 9
}
allianceMap_2[51] = {
	["index"] = 51,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 10
}
allianceMap_2[52] = {
	["index"] = 52,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 10
}
allianceMap_2[53] = {
	["index"] = 53,
	["name"] = "orderHall",
	["x"] = 8,
	["y"] = 10
}
allianceMap_2[54] = {
	["index"] = 54,
	["name"] = "shop",
	["x"] = 12,
	["y"] = 10
}
allianceMap_2[55] = {
	["index"] = 55,
	["name"] = "decorate_tree_2",
	["x"] = 13,
	["y"] = 10
}
allianceMap_2[56] = {
	["index"] = 56,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 10
}
allianceMap_2[57] = {
	["index"] = 57,
	["name"] = "decorate_tree_2",
	["x"] = 7,
	["y"] = 11
}
allianceMap_2[58] = {
	["index"] = 58,
	["name"] = "decorate_tree_1",
	["x"] = 8,
	["y"] = 11
}
allianceMap_2[59] = {
	["index"] = 59,
	["name"] = "decorate_lake_1",
	["x"] = 11,
	["y"] = 11
}
allianceMap_2[60] = {
	["index"] = 60,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 11
}
allianceMap_2[61] = {
	["index"] = 61,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 11
}
allianceMap_2[62] = {
	["index"] = 62,
	["name"] = "decorate_tree_2",
	["x"] = 6,
	["y"] = 12
}
allianceMap_2[63] = {
	["index"] = 63,
	["name"] = "shrine",
	["x"] = 8,
	["y"] = 12
}
allianceMap_2[64] = {
	["index"] = 64,
	["name"] = "decorate_tree_4",
	["x"] = 9,
	["y"] = 12
}
allianceMap_2[65] = {
	["index"] = 65,
	["name"] = "decorate_tree_3",
	["x"] = 10,
	["y"] = 12
}
allianceMap_2[66] = {
	["index"] = 66,
	["name"] = "decorate_tree_3",
	["x"] = 11,
	["y"] = 12
}
allianceMap_2[67] = {
	["index"] = 67,
	["name"] = "watchTower",
	["x"] = 12,
	["y"] = 12
}
allianceMap_2[68] = {
	["index"] = 68,
	["name"] = "decorate_tree_4",
	["x"] = 13,
	["y"] = 12
}
allianceMap_2[69] = {
	["index"] = 69,
	["name"] = "decorate_tree_4",
	["x"] = 8,
	["y"] = 13
}
allianceMap_2[70] = {
	["index"] = 70,
	["name"] = "decorate_tree_2",
	["x"] = 9,
	["y"] = 13
}
allianceMap_2[71] = {
	["index"] = 71,
	["name"] = "decorate_tree_1",
	["x"] = 11,
	["y"] = 13
}
allianceMap_2[72] = {
	["index"] = 72,
	["name"] = "decorate_tree_3",
	["x"] = 1,
	["y"] = 14
}
allianceMap_2[73] = {
	["index"] = 73,
	["name"] = "decorate_tree_3",
	["x"] = 7,
	["y"] = 14
}
allianceMap_2[74] = {
	["index"] = 74,
	["name"] = "decorate_tree_2",
	["x"] = 11,
	["y"] = 14
}
allianceMap_2[75] = {
	["index"] = 75,
	["name"] = "decorate_tree_1",
	["x"] = 12,
	["y"] = 14
}
allianceMap_2[76] = {
	["index"] = 76,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 14
}
allianceMap_2[77] = {
	["index"] = 77,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 15
}
allianceMap_2[78] = {
	["index"] = 78,
	["name"] = "decorate_tree_1",
	["x"] = 3,
	["y"] = 15
}
allianceMap_2[79] = {
	["index"] = 79,
	["name"] = "decorate_tree_3",
	["x"] = 12,
	["y"] = 15
}
allianceMap_2[80] = {
	["index"] = 80,
	["name"] = "decorate_tree_1",
	["x"] = 18,
	["y"] = 15
}
allianceMap_2[81] = {
	["index"] = 81,
	["name"] = "decorate_tree_2",
	["x"] = 17,
	["y"] = 16
}
allianceMap_2[82] = {
	["index"] = 82,
	["name"] = "decorate_tree_2",
	["x"] = 18,
	["y"] = 16
}
allianceMap_2[83] = {
	["index"] = 83,
	["name"] = "decorate_tree_4",
	["x"] = 19,
	["y"] = 16
}
allianceMap_2[84] = {
	["index"] = 84,
	["name"] = "decorate_tree_1",
	["x"] = 4,
	["y"] = 17
}
allianceMap_2[85] = {
	["index"] = 85,
	["name"] = "decorate_tree_3",
	["x"] = 5,
	["y"] = 17
}
allianceMap_2[86] = {
	["index"] = 86,
	["name"] = "decorate_tree_1",
	["x"] = 7,
	["y"] = 17
}
allianceMap_2[87] = {
	["index"] = 87,
	["name"] = "decorate_tree_4",
	["x"] = 14,
	["y"] = 17
}
allianceMap_2[88] = {
	["index"] = 88,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 17
}
allianceMap_2[89] = {
	["index"] = 89,
	["name"] = "decorate_mountain_1",
	["x"] = 3,
	["y"] = 18
}
allianceMap_2[90] = {
	["index"] = 90,
	["name"] = "decorate_tree_2",
	["x"] = 4,
	["y"] = 18
}
allianceMap_2[91] = {
	["index"] = 91,
	["name"] = "decorate_tree_9",
	["x"] = 5,
	["y"] = 18
}
allianceMap_2[92] = {
	["index"] = 92,
	["name"] = "decorate_tree_1",
	["x"] = 6,
	["y"] = 18
}
allianceMap_2[93] = {
	["index"] = 93,
	["name"] = "decorate_tree_7",
	["x"] = 13,
	["y"] = 18
}
allianceMap_2[94] = {
	["index"] = 94,
	["name"] = "decorate_tree_3",
	["x"] = 14,
	["y"] = 18
}
allianceMap_2[95] = {
	["index"] = 95,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 18
}
allianceMap_2[96] = {
	["index"] = 96,
	["name"] = "decorate_tree_1",
	["x"] = 19,
	["y"] = 18
}
allianceMap_2[97] = {
	["index"] = 97,
	["name"] = "decorate_tree_4",
	["x"] = 2,
	["y"] = 19
}
allianceMap_2[98] = {
	["index"] = 98,
	["name"] = "decorate_tree_3",
	["x"] = 3,
	["y"] = 19
}
allianceMap_2[99] = {
	["index"] = 99,
	["name"] = "decorate_tree_2",
	["x"] = 5,
	["y"] = 19
}
allianceMap_2[100] = {
	["index"] = 100,
	["name"] = "decorate_tree_4",
	["x"] = 15,
	["y"] = 19
}
allianceMap_2[101] = {
	["index"] = 101,
	["name"] = "decorate_mountain_2",
	["x"] = 18,
	["y"] = 19
}
