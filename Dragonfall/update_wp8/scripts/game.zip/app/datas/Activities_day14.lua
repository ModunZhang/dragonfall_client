local day14 = GameDatas.Activities.day14

day14[1] = {
	["day"] = 1,
	["rewards"] = "soldiers:catapult_1:200"
}
day14[2] = {
	["day"] = 2,
	["rewards"] = "soldiers:lancer_1:250"
}
day14[3] = {
	["day"] = 3,
	["rewards"] = "soldiers:sentinel_1:300"
}
day14[4] = {
	["day"] = 4,
	["rewards"] = "soldiers:crossbowman_1:300"
}
day14[5] = {
	["day"] = 5,
	["rewards"] = "soldiers:horseArcher_1:200"
}
day14[6] = {
	["day"] = 6,
	["rewards"] = "soldiers:ballista_1:200"
}
day14[7] = {
	["day"] = 7,
	["rewards"] = "soldiers:swordsman_2:200"
}
day14[8] = {
	["day"] = 8,
	["rewards"] = "soldiers:ranger_2:200"
}
day14[9] = {
	["day"] = 9,
	["rewards"] = "soldiers:lancer_2:200"
}
day14[10] = {
	["day"] = 10,
	["rewards"] = "soldiers:catapult_2:200"
}
day14[11] = {
	["day"] = 11,
	["rewards"] = "soldiers:skeletonWarrior:200"
}
day14[12] = {
	["day"] = 12,
	["rewards"] = "soldiers:skeletonArcher:200"
}
day14[13] = {
	["day"] = 13,
	["rewards"] = "soldiers:deathKnight:200"
}
day14[14] = {
	["day"] = 14,
	["rewards"] = "soldiers:meatWagon:200"
}
