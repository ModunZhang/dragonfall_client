#! /bin/bash
#清空"player"中Userdefault 中存储的所有数据
defaults delete com.cocos.quick.apps.player