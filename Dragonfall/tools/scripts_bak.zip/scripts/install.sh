#! /bin/bash
# 添加脚本的执行权限
find . -name "*.sh" -exec chmod +x {} \;